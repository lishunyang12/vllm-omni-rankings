#!/usr/bin/env bash
set -Eeuo pipefail
root_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ "${1:-}" == start ]]; then
  printf 'start_before,%s\n' "$(date +%s%N)" >>"$root_dir/capture-control.csv"
  /usr/local/cuda/bin/nsys "$@" --gpu-metrics-devices=all --gpu-metrics-frequency=1000
  printf 'start_after,%s\n' "$(date +%s%N)" >>"$root_dir/capture-control.csv"
elif [[ "${1:-}" == stop ]]; then
  printf 'stop_before,%s\n' "$(date +%s%N)" >>"$root_dir/capture-control.csv"
  /usr/local/cuda/bin/nsys "$@"
  printf 'stop_after,%s\n' "$(date +%s%N)" >>"$root_dir/capture-control.csv"
else
  exec /usr/local/cuda/bin/nsys "$@"
fi
