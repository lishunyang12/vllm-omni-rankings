# H3 八卡频率原始数据

这是 2026-09-09 已完成的同一次 H3 请求采集的原始数据导出，未重新运行请求。
Nsight Systems 2025.3.2 目标采样率为 1000 Hz；NVML 每卡目标轮询率为 10 Hz。
用户示例中的 20000 Hz 未用于这次既有采集。

## 数据文件

- `nsys-gpc-raw.csv`：246,429 行 GPC Clock Frequency 记录。
- `nsys-sys-raw.csv`：246,429 行 SYS Clock Frequency 记录。
- `nvml-frequency.csv`：42,896 行原始 NVML 记录，是原始文件的逐字节副本，含启动与请求过程。
- `metric-device-map.csv`：typeId/metricId、Nsight 设备号、物理卡号、PCI 地址与 UUID 的映射。
- `TARGET_INFO_*.csv`、`source-schema.sql`：原始元数据与表结构。
- `manifest.json`、`SHA256SUMS.txt`：来源、完整性校验和导出验证结果。
- `export-queries.json`、`export_raw_data.py`：精确导出 SQL 与本次导出脚本。

## 原始值与时间戳

两个 Nsight CSV 的列与 GPU_METRICS 表一致：
`rawTimestamp,timestamp,typeId,metricId,value`。
所有采样点都保留；不按 VSA 区间筛选，不计算均值、中位数，不重采样。
`value` 完整保留 SQLite 返回的整数，包括负数，不进行 uint32 或 MHz 换算。
本版本源元数据写的是 `GPC Clock Frequency [MHz]` / `SYS Clock Frequency [MHz]`，此标签也完整保留。
不能把这些未处理的 SQLite 整数直接当成 MHz。
先前报告的分析脚本采用 `(value & 0xffffffff) / 1e6` 得到 MHz；本原始导出不执行这一步。

NVIDIA 文档将 GPC/SYS 对应的平均频率指标说明为 Hz：
https://docs.nvidia.com/nsight-systems/UserGuide/index.html#available-metrics
NVML `nvmlDeviceGetClockInfo` 的返回单位是 MHz：
https://docs.nvidia.com/deploy/nvml-api/group__nvmlDeviceQueries.html
NVML CSV 的 `sm_mhz`、`graphics_mhz`、`memory_mhz` 直接保存该 API 返回的数值；
功耗列在原始采样脚本中已由 mW 除以 1000 保存为 W。
这次采样脚本未读取 VIDEO clock，也未采集 supported clocks 组合。

Nsight `timestamp` 为采集时间线纳秒；`TARGET_INFO_SESSION_START_TIME.csv` 保存 epoch 锚点。
NVML `epoch_ns` 为单卡查询开始的 Unix 纳秒时间，`query_end_epoch_ns` 为查询结束时间；
`monotonic_ns` 也被保留。NVML 顺序轮询八卡，不应假定每行或每卡完全同时采样。
目标采样率不是严格等间隔保证；所有原始时间戳保持原样。

## 原始 Nsight 文件

原生 trace 和完整 SQLite 已存在，未重复装入 CSV 数据包：

- `/lustre/raplab/client/sylarl/minimax-h3-native/results/h3-gpu-frequency-20260909T122900Z/profile/minimax-h3-original-cutedsl-mlp-fp8-bf16-wire-e2e.nsys-rep`
- `/lustre/raplab/client/sylarl/minimax-h3-native/results/h3-gpu-frequency-20260909T122900Z/profile/minimax-h3-original-cutedsl-mlp-fp8-bf16-wire-e2e.sqlite`

可用 Nsight Systems GUI 打开 `.nsys-rep`，按 PCI 地址选择设备，查看 GPU Metrics 下的 GPC/SYS Clock Frequency。
这两个源文件的 SHA256 已写入 manifest。ZIP 包包含本目录的数据、元数据和脚本。
