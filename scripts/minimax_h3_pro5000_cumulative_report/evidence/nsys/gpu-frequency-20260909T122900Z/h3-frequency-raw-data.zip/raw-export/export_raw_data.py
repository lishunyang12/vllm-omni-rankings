"""Export recorded frequency samples without converting or filtering values."""

import csv
import hashlib
import json
import shutil
import sqlite3
import zipfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "raw-export"
OUT.mkdir(exist_ok=False)
SQLITE = next((ROOT / "profile").glob("*.sqlite"))
TRACE = next((ROOT / "profile").glob("*.nsys-rep"))
db = sqlite3.connect(SQLITE.as_uri() + "?mode=ro", uri=True)


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def export_query(filename, query):
    cursor = db.execute(query)
    count = 0
    with (OUT / filename).open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([col[0] for col in cursor.description])
        for row in cursor:
            writer.writerow(row)
            count += 1
    return count


counts = {}
queries = {}
for kind, name in [("gpc", "GPC Clock Frequency"), ("sys", "SYS Clock Frequency")]:
    query = f"""SELECT g.rawTimestamp, g.timestamp, g.typeId, g.metricId, g.value
FROM GPU_METRICS AS g
JOIN TARGET_INFO_GPU_METRICS AS m
  ON g.typeId=m.typeId AND g.metricId=m.metricId
WHERE m.metricName LIKE '{name}%'
ORDER BY g.timestamp, g.typeId, g.rowid"""
    filename = f"nsys-{kind}-raw.csv"
    counts[filename] = export_query(filename, query)
    queries[filename] = query
    # Compare every exported numeric field with a fresh read of the source DB.
    with (OUT / filename).open(newline="") as stream:
        reader = csv.reader(stream)
        next(reader)
        expected = db.execute(query)
        verified = 0
        for source_row in expected:
            assert tuple(map(int, next(reader))) == source_row
            verified += 1
        assert next(reader, None) is None
        assert verified == counts[filename]

for table in ["TARGET_INFO_GPU_METRICS", "TARGET_INFO_GPU", "TARGET_INFO_SESSION_START_TIME"]:
    export_query(table + ".csv", "SELECT * FROM " + table)

inventory = list(csv.DictReader((ROOT / "gpu-inventory.csv").open()))
bus_to_physical = {r[" pci.bus_id"].strip().lower()[-12:]: int(r["index"]) for r in inventory}
targets = {
    row[0]: row[1:]
    for row in db.execute("SELECT id,pwGpuId,busLocation,uuid FROM TARGET_INFO_GPU")
}
metadata = db.execute("""SELECT typeId,metricId,metricName
FROM TARGET_INFO_GPU_METRICS
WHERE metricName LIKE 'GPC Clock Frequency%' OR metricName LIKE 'SYS Clock Frequency%'
ORDER BY typeId,metricId""").fetchall()
with (OUT / "metric-device-map.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(["typeId", "metricId", "metricName", "nsys_device_id", "physical_gpu", "pci_bus_id", "uuid"])
    for tid, mid, name in metadata:
        instance = tid & 255
        pw, bus, uuid = targets[instance]
        assert instance == pw
        writer.writerow([tid, mid, name, instance, bus_to_physical[bus.lower()[-12:]], bus, uuid])

copied = ["nvml-frequency.csv", "gpu-inventory.csv", "measurement-contract.json", "sample_nvml.py", "nsys-frequency-wrapper.sh", "capture-control.csv"]
for name in copied:
    shutil.copyfile(ROOT / name, OUT / name)
    assert digest(ROOT / name) == digest(OUT / name)
shutil.copyfile(Path(__file__), OUT / Path(__file__).name)
with (OUT / "nvml-frequency.csv").open() as stream:
    nvml_rows_per_gpu = Counter(row["physical_gpu"] for row in csv.DictReader(stream))

schema = "\n\n".join(
    db.execute("SELECT sql FROM sqlite_master WHERE name=?", (table,)).fetchone()[0] + ";"
    for table in ["GPU_METRICS", "TARGET_INFO_GPU_METRICS", "TARGET_INFO_GPU", "TARGET_INFO_SESSION_START_TIME"]
)
(OUT / "source-schema.sql").write_text(schema + "\n")
(OUT / "export-queries.json").write_text(json.dumps(queries, indent=2) + "\n")
sources = {
    "source_sqlite": {"path": str(SQLITE), "bytes": SQLITE.stat().st_size, "sha256": digest(SQLITE)},
    "source_nsys_rep": {"path": str(TRACE), "bytes": TRACE.stat().st_size, "sha256": digest(TRACE)},
    "source_nvml": {"path": str(ROOT / "nvml-frequency.csv"), "sha256": digest(ROOT / "nvml-frequency.csv")},
    "nsys_target_sampling_hz": 1000,
    "nvml_target_polling_hz_per_gpu": 10,
    "nsys_exported_rows": counts,
    "nvml_rows_per_gpu": dict(sorted(nvml_rows_per_gpu.items())),
    "raw_export_value_conversion": "none",
    "time_window_filter": "none; all recorded samples",
    "value_verification": "Every Nsight CSV data row compared field-for-field with the source SQLite; copied NVML file SHA256 verified.",
}
(OUT / "manifest.json").write_text(json.dumps(sources, indent=2) + "\n")
nvml_count = sum(nvml_rows_per_gpu.values())
readme = f"""# H3 八卡频率原始数据

这是 2026-09-09 已完成的同一次 H3 请求采集的原始数据导出，未重新运行请求。
Nsight Systems 2025.3.2 目标采样率为 1000 Hz；NVML 每卡目标轮询率为 10 Hz。
用户示例中的 20000 Hz 未用于这次既有采集。

## 数据文件

- `nsys-gpc-raw.csv`：{counts['nsys-gpc-raw.csv']:,} 行 GPC Clock Frequency 记录。
- `nsys-sys-raw.csv`：{counts['nsys-sys-raw.csv']:,} 行 SYS Clock Frequency 记录。
- `nvml-frequency.csv`：{nvml_count:,} 行原始 NVML 记录，是原始文件的逐字节副本，含启动与请求过程。
- `metric-device-map.csv`：typeId/metricId、Nsight 设备号、物理卡号、PCI 地址与 UUID 的映射。
- `TARGET_INFO_*.csv`、`source-schema.sql`：原始元数据与表结构。
- `manifest.json`、`SHA256SUMS.txt`：来源、完整性校验和导出验证结果。
- `export-queries.json`、`export_raw_data.py`：精确导出 SQL 与本次导出脚本。

## 原始值与时间戳

两个 Nsight CSV 的列与 GPU_METRICS 表一致：
`rawTimestamp,timestamp,typeId,metricId,value`。
所有采样点都保留；不按 VSA 区间筛选，不计算均值、中位数，不重采样。
`value` 完整保留 SQLite 返回的整数，包括负数，不进行 uint32 或 MHz 换算。
本版本源元数据写的是 `GPC Clock Frequency [MHz]` / `SYS Clock Frequency [MHz]`，此标签也完整保留。
不能把这些未处理的 SQLite 整数直接当成 MHz。
先前报告的分析脚本采用 `(value & 0xffffffff) / 1e6` 得到 MHz；本原始导出不执行这一步。

NVIDIA 文档将 GPC/SYS 对应的平均频率指标说明为 Hz：
https://docs.nvidia.com/nsight-systems/UserGuide/index.html#available-metrics
NVML `nvmlDeviceGetClockInfo` 的返回单位是 MHz：
https://docs.nvidia.com/deploy/nvml-api/group__nvmlDeviceQueries.html
NVML CSV 的 `sm_mhz`、`graphics_mhz`、`memory_mhz` 直接保存该 API 返回的数值；
功耗列在原始采样脚本中已由 mW 除以 1000 保存为 W。
这次采样脚本未读取 VIDEO clock，也未采集 supported clocks 组合。

Nsight `timestamp` 为采集时间线纳秒；`TARGET_INFO_SESSION_START_TIME.csv` 保存 epoch 锚点。
NVML `epoch_ns` 为单卡查询开始的 Unix 纳秒时间，`query_end_epoch_ns` 为查询结束时间；
`monotonic_ns` 也被保留。NVML 顺序轮询八卡，不应假定每行或每卡完全同时采样。
目标采样率不是严格等间隔保证；所有原始时间戳保持原样。

## 原始 Nsight 文件

原生 trace 和完整 SQLite 已存在，未重复装入 CSV 数据包：

- `{TRACE}`
- `{SQLITE}`

可用 Nsight Systems GUI 打开 `.nsys-rep`，按 PCI 地址选择设备，查看 GPU Metrics 下的 GPC/SYS Clock Frequency。
这两个源文件的 SHA256 已写入 manifest。ZIP 包包含本目录的数据、元数据和脚本。
"""
(OUT / "README.md").write_text(readme)
files = sorted(p for p in OUT.iterdir() if p.is_file())
(OUT / "SHA256SUMS.txt").write_text("".join(f"{digest(p)}  {p.name}\n" for p in files))
archive = ROOT / "h3-frequency-raw-data.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in sorted(OUT.iterdir()):
        if p.is_file():
            z.write(p, arcname="raw-export/" + p.name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
print(json.dumps({"directory": str(OUT), "archive": str(archive), "archive_bytes": archive.stat().st_size, "nsys_rows": counts, "nvml_rows": nvml_count, "verified": True}, indent=2))
