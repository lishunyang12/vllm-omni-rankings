#!/usr/bin/env python3
import csv
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / "cache/matplotlib"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

report = json.loads((ROOT / "quality/comparison.json").read_text())
metrics = report["metrics"]
fig, axes = plt.subplots(2, 2, figsize=(12, 7))
rows = []
for space, color in (("rgb", "#3158a5"), ("yuv", "#c76531")):
    frames = metrics[space]["per_frame"]
    times = [r["frame_index"] / 24 for r in frames]
    axes[0, 0].plot(times, [r["psnr_db"] for r in frames], label=space.upper(), color=color)
    axes[0, 1].plot(times, [r["ssim"] for r in frames], label=space.upper(), color=color)
    for r in frames:
        rows.append({"color_space": space, "frame_index": r["frame_index"], "time_s": r["frame_index"] / 24,
                     "psnr_db": r["psnr_db"], "ssim": r["ssim"], "mse": r["mse"]})
axes[0, 0].set_ylabel("PSNR (dB)")
axes[0, 1].set_ylabel("SSIM")
axes[0, 1].set_ylim(0, 1)
transitions = metrics["temporal"]["per_transition"]
times = [r["to_frame_index"] / 24 for r in transitions]
axes[1, 0].plot(times, [r["reference_luma_temporal_mae"] for r in transitions], label="BF16", color="#3158a5")
axes[1, 0].plot(times, [r["candidate_luma_temporal_mae"] for r in transitions], label="Sage", color="#c76531", alpha=.8)
axes[1, 0].set_ylabel("Frame-to-frame luma MAE (0-255)")
axes[1, 1].plot(times, [r["luma_temporal_derivative_error_mae"] for r in transitions], color="#8d489b")
axes[1, 1].set_ylabel("Temporal derivative difference MAE")
for ax in axes.flat:
    ax.set_xlabel("Video time (s)")
    ax.grid(alpha=.2)
    if ax.get_legend_handles_labels()[0]: ax.legend()
fig.suptitle("Sage PR4691 vs BF16 | aligned frames, same prompt and seed\nPixel and waveform differences are not a perceptual quality acceptance test", fontsize=12)
fig.tight_layout(rect=(0, 0, 1, .93))
fig.savefig(ROOT / "quality/quality-metrics.png", dpi=160)
plt.close(fig)
with (ROOT / "quality/per-frame-metrics.csv").open("w", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
