#!/usr/bin/env python3
"""Export unmodified Nsight clock samples and separately named MHz summaries."""
import argparse
import bisect
import csv
import hashlib
import json
import pathlib
import sqlite3
import statistics

ROOT = pathlib.Path(__file__).resolve().parent


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("sqlite", type=pathlib.Path)
    args = parser.parse_args()
    path = args.sqlite.resolve()
    out = path.parent / "frequency"
    out.mkdir(exist_ok=True)
    db = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
    inventory = list(csv.DictReader((ROOT / "gpu-inventory.csv").open()))
    bus_to_physical = {r[" pci.bus_id"].strip().lower()[-12:]: int(r["index"]) for r in inventory}
    targets = {r[0]: r[1:] for r in db.execute("SELECT id,pwGpuId,busLocation,uuid FROM TARGET_INFO_GPU")}
    # CUPTI device IDs and GPU Metrics instance IDs are separate namespaces.
    # The H3 analyzer resolves CUPTI through kernel PID -> NCCL PCI identity.
    identities = json.loads((path.parent / "analysis/full-request.json").read_text())["per_gpu"]
    cupti_to_physical = {row["gpu"]: row["physical_gpu"] for row in identities}
    assert set(cupti_to_physical.values()) == set(range(8)), "unresolved CUPTI/physical GPU identity"
    vsa_intervals = {i: [] for i in range(8)}
    for device, start, end in db.execute("""SELECT k.deviceId,k.start,k.end
        FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.demangledName
        WHERE lower(s.value) LIKE '%blocksparseattn%' OR lower(s.value) LIKE '%bsa_attn%'
        ORDER BY k.start"""):
        physical = cupti_to_physical[device]
        intervals = vsa_intervals[physical]
        if intervals and start <= intervals[-1][1]:
            intervals[-1][1] = max(end, intervals[-1][1])
        else:
            intervals.append([start, end])
    vsa_starts = {gpu: [start for start, _ in intervals] for gpu, intervals in vsa_intervals.items()}
    metric_rows = db.execute("""SELECT typeId,metricId,metricName FROM TARGET_INFO_GPU_METRICS
        WHERE metricName LIKE 'GPC Clock Frequency%' OR metricName LIKE 'SYS Clock Frequency%'
        ORDER BY typeId,metricId""").fetchall()
    mappings = []
    lookup = {}
    for tid, mid, name in metric_rows:
        instance = tid & 255
        pw, bus, uuid = targets[instance]
        assert instance == pw
        physical = bus_to_physical[bus.lower()[-12:]]
        mappings.append(dict(typeId=tid, metricId=mid, metricName=name, nsys_device_id=instance,
                             physical_gpu=physical, pci_bus_id=bus, uuid=uuid))
        lookup[(tid, mid)] = physical
    with (out / "metric-device-map.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(mappings[0])); writer.writeheader(); writer.writerows(mappings)
    counts = {}
    summaries = []
    queries = {}
    for kind in ("gpc", "sys"):
        query = f"""SELECT g.rawTimestamp,g.timestamp,g.typeId,g.metricId,g.value
            FROM GPU_METRICS g JOIN TARGET_INFO_GPU_METRICS m
            ON g.typeId=m.typeId AND g.metricId=m.metricId
            WHERE m.metricName LIKE '{kind.upper()} Clock Frequency%'
            ORDER BY g.timestamp,g.typeId,g.rowid"""
        queries[kind] = query
        values = {i: [] for i in range(8)}
        timestamps = {i: [] for i in range(8)}
        raw_path = out / f"nsys-{kind}-raw.csv"
        cursor = db.execute(query)
        count = 0
        with raw_path.open("w", newline="") as stream:
            writer = csv.writer(stream); writer.writerow([r[0] for r in cursor.description])
            for row in cursor:
                writer.writerow(row)
                gpu = lookup[(row[2], row[3])]
                assert isinstance(row[4], int)
                values[gpu].append((row[4] & 0xffffffff) / 1e6)
                timestamps[gpu].append(row[1])
                count += 1
        with raw_path.open(newline="") as stream:
            reader = csv.reader(stream); next(reader)
            for expected in db.execute(query):
                assert tuple(map(int, next(reader))) == expected
            assert next(reader, None) is None
        counts[kind] = count
        for gpu, samples in values.items():
            assert samples, f"missing {kind} samples for GPU {gpu}"
            summaries.append(dict(metric=kind, physical_gpu=gpu, window="full_capture",
                                  sample_count=len(samples), max_mhz=max(samples), mean_mhz=statistics.mean(samples),
                                  first_timestamp_ns=min(timestamps[gpu]), last_timestamp_ns=max(timestamps[gpu])))
            selected = []
            selected_times = []
            for t, sample in zip(timestamps[gpu], samples):
                pos = bisect.bisect_right(vsa_starts[gpu], t) - 1
                if pos >= 0 and t < vsa_intervals[gpu][pos][1]:
                    selected.append(sample)
                    selected_times.append(t)
            assert selected, f"missing in-VSA {kind} samples for GPU {gpu}"
            summaries.append(dict(metric=kind, physical_gpu=gpu, window="timestamps_inside_fine_vsa_kernels",
                                  sample_count=len(selected), max_mhz=max(selected), mean_mhz=statistics.mean(selected),
                                  first_timestamp_ns=min(selected_times), last_timestamp_ns=max(selected_times)))
    for table in ("TARGET_INFO_GPU", "TARGET_INFO_GPU_METRICS", "TARGET_INFO_SESSION_START_TIME"):
        cursor = db.execute("SELECT * FROM " + table)
        with (out / (table + ".csv")).open("w", newline="") as stream:
            writer = csv.writer(stream); writer.writerow([r[0] for r in cursor.description]); writer.writerows(cursor)
    with (out / "frequency-summary.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summaries[0])); writer.writeheader(); writer.writerows(summaries)
    (out / "export-queries.json").write_text(json.dumps(queries, indent=2) + "\n")
    (out / "manifest.json").write_text(json.dumps({"source_sqlite": str(path), "sha256": digest(path),
        "target_sampling_hz": 1000, "raw_value_conversion": "none", "exported_rows": counts,
        "verification": "Every raw CSV numeric field compared to a second read of the source database",
        "summary_conversion": "(raw_value & 0xffffffff) / 1e6 MHz; raw CSV retains signed integers",
        "mean_definition": "Arithmetic sample mean, not time-weighted; each CSV row identifies full capture or sample timestamps inside that GPU's fine-VSA kernel intervals"
    }, indent=2) + "\n")
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
