#!/usr/bin/env python3
"""Apply the existing H3 analyzer, with explicit Sage-quantization accounting."""
import argparse
import importlib.util
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "h3_nsys", ROOT / "vllm-omni/tools/minimax_h3/analyze_h3_nsys_step.py"
)
analysis = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = analysis
spec.loader.exec_module(analysis)
original_classify = analysis.classify_kernel
original_wall_phase = analysis._kernel_wall_phase


def classify(name):
    if any(token in name.lower() for token in ("quantize_sage", "sage_kv_stats")):
        return "sage_quantization"
    return original_classify(name)


def wall_phase(category):
    if category == "sage_quantization":
        return category
    return original_wall_phase(category)


analysis.classify_kernel = classify
analysis._kernel_wall_phase = wall_phase
analysis.KERNEL_CATEGORY_DESCRIPTIONS["sage_quantization"] = "Explicit Sage Q/K/V quantization and statistics kernels"
analysis.KERNEL_WALL_PHASE_DESCRIPTIONS["sage_quantization"] = "Explicit Sage Q/K/V quantization and statistics kernels"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dir", type=pathlib.Path)
    args = parser.parse_args()
    run_dir = args.run_dir.resolve()
    report, = run_dir.glob("*.nsys-rep")
    server_log, = run_dir.glob("vllm-*/server.log")
    db = report.with_suffix(".sqlite")
    if not db.exists():
        subprocess.run(["/usr/local/cuda/bin/nsys", "export", "--type=sqlite", "--quiet=true",
                        f"--output={db}", str(report)], check=True)
    out = run_dir / "analysis"
    out.mkdir(exist_ok=True)
    for label, scope in (("full-request", "none"), ("step03", "minimax_h3.denoise.step_03")):
        result = analysis.analyze_sqlite(db, requested_range=scope, server_log=server_log, top=30)
        (out / (label + ".json")).write_text(json.dumps(result, indent=2) + "\n")
        (out / (label + ".md")).write_text(analysis.render_markdown(result, source=report))
        print(f"Wrote {label} analysis", flush=True)
    subprocess.run(["/usr/local/cuda/bin/nsys", "stats", "--report=cuda_gpu_kern_sum,cuda_gpu_mem_time_sum,cuda_api_sum,nvtx_sum",
                    "--format=csv", str(db)], check=True, stdout=(out / "canonical-nsys-stats.csv").open("w"))
    subprocess.run([sys.executable, str(ROOT / "export_frequency.py"), str(db)], check=True,
                   stdout=(out / "frequency-summary.log").open("w"))


if __name__ == "__main__":
    main()
