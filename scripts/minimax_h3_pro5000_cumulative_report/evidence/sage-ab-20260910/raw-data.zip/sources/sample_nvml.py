import csv
import signal
import sys
import time
import pynvml as nv

running = True

def stop(*_):
    global running
    running = False

signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)
nv.nvmlInit()
devices = [nv.nvmlDeviceGetHandleByIndex(i) for i in range(nv.nvmlDeviceGetCount())]
assert len(devices) == 8

def safe(fn, *args):
    try:
        value = fn(*args)
        return value.decode() if isinstance(value, bytes) else value
    except nv.NVMLError:
        return ''

with open(sys.argv[1], 'w', buffering=1) as file:
    out = csv.writer(file)
    out.writerow(['epoch_ns', 'monotonic_ns', 'query_end_epoch_ns', 'physical_gpu', 'uuid', 'pci_bus_id', 'sm_mhz', 'graphics_mhz', 'memory_mhz', 'pstate', 'gpu_util_pct', 'memory_util_pct', 'power_w', 'power_limit_w', 'temperature_c', 'clock_event_reasons'])
    identities = [(safe(nv.nvmlDeviceGetUUID, d), nv.nvmlDeviceGetPciInfo(d).busId) for d in devices]
    while running:
        deadline = time.monotonic() + .1
        for i, d in enumerate(devices):
            begin, mono = time.time_ns(), time.monotonic_ns()
            util = nv.nvmlDeviceGetUtilizationRates(d)
            values = [safe(nv.nvmlDeviceGetClockInfo, d, clock) for clock in (nv.NVML_CLOCK_SM, nv.NVML_CLOCK_GRAPHICS, nv.NVML_CLOCK_MEM)]
            values += [safe(nv.nvmlDeviceGetPerformanceState, d), util.gpu, util.memory, nv.nvmlDeviceGetPowerUsage(d) / 1000, nv.nvmlDeviceGetEnforcedPowerLimit(d) / 1000, safe(nv.nvmlDeviceGetTemperature, d, nv.NVML_TEMPERATURE_GPU), safe(nv.nvmlDeviceGetCurrentClocksEventReasons, d)]
            uuid, bus = identities[i]
            if isinstance(bus, bytes):
                bus = bus.decode()
            out.writerow([begin, mono, time.time_ns(), i, uuid, bus, *values])
        time.sleep(max(0, deadline - time.monotonic()))
nv.nvmlShutdown()
