#!/usr/bin/env python3
import difflib
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "deliverables"


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def copy(src, relative):
    dst = OUT / relative
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    assert digest(src) == digest(dst)


def main():
    assert (ROOT / "nvml-sampler-stopped.json").exists(), "Stop and flush the NVML sampler first"
    OUT.mkdir(exist_ok=True)
    identities = []
    for mode, label in (("bf16", "BF16"), ("pr4691", "Sage-PR4691")):
        normal = json.loads((ROOT / f"{mode}-normal-summary.json").read_text())
        copy(Path(normal["runs"][0]["mp4"]), label+".mp4")
        run = ROOT / "runs" / f"{mode}-nsys"
        report, = run.glob("*.nsys-rep")
        copy(report, label+"-warmed.nsys-rep")
        video, = run.glob("vllm-*/out_t2va1.mp4")
        same = digest(video) == normal["runs"][0]["sha256"]
        identities.append({"mode":mode, "nsys_video_sha256":digest(video), "same_as_normal_video":same})
        if not same:
            copy(video, label+"-nsys.mp4")
        for p in (run / "analysis").glob("*"):
            if p.is_file(): copy(p, Path("analysis") / mode / p.name)
    (OUT / "video-trace-identities.json").write_text(json.dumps(identities,indent=2)+"\n")
    for folder in ("summary", "quality"):
        for p in (ROOT / folder).iterdir():
            if p.is_file(): copy(p, Path(folder) / p.name)
    for name in ("pr4951-assessment.md", "pr4951-compatibility.json"):
        copy(ROOT / name, name)
    make_raw_archive()
    files = [{"path":str(p.relative_to(OUT)), "bytes":p.stat().st_size, "sha256":digest(p)}
             for p in sorted(OUT.rglob("*")) if p.is_file() and p.name not in ("manifest.json", "SHA256SUMS.txt")]
    (OUT / "manifest.json").write_text(json.dumps({"experiment":"H3 VSA 4-step BF16 vs PR4691 Sage",
        "pr4691_head":"e0526bbe9180b0b65b513faa32ab255e078d8bcb",
        "pr4951_head":"30751b2ef15776ea00256e9ba979364a1ecf39a3",
        "files":files},indent=2)+"\n")
    (OUT / "SHA256SUMS.txt").write_text("".join(f"{r['sha256']}  {r['path']}\n" for r in files))
    print(json.dumps({"files":len(files), "bytes":sum(r['bytes'] for r in files), "video_trace_identity":identities},indent=2))


def make_raw_archive():
    original = ROOT.parents[1] / "vllm-omni-h3-dlo-latest/vllm-omni/vllm_omni/diffusion/attention/backends/fastvideo_vsa.py"
    candidate = ROOT / "vllm-omni/vllm_omni/diffusion/attention/backends/fastvideo_vsa.py"
    patch = "".join(difflib.unified_diff(original.read_text().splitlines(True), candidate.read_text().splitlines(True),
        fromfile="a/vllm_omni/diffusion/attention/backends/fastvideo_vsa.py",
        tofile="b/vllm_omni/diffusion/attention/backends/fastvideo_vsa.py"))
    assert "VLLM_OMNI_H3_VSA_SAGE" in patch and len(patch.splitlines()) < 100
    (ROOT / "vllm-sage-adapter.patch").write_text(patch)
    sources = ["run_case.sh", "run_remaining.sh", "nsys_with_metrics.sh", "sample_nvml.py",
        "analyze_run.py", "export_frequency.py", "qualify_sage_h3.py", "summarize_results.py",
        "render_comparison_frames.py", "render_quality_metrics.py", "render_report.py", "report-methodology.md", "package_results.py",
        "vllm-sage-adapter.patch", "pr4691-source.json", "pr4951-source.json", "pr4951-compatibility.json",
        "pr4691-tests.log", "h3-shape-qualification.json", "source-snapshot.json", "rdma-artifact.json",
        "benchmark-source.json", "bf16-normal-summary.json", "pr4691-normal-summary.json",
        "stage-timing-results.json", "video-identities-pre-nsys.json"]
    files = [(ROOT / name, name) for name in ("nvml-frequency.csv", "gpu-inventory.csv", "prompt.txt", "nvml-sampler-stopped.json")]
    files += [(ROOT / name, "sources/"+name) for name in sources]
    for mode in ("bf16", "pr4691"):
        run = ROOT / "runs" / f"{mode}-nsys"
        files += [(p, f"frequency/{mode}/"+str(p.relative_to(run / "frequency"))) for p in (run / "frequency").rglob("*") if p.is_file()]
        files += [(p, f"analysis/{mode}/"+str(p.relative_to(run / "analysis"))) for p in (run / "analysis").rglob("*") if p.is_file()]
        for kind in ("normal", "stages", "nsys"):
            run = ROOT / "runs" / f"{mode}-{kind}"
            for p in run.rglob("*"):
                if not p.is_file() or p.suffix not in (".txt", ".json", ".tsv", ".log", ".csv", ".sha256"):
                    continue
                if p.is_relative_to(run / "analysis") or p.is_relative_to(run / "frequency"):
                    continue
                files.append((p, f"runs/{mode}-{kind}/"+str(p.relative_to(run))))
    receipt = [{"path":relative, "bytes":p.stat().st_size, "sha256":digest(p)} for p, relative in files]
    archive = OUT / "raw-data.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p, relative in files:
            z.write(p, relative)
        z.writestr("manifest.json", json.dumps({"files":receipt}, indent=2)+"\n")
        z.writestr("README.txt", "Raw H3 BF16 / Sage A-B evidence. See the adjacent README.md for the full measurement contract.\n"
            "Frequency raw CSV preserves signed database values. Derived summaries are separate.\n"
            "Native .nsys-rep files and complete videos are supplied separately. No model weights or runtime caches are included.\n"
            "Run configurations identify the original workspace sources; the small adapter patch selects Sage at the existing fine-attention boundary.\n")
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None


if __name__ == "__main__":
    main()
