#!/usr/bin/env python3
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "deliverables"
OUT.mkdir(exist_ok=True)


def rows(name):
    return list(csv.DictReader((ROOT / "summary" / name).open()))


def table(headers, data):
    return "\n".join(["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"] +
                     ["| " + " | ".join(map(str, row)) + " |" for row in data])


def main():
    comparisons = json.loads((ROOT / "summary/comparisons.json").read_text())
    latency = []
    for label, key in (("正常端到端（无 profiler）", "normal"), ("DiT（分阶段计时，无 Nsight）", "dit_untraced_stage_profiler")):
        c = comparisons[key]
        latency.append([label, f"{c['bf16_s']:.3f}", f"{c['sage_s']:.3f}", f"{c['latency_reduction_percent']:.2f}%"])
    stage_table = table(["阶段", "BF16 秒", "Sage 秒", "BF16 占比", "Sage 占比", "变化 pp"], [
        [r['stage'], f"{float(r['bf16_s']):.3f}", f"{float(r['sage_s']):.3f}",
         f"{float(r['bf16_share_percent']):.2f}%", f"{float(r['sage_share_percent']):.2f}%",
         f"{float(r['share_delta_percentage_points']):+.2f}"] for r in rows("stage-share-changes.csv")])
    phase_table = table(["GPU 7，第 3 步", "BF16 秒", "Sage 秒", "BF16 占比", "Sage 占比", "变化 pp"], [
        [r['phase'], f"{float(r['bf16_s']):.3f}", f"{float(r['sage_s']):.3f}",
         f"{float(r['bf16_share_percent']):.2f}%", f"{float(r['sage_share_percent']):.2f}%",
         f"{float(r['share_delta_percentage_points']):+.2f}"] for r in rows("nsys-step03-phase-changes-gpu7.csv")])
    clocks = {(r['mode'], int(r['physical_gpu'])): r for r in rows("gpc-vsa-max-mean.csv")}
    clock_table = table(["物理 GPU", "BF16 GPC max MHz", "BF16 mean MHz", "Sage GPC max MHz", "Sage mean MHz"], [
        [gpu] + [f"{float(clocks[(mode, gpu)][field]):.2f}" for mode in ('bf16','pr4691') for field in ('max_mhz','mean_mhz')]
        for gpu in range(8)])
    text = "# H3 VSA + 4-step：BF16 vs Sage PR #4691\n\n"
    text += "固定同一 prompt、seed 1101、8 卡和稀疏配置。Sage 有耗时收益，但此次 DiT 降幅未达到预期 15%；输出有可见变化。\n\n"
    text += table(["测量", "BF16 秒", "Sage 秒", "耗时下降"], latency) + "\n\n"
    text += "每组先预热一次，再测三次。正常请求与分阶段计时分别运行；Nsight 另行采集，不能用 trace 用时代替正常延迟。\n\n"
    text += "## 视频、原始 Nsight 与数据\n\n"
    text += "- 完整视频：[BF16](BF16.mp4)、[Sage PR4691](Sage-PR4691.mp4)。\n"
    text += "- 原生 trace：[BF16](BF16-warmed.nsys-rep)、[Sage PR4691](Sage-PR4691-warmed.nsys-rep)。\n"
    text += "- [原始数据和日志 ZIP](raw-data.zip)、[汇总 CSV](summary/latency-summary.csv)、[来源和校验](manifest.json)。\n\n"
    text += "## 阶段耗时与占比\n\n" + stage_table + "\n\n"
    text += "分母为分阶段计时运行的完整请求 E2E；这些顶层项组成完整请求。视频/音频 VAE 是 Decode 子项，另见 [解码明细](summary/decode-components.csv)，不要重复相加。\n\n"
    text += "## Nsight 中第 3 步的耗时分布\n\n" + phase_table + "\n\n"
    text += "这是物理 GPU 7 的不重叠时间区间划分；跨类别并发记为 concurrent_mixed，空闲记为 idle，总和为该步时长。没有跨 GPU 求和。vsa 表示可识别的精细 block-sparse/index kernel；量化和布局另列。GEMM 按 kernel 名分类，不声称每个 GEMM 都属于线性层。RDMA barrier 是驻留/等待时间，不等于可全部消除的通信开销。\n\n"
    phases = {r['phase']: r for r in rows("nsys-step03-phase-changes-gpu7.csv")}
    vsa_before, vsa_after = (float(phases['vsa'][f'{mode}_s']) for mode in ('bf16', 'sage'))
    layout_extra = float(phases['layout_copy']['sage_s']) - float(phases['layout_copy']['bf16_s'])
    text += (f"这一 GPU 的精细 VSA kernel 耗时下降 {100*(1-vsa_after/vsa_before):.2f}%，"
             f"但每步新增量化 {float(phases['sage_quantization']['sage_s']):.3f} 秒、布局开销增加 {layout_extra:.3f} 秒；"
             "GEMM 仍约 2.670 秒。这解释了 kernel 收益没有等比例转化为整个 DiT 的收益。\n\n")
    text += "[全部八卡占比 CSV](summary/nsys-step03-phase-changes-all-gpus.csv) · [精细 VSA kernel 次数/均值/最大值](summary/nsys-fine-vsa-kernel-per-gpu.csv)\n\n"
    text += "## 运行中 GPC 频率\n\n" + clock_table + "\n\n"
    text += "GPU Metrics 目标 1000 Hz。此表仅选择时间戳落在对应 GPU 精细 VSA kernel 区间内的采样点；mean 为采样点算术均值。完整采集窗口和 SYS 数据见 [频率汇总](summary/frequency-summary-all.csv)。NVML 目标每卡 10 Hz，保留完整原始时间戳。\n\n"
    text += "本实验没有锁定频率，部分 GPU 在 Sage 下频率更高，因此这些结果属于节点默认动态频率下的实测。GPU 7 两组的 GPC 均值接近（1948.48 / 1948.38 MHz），可结合上面的该卡耗时分解评估变化。\n\n"
    text += quality_and_methodology()
    (OUT / "README.md").write_text(text)


def quality_and_methodology():
    return (ROOT / "report-methodology.md").read_text()


if __name__ == "__main__":
    main()
