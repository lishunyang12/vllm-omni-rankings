#!/usr/bin/env python3
"""Compare unchanged H3 sparse metadata across BF16 and pinned PR4691 Sage."""
import importlib.util
import json
import pathlib
import statistics
import subprocess
import sys
import time

import torch

ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "flashinfer"))
spec = importlib.util.spec_from_file_location(
    "h3_geometry", ROOT / "vllm-omni/tools/minimax_h3/benchmark_h3_vsa_exact_shape_matrix_sm120.py"
)
geo = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = geo
spec.loader.exec_module(geo)
from flashinfer.cute_dsl.sparse.bsa_attn_sm120 import (
    bsa_attn_sm120_blk64_fwd as bf16,
    bsa_attn_sm120_blk64_sage_fwd as sage,
)
from flashinfer.cute_dsl.sparse.bsa_utils.sage_quant_sm120 import quantize_sage_qkv_sm120


def error(ref, out, sizes):
    valid = (torch.arange(64, device=sizes.device)[None] < sizes[:, None]).flatten()
    ref, out = ref[:, valid].float().flatten(), out[:, valid].float().flatten()
    diff = out - ref
    return {
        "finite": bool(out.isfinite().all()),
        "max_abs": float(diff.abs().max()),
        "mean_abs": float(diff.abs().mean()),
        "relative_l2": float(diff.norm() / ref.norm()),
        "cosine": float(torch.nn.functional.cosine_similarity(ref[None], out[None])),
    }


def run(case):
    geometry = geo.case_geometry(case)
    q, k, v, sizes = geo.make_inputs(case, geometry, torch.device("cuda:0"), 1101)
    idx, nums = geo.make_q2k(q, k, sizes, geometry)
    geo.validate_metadata(idx, nums, sizes, geometry)
    kwargs = dict(block_sizes=sizes, q2k_block_nums=nums, softmax_scale=128**-0.5)
    def baseline():
        return bf16(q, k, v, idx, idx.shape[-1], return_lse=False, **kwargs)[0]
    def full_sage():
        packed = [t.transpose(1, 2).contiguous() for t in (q, k, v)]
        quant = quantize_sage_qkv_sm120(*packed)
        return sage(*quant, idx, idx.shape[-1], **kwargs).transpose(1, 2).contiguous()
    quant = quantize_sage_qkv_sm120(*[t.transpose(1, 2).contiguous() for t in (q, k, v)])
    def prequantized_sage():
        return sage(*quant, idx, idx.shape[-1], **kwargs)
    ref = baseline()
    out = full_sage()
    metrics = error(ref, out, sizes)
    if not metrics["finite"]:
        raise RuntimeError(f"{case.name}: non-finite Sage output")
    funcs = {"bf16_provider": baseline, "sage_provider_including_layout_quantization": full_sage,
             "sage_prequantized_kernel": prequantized_sage}
    for fn in funcs.values():
        for _ in range(3): fn()
    torch.cuda.synchronize()
    samples = {name: [] for name in funcs}
    clocks = []
    for iteration in range(9):
        clocks.append(subprocess.check_output([
            "nvidia-smi", "--query-gpu=index,clocks.current.sm,power.draw,temperature.gpu",
            "--format=csv,noheader,nounits", "-i", "0"
        ], text=True).strip())
        names = list(funcs)
        if iteration % 2: names.reverse()
        for name in names:
            start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            start.record()
            for _ in range(5): funcs[name]()
            end.record(); end.synchronize()
            samples[name].append(start.elapsed_time(end) / 5)
    summary = {name: {"samples_ms": values, "mean_ms": statistics.mean(values),
                     "median_ms": statistics.median(values)} for name, values in samples.items()}
    result = {"case": case.name, "geometry": geometry, "errors_vs_bf16_valid_rows": metrics,
              "timing": summary, "clock_snapshots": clocks,
              "provider_speedup": summary["bf16_provider"]["mean_ms"] / summary["sage_provider_including_layout_quantization"]["mean_ms"]}
    print(json.dumps(result), flush=True)
    return result


if __name__ == "__main__":
    torch.cuda.set_device(0)
    cases = geo.preset_cases("smoke") + [c for c in geo.preset_cases("core") if c.name == "h3_720p_15s_landscape"]
    results = []
    for case in cases:
        results.append(run(case))
        (ROOT / "h3-shape-qualification.json").write_text(json.dumps({"results": results}, indent=2) + "\n")
        torch.cuda.empty_cache()
