#!/usr/bin/env bash
set -euo pipefail
EXPERIMENT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
for kind in stages nsys; do
  for mode in bf16 pr4691; do
    printf 'Starting %s %s at %s\n' "$mode" "$kind" "$(date -u +%FT%TZ)"
    bash "$EXPERIMENT_DIR/run_case.sh" "$mode" "$kind" >"$EXPERIMENT_DIR/$mode-$kind.log" 2>&1
    printf 'Completed %s %s at %s\n' "$mode" "$kind" "$(date -u +%FT%TZ)"
  done
done
