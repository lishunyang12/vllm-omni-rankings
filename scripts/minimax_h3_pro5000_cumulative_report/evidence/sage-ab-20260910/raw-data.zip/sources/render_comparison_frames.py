#!/usr/bin/env python3
"""Fixed timestamp frame comparison; the complete MP4s remain the quality evidence."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / "cache/matplotlib"))
import av
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

case = "vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct"
indices = [24, 120, 240, 348]
fig, axes = plt.subplots(len(indices), 2, figsize=(15, 17))
for column, mode in enumerate(("bf16", "pr4691")):
    path = ROOT / "runs" / f"{mode}-normal" / case / "out_t2va1-repeat-1.mp4"
    with av.open(str(path)) as container:
        for index, frame in enumerate(container.decode(video=0)):
            if index not in indices:
                continue
            row = indices.index(index)
            ax = axes[row, column]
            ax.imshow(frame.to_ndarray(format="rgb24"))
            ax.set_title(f"{'BF16 VSA' if column == 0 else 'Sage PR4691'} | {index / 24:.1f} s", fontsize=15)
            ax.axis("off")
            if index == indices[-1]:
                break
fig.suptitle("H3 VSA + 4 steps | same prompt / seed 1101 | full H3 VAE", fontsize=17)
fig.tight_layout(rect=(0, 0, 1, 0.98))
(ROOT / "quality").mkdir(exist_ok=True)
fig.savefig(ROOT / "quality/comparison-frames.png", dpi=130)
plt.close(fig)
