#!/usr/bin/env python3
"""Build visible A/B tables from completed, validated runs."""
import csv
import json
import sqlite3
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "summary"
OUT.mkdir(exist_ok=True)
MODES = ("bf16", "pr4691")


def write_csv(name, rows):
    with (OUT / name).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def change(a, b):
    return {"bf16_s": a, "sage_s": b, "delta_s": b-a,
            "latency_reduction_percent": 100*(a-b)/a if a else None,
            "speedup": a/b if b else None}


def main():
    runs = {}
    request_rows = []
    for kind in ("normal", "stages", "nsys"):
        for mode in MODES:
            run_dir = ROOT / "runs" / f"{mode}-{kind}"
            rows = list(csv.DictReader((run_dir / "summary.tsv").open(), delimiter="\t"))
            assert len(rows) == 1 and rows[0]["status"] == "ok", (mode, kind, rows)
            row = rows[0]
            case_dir = run_dir / row["case"]
            count = 1 if kind == "nsys" else 3
            times = [float((case_dir / f"measured-{i}-e2e-seconds.txt").read_text()) for i in range(1, count+1)]
            runs[(mode, kind)] = row
            request_rows.append({"mode": mode, "measurement": kind, "repeats": count,
                "e2e_mean_s": statistics.mean(times), "e2e_median_s": statistics.median(times),
                "e2e_min_s": min(times), "e2e_max_s": max(times),
                "dit_mean_s": row["dit_s"], "decode_mean_s": row["decode_total_s"],
                "samples_s": json.dumps(times)})
    write_csv("latency-summary.csv", request_rows)
    stage_rows = []
    a, b = (runs[(mode, "stages")] for mode in MODES)
    residuals = {mode: float(row["e2e_s"]) - sum(float(row[field]) for field in ("encoder_s", "dit_s", "decode_total_s"))
                 for mode, row in zip(MODES, (a, b))}
    for label, field in (("Encoder", "encoder_s"), ("DiT", "dit_s"), ("Decode total", "decode_total_s"),
                         ("Outside encoder/DiT/decode", None)):
        va, vb = (float(row[field]) if field else residuals[mode] for mode, row in zip(MODES, (a, b)))
        pa, pb = 100*va/float(a["e2e_s"]), 100*vb/float(b["e2e_s"])
        stage_rows.append({"stage": label, **change(va, vb), "bf16_share_percent": pa,
                           "sage_share_percent": pb, "share_delta_percentage_points": pb-pa})
    write_csv("stage-share-changes.csv", stage_rows)
    decode_rows = [{"component": name, **change(float(a[field]), float(b[field]))} for name, field in
                   (("Video VAE path (within decode)", "video_vae_path_s"), ("Audio VAE (within decode)", "audio_vae_s"))]
    write_csv("decode-components.csv", decode_rows)
    comparisons = {kind: change(float(runs[("bf16", kind)]["e2e_s"]), float(runs[("pr4691", kind)]["e2e_s"]))
                   for kind in ("normal", "stages", "nsys")}
    comparisons["dit_untraced_stage_profiler"] = change(float(a["dit_s"]), float(b["dit_s"]))
    (OUT / "comparisons.json").write_text(json.dumps(comparisons, indent=2) + "\n")
    summarize_nsys()


def summarize_nsys():
    traces = {mode: json.loads((ROOT / "runs" / f"{mode}-nsys/analysis/step03.json").read_text()) for mode in MODES}
    phase_maps = {}
    for mode, result in traces.items():
        identities = {row["gpu"]: row["physical_gpu"] for row in result["per_gpu"]}
        assert set(identities.values()) == set(range(8)), identities
        phase_maps[mode] = {identities[row["gpu"]]: row for row in result["kernel_phase_wall"]["per_device"]}
    phase_rows = []
    for gpu in range(8):
        a, b = (phase_maps[mode][gpu] for mode in MODES)
        assert a["accounting_error_ns"] == b["accounting_error_ns"] == 0
        for phase in a["phase_wall_ms"]:
            va, vb = (row["phase_wall_ms"][phase]/1000 for row in (a, b))
            pa, pb = (row["phase_percent_of_scope_wall"][phase] for row in (a, b))
            phase_rows.append({"physical_gpu": gpu, "phase": phase, **change(va, vb),
                               "bf16_share_percent": pa, "sage_share_percent": pb,
                               "share_delta_percentage_points": pb-pa})
    write_csv("nsys-step03-phase-changes-all-gpus.csv", phase_rows)
    write_csv("nsys-step03-phase-changes-gpu7.csv", [r for r in phase_rows if r["physical_gpu"] == 7])
    kernel_rows, frequency_rows = [], []
    for mode in MODES:
        run_dir = ROOT / "runs" / f"{mode}-nsys"
        full = json.loads((run_dir / "analysis/full-request.json").read_text())
        identity = {r["gpu"]: r["physical_gpu"] for r in full["per_gpu"]}
        db_path, = run_dir.glob("*.sqlite")
        db = sqlite3.connect(db_path.as_uri()+"?mode=ro", uri=True)
        for device, count, total, avg, maximum in db.execute("""SELECT k.deviceId,COUNT(*),SUM(k.end-k.start),AVG(k.end-k.start),MAX(k.end-k.start)
            FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.demangledName
            WHERE lower(s.value) LIKE '%blocksparseattn%' OR lower(s.value) LIKE '%bsa_attn%'
            GROUP BY k.deviceId"""):
            assert count == 200, (mode, device, count)
            kernel_rows.append({"mode": mode, "physical_gpu": identity[device], "fine_kernel_calls": count,
                                "total_ms": total/1e6, "mean_ms": avg/1e6, "max_ms": maximum/1e6})
        db.close()
        with (run_dir / "frequency/frequency-summary.csv").open() as stream:
            frequency_rows.extend({"mode": mode, **r} for r in csv.DictReader(stream))
    write_csv("nsys-fine-vsa-kernel-per-gpu.csv", sorted(kernel_rows, key=lambda r: (r["mode"], r["physical_gpu"])))
    write_csv("frequency-summary-all.csv", frequency_rows)
    write_csv("gpc-vsa-max-mean.csv", [r for r in frequency_rows if r["metric"] == "gpc" and r["window"] == "timestamps_inside_fine_vsa_kernels"])
    metrics = json.loads((ROOT / "quality/comparison.json").read_text())["metrics"]
    quality_rows = []
    for space in ("rgb", "yuv"):
        summary = metrics[space]["summary"]
        quality_rows.extend([
            {"metric": f"{space}_global_psnr_db", "value": summary["global_psnr_from_mean_mse_db"]},
            {"metric": f"{space}_mean_frame_ssim", "value": summary["per_frame_ssim"]["mean"]},
        ])
    quality_rows.append({"metric": "audio_pcm_snr_db", "value": metrics["audio"]["overlap_snr_db"]})
    quality_rows.append({"metric": "audio_pcm_identical", "value": metrics["audio"]["pcm_bitwise_identical"]})
    write_csv("quality-summary.csv", quality_rows)


if __name__ == "__main__":
    main()
