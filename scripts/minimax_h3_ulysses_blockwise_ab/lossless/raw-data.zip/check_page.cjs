process.env.PLAYWRIGHT_BROWSERS_PATH ||= '/tmp/h3-page-browser/browsers';
process.env.FONTCONFIG_FILE ||= '/tmp/h3-page-browser/fonts.conf';
const {chromium}=require('/tmp/h3-page-browser/node_modules/playwright');
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path');
(async()=>{
 const [base,out]=process.argv.slice(2);assert(base&&out);fs.mkdirSync(path.dirname(out),{recursive:true});
 const browser=await chromium.launch({headless:true,args:['--no-sandbox','--disable-gpu']});
 const page=await browser.newPage({viewport:{width:1440,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 const response=await page.goto(base,{waitUntil:'networkidle'});assert.equal(response.status(),200);
 await page.waitForFunction(()=>[...document.querySelectorAll('video')].length===2&&[...document.querySelectorAll('video')].every(v=>v.readyState>=1&&v.videoWidth===1280&&v.videoHeight===704));
 assert.equal(await page.locator('#lossless-latencies tbody tr').count(),2);
 await page.locator('[data-seek="4.5"]').click();await page.waitForFunction(()=>[...document.querySelectorAll('video')].every(v=>Math.abs(v.currentTime-4.5)<.02&&!v.seeking));
 await page.locator('#play').click();await page.waitForFunction(()=>[...document.querySelectorAll('video')].every(v=>!v.paused&&v.currentTime>5));await page.locator('#pause').click();
 const playback=await page.locator('video').evaluateAll(vs=>vs.map(v=>({time:v.currentTime,paused:v.paused,muted:v.muted,duration:v.duration})));
 assert(playback.every(v=>v.paused&&v.duration>15));assert.deepEqual(playback.map(v=>v.muted),[false,true]);assert(Math.abs(playback[0].time-playback[1].time)<.2);
 await page.locator('[data-seek="1"]').click();await page.waitForFunction(()=>[...document.querySelectorAll('video')].every(v=>!v.seeking));await page.evaluate(()=>scrollTo(0,0));
 await page.screenshot({path:out+'-desktop.png',fullPage:true});await page.screenshot({path:out+'-desktop-top.png'});
 await page.setViewportSize({width:390,height:844});await page.waitForTimeout(200);
 assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));await page.evaluate(()=>scrollTo(0,0));await page.screenshot({path:out+'-mobile.png',fullPage:true});await page.screenshot({path:out+'-mobile-top.png'});
 const urls=await page.locator('a[href]').evaluateAll(as=>[...new Set(as.map(a=>a.href))]);const links=[];
 for(const url of urls){if(!url.startsWith(new URL(base).origin))continue;const res=await page.request.head(url);links.push({url,status:res.status()})}
 assert(links.every(v=>v.status===200));assert.deepEqual(errors,[]);
 const result={status:'passed',base,at:new Date().toISOString(),playback,links,page_errors:errors};fs.writeFileSync(out+'.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
