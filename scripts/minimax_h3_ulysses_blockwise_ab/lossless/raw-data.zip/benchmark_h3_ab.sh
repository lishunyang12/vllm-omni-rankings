#!/usr/bin/env bash
set -Eeuo pipefail

# Communication-first MiniMax-H3 benchmark for 8x RTX PRO 5000 Blackwell.
#
# Base-H3 cases use the original BF16 FL2VA checkpoint. The one explicitly
# named dense FastH3 case fuses the pinned Dense/Data-Free student at load
# time.  The two VSA actions instead fuse the pinned VSA/Data-Free student and
# differ only in the tile-64 compute provider.  No action uses approximate DiT
# caching.
#
# Actions:
#   comm-ab            TP2 x SP4 regular A2A vs fused permute-free A2A
#   tp2-sp4-regular    Original communication baseline
#   tp2-sp4-lsa        Same baseline with fused Ulysses A2A
#   tp2-sp4-adaln-lsa  Exact AdaLN sidecar plus fused Ulysses A2A
#   tp1-sp8-adaln-lsa  Same combination on SP8; requires an explicit, current-
#                       code SP8 symmetric-memory smoke-test gate
#   tp1-sp8-adaln-rdma Exact AdaLN sidecar plus FlashInfer PR #4876 all-RDMA
#   tp1-sp8-adaln-rdma-qk-direct
#                       Same all-RDMA path with fused Q/K producers writing
#                       directly into the registered NIC landing buffers
#   tp1-sp8-fasth3-dense-adaln-rdma-qk-direct
#                       Dense/Data-Free FastH3 fused student: four DiT
#                       forwards, exact adapter-bound AdaLN sidecar, SP8,
#                       FlashInfer all-RDMA, direct Q/K producers, and qchunk2
#   vllm-omni-tp1-sp8-fasth3-vsa-fastvideo-topk162-nccl
#                       VSA/Data-Free FastH3, four DiT forwards, exact
#                       adapter-bound AdaLN sidecar, TP1/SP8, Qwen TP8,
#                       ordinary NCCL Ulysses, official FastVideo tile-64
#                       compute, top-k 162, and qchunk disabled
#   vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-nccl
#                       Identical request/model/mask/communication contract;
#                       only the VSA compute provider changes to FlashInfer
#                       PR #4944 SM120 CuTeDSL
#   vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct
#                       Cumulative lane: PR #4944 VSA plus PR #4876 all-RDMA
#                       Ulysses, direct Q/K/O producers, fused tile layout,
#                       and direct ordered q2k metadata; qchunk disabled
#                       VLLM_OMNI_MINIMAX_H3_FP8_SCOPE optionally adds one
#                       transformer-only online-FP8 qualification rung:
#                       mlp, mlp-out, mlp-out-qkv, or all-main. The default is
#                       none and every non-main DiT linear stays BF16.
#   ...-rdma-qk-direct-mlp-out-fp8
#                       Formal compute-only MLP+attention-output E4M3 rung:
#                       exactly 50 fc1, 50 fc2, and 50 attention out_proj;
#                       QKV and VSA gate compute/wire values stay BF16.
#   ...-rdma-qk-direct-qkv-calibration-mlp-out-fp8
#                       Fresh BF16-wire QKV calibration bound to the exact
#                       formal mlp-out scope/mode/config/contract identity.
#   ...-rdma-qk-direct-qkv-validation-mlp-out-fp8
#                       Fresh validation of derived QKV scales under that same
#                       mlp-out identity; never publishes a final sidecar.
#   ...-rdma-qk-direct-qkv-e4m3-mlp-out-fp8
#                       Formal cumulative mlp-out plus bound E4M3 QKV wire rung.
#   ...-rdma-qk-direct-mlp-out-qkv-fp8
#                       Formal compute-only MLP+out+fused-QKV E4M3 rung:
#                       exactly 200 main-block linears. QKV projection output
#                       and wire stay BF16; VSA to_gate_compress stays BF16.
#   ...-rdma-qk-direct-qkv-calibration-mlp-out-qkv-fp8
#                       Fresh BF16-wire QKV calibration bound to the exact
#                       formal mlp-out-qkv scope/mode/config/contract identity.
#   ...-rdma-qk-direct-qkv-validation-mlp-out-qkv-fp8
#                       Fresh scale validation under that same identity.
#   ...-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8
#                       Formal cumulative mlp-out-qkv compute plus independently
#                       bound E4M3 QKV Ulysses wire transport.
#   ...-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp32
#                       Validated cumulative output rung: the exact preceding
#                       compute/communication stack plus reverse-O bundling and
#                       pinned TAEH3 FP32 temporal chunk-5 decode into the
#                       two-slot CPU libx264 MP4 sink. NVENC and the full H3
#                       video VAE are disabled. Node clocks remain unlocked.
#   ...-rdma-qk-direct-quality-moon-bf16-o-bundle-full-vae
#                       Moon quality-factorial Q0D0: BF16 main-block compute,
#                       BF16 QKV wire, reverse-O bundling, and the full H3 VAE.
#   ...-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp32
#                       Moon quality-factorial Q0D1: the exact Q0D0 latent path
#                       with only the video decoder changed to TAEH3 FP32.
#   ...-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp16
#                       Moon quality-factorial Q0D2: the exact Q0D1 path with
#                       only TAEH3 arithmetic changed from FP32 to FP16.
#   ...-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-full-vae
#                       Moon quality-factorial Q1D0: all-main online FP8 and
#                       calibrated E4M3 QKV wire, with the full H3 VAE.
#   ...-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16
#                       Moon quality-factorial Q1D1: the exact Q1D0 latent path
#                       with only the video decoder changed to TAEH3 FP16.
#   ...-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-full-vae
#                       Moon diagnostic: all-main online FP8 compute with BF16
#                       QKV wire and the full H3 VAE, isolating compute
#                       quantization from E4M3 transport.
#   ...-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-taeh3-fp16
#                       Moon qmid_d1 diagnostic: the same all-main FP8/BF16
#                       wire path with TAEH3 FP16, closing the decoder x
#                       transport interaction matrix.
#                       All factorial actions are one-shot,
#                       prompt/geometry bound, O-bundle, and non-persistent.
#   ...-rdma-qk-direct-qkv-calibration-all-main-fp8
#                       Fresh BF16-wire QKV calibration bound to the exact
#                       all-main online-FP8 scope: 250 main-block linears,
#                       including all 50 VSA to_gate_compress projections.
#   ...-rdma-qk-direct-qkv-validation-all-main-fp8
#                       Fresh validation of an all-main-bound draft scale
#                       tensor. This action never publishes a final sidecar.
#   ...-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16
#                       Final cumulative all-main rung: newly calibrated and
#                       finalized E4M3 QKV transport, reverse-O bundling, and
#                       TAEH3 FP16 chunked output. QKV single-phase stays off.
#   ...-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma
#                       Identical final cumulative rung with only the
#                       FlashInfer communicator lifecycle changed: registered
#                       RDMA windows remain armed across requests instead of
#                       being released after every denoise.
#   ...-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-audio-overlap
#                       Schedule-only candidate on the current fastest stack:
#                       launch the rank-0 audio VAE on a side CUDA stream while
#                       TAEH3 decodes/submits video chunks. Values, codecs, and
#                       communication protocols are otherwise unchanged.
#   ...-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio
#                       Rank-placement-only candidate: rank 0 keeps the
#                       unchanged TAEH3 video decode while rank 1 runs the
#                       unchanged audio VAE, then broadcasts the FP32 waveform.
#                       TAEH3 remains single-rank; VAE PP is explicitly 1.
#   ...-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio-aac
#                       Extends cross-rank audio placement by encoding AAC on
#                       rank 1 before its small packet payload is broadcast.
#                       Rank 0 only muxes those packets after video flush.
#   ...-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-qkv-single-phase
#                       Explicit protocol-only candidate on top of the
#                       persistent all-main-FP8 best stack. It retains the
#                       communicator across requests and uses one standard-
#                       layout Q/K/V collective phase; release-after-denoise
#                       remains disabled.
#   ...-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16-qkv-single-phase
#                       Explicit protocol-only candidate on top of the FP16
#                       best stack. The runner owns the single-phase opt-in and
#                       replaces three standard-layout Q/K/V collective phases
#                       with one FlashInfer scatter_heads_qkv_experimental
#                       phase. Values and all compute dtypes are unchanged.
#   vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3
#                       Identical cumulative stack, with only Q/K/V Ulysses
#                       wire transport changed from BF16 to static per-block
#                       E4M3. Reverse-O and all transformer compute remain BF16.
#   vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration
#                       Diagnostic phase 1: observe BF16 Q/K/V at the exact
#                       transport boundary and atomically publish one cumulative
#                       provenance-bound rank-v3 snapshot per SP rank. E4M3
#                       transport is disabled.
#   vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation
#                       Diagnostic phase 2: validate an explicitly supplied
#                       derived draft scale tensor against a fresh BF16 run.
#                       This action never finalizes or overwrites a formal sidecar.
#   tp2-sp4-fasth3-dense-smoke
#                       Diagnostic four-forward fused-student correctness run;
#                       no AdaLN cache, qchunk, specialized A2A, or upload
#   tp1-sp8-layerwise  Rank-local DiT block streaming; regular NCCL SP8
#   tp1-sp8-layerwise-tuned
#                       DLO shard+AllGather with an env-selected resident window
#   tp1-sp8-adaln      Exact fixed-schedule AdaLN sidecar; regular NCCL SP8
#   remaining          Run the ungated optimized cases after a saved regular baseline
#   matrix             Run every ungated active non-NVENC case serially
#
# The NVENC experiment remains in the implementation as TODO-only code, but
# it is deliberately unreachable from this benchmark's active action matrix.
#
# GPU health is fail-closed by default before every model load:
#   VLLM_OMNI_GPU_IDLE_HEALTH_GATE=0 disables only the repeated no-app idle
#     consistency check (default: 3 samples, 5% utilization, 256 MiB).
#   VLLM_OMNI_GPU_BALANCE_HEALTH_GATE is fixed to 0 for this campaign, disabling
#     only the independent eight-GPU exact-shape SDPA balance check.
# This node cannot provide a stable application-clock lock, so the balance
# probe is disabled and every result is explicitly recorded as
# ``node-default/unlocked clocks``.  The idle/process/temperature/ECC gates
# remain fail-closed.  This script only observes clocks; it never changes or
# locks them.
# VLLM_OMNI_ENABLE_DIFFUSION_PIPELINE_PROFILER=0 measures the production
# request path without the profiler's device-wide stage/step synchronizations.
# Client E2E, process exclusivity, and finalized-media validation stay enabled;
# component/step timing columns are recorded as unavailable for that A/B.
#
# VLLM_OMNI_FASTVIDEO_VSA_DEFERRED_GATE_SP=1 enables the default-off Stage-1
# qualification route that keeps the gate on its original SP shard and moves
# only compact VSA coarse output. It is restricted to strict FastH3 VSA SP>1
# and is mutually exclusive with fused gate+untile and qchunk.
# VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE=1 enables the default-off Stage-2 route:
# retain the owner-local gate and piggyback each owner's compact coarse rows in
# the registered reverse-O RDMA operand. It is qualified only on the cumulative
# strict-SP8 FlashInfer lane and is mutually exclusive with Stage-1, fused
# gate+untile, qchunk, joint rows, Ring, and advanced Ulysses.
# VLLM_OMNI_FASTVIDEO_VSA_GATE_COMPUTE_OVERLAP=1 enables the default-off
# schedule-only experiment that launches the unchanged BF16 VSA gate projection
# on a side stream after QKV, then waits immediately before the owner-local gate
# consumer. It is restricted to the exact E4M3-QKV Stage-2 contract above and
# to resident TP1/SP8 execution; unsupported combinations fail before model
# load. The stable runtime proof is one ACTIVE_V1 marker per diffusion worker;
# request-level launch/wait counts require an Nsight trace of the NVTX ranges.

QUALITY_MOON_BF16_FULL_VAE_ACTION=vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-full-vae
QUALITY_MOON_BF16_TAEH3_FP32_ACTION=vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp32
QUALITY_MOON_BF16_TAEH3_FP16_ACTION=vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp16
QUALITY_MOON_ALL_MAIN_FP8_FULL_VAE_ACTION=vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-full-vae
QUALITY_MOON_ALL_MAIN_FP8_TAEH3_FP16_ACTION=vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16
QUALITY_MOON_ALL_MAIN_FP8_BF16_WIRE_FULL_VAE_ACTION=vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-full-vae
QUALITY_MOON_ALL_MAIN_FP8_BF16_WIRE_TAEH3_FP16_ACTION=vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-taeh3-fp16
MLP_FP8_BF16_WIRE_E2E_ACTION=vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio
QUALITY_MOON_PROMPT_SHA256=5abb96b31333eea455c241aa17e61d1eaf75d7e78625c80f17302b34ce11fad3

ACTION="${1:-comm-ab}"
case "$ACTION" in
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-full-vae|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp32|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp16|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-full-vae|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-full-vae|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-taeh3-fp16|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-qkv-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp32|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16-qkv-single-phase|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-qkv-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-qkv-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-all-main-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-all-main-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-audio-overlap|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio-aac|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-qkv-single-phase) ;;
  comm-ab|tp2-sp4-regular|tp2-sp4-lsa|tp2-sp4-adaln-lsa|tp1-sp8-adaln-lsa|tp1-sp8-adaln-rdma|tp1-sp8-adaln-rdma-qk-direct|tp1-sp8-fasth3-dense-adaln-rdma-qk-direct|vllm-omni-tp1-sp8-fasth3-vsa-fastvideo-topk162-nccl|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-nccl|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-fp8|tp2-sp4-fasth3-dense-smoke|tp1-sp8-layerwise|tp1-sp8-layerwise-tuned|tp1-sp8-adaln|remaining|matrix) ;;
  *)
    echo "Usage: bash $0 [comm-ab|tp2-sp4-regular|tp2-sp4-lsa|tp2-sp4-adaln-lsa|tp1-sp8-adaln-rdma|tp1-sp8-adaln-rdma-qk-direct|tp1-sp8-fasth3-dense-adaln-rdma-qk-direct|vllm-omni-tp1-sp8-fasth3-vsa-fastvideo-topk162-nccl|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-nccl|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-qkv-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp32|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16-qkv-single-phase|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-qkv-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-all-main-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-qkv-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-all-main-fp8|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma|vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-qkv-single-phase|tp2-sp4-fasth3-dense-smoke|tp1-sp8-layerwise|tp1-sp8-layerwise-tuned|tp1-sp8-adaln|remaining|matrix]" >&2
    exit 2
    ;;
esac

CUMULATIVE_FASTH3_VSA_RDMA=0
QUALITY_MOON_FACTORIAL_ACTION=0
QUALITY_MOON_BF16_FACTORIAL=0
QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL=0
MLP_FP8_CONTRACT=0
MLP_OUT_FP8_CONTRACT=0
MLP_OUT_QKV_FP8_CONTRACT=0
ALL_MAIN_FP8_CONTRACT=0
QKV_E4M3_TRANSPORT=0
QKV_SINGLE_PHASE=0
QKV_TRANSPORT_OBSERVER_MODE=disabled
TAEH3_OUTPUT=0
TAEH3_DTYPE_DEFAULT=disabled
PERSISTENT_RDMA=0
TAEH3_AUDIO_DECODE_OVERLAP=0
TAEH3_CROSS_RANK_AUDIO_DECODE=0
TAEH3_CROSS_RANK_AUDIO_ENCODE=0
case "$ACTION" in
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-full-vae)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    QUALITY_MOON_FACTORIAL_ACTION=1
    QUALITY_MOON_BF16_FACTORIAL=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp32)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    QUALITY_MOON_FACTORIAL_ACTION=1
    QUALITY_MOON_BF16_FACTORIAL=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp32
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp16)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    QUALITY_MOON_FACTORIAL_ACTION=1
    QUALITY_MOON_BF16_FACTORIAL=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp16
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-full-vae)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    QUALITY_MOON_FACTORIAL_ACTION=1
    QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL=1
    ALL_MAIN_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    QUALITY_MOON_FACTORIAL_ACTION=1
    QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL=1
    ALL_MAIN_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp16
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-full-vae)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    QUALITY_MOON_FACTORIAL_ACTION=1
    QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL=1
    ALL_MAIN_FP8_CONTRACT=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-taeh3-fp16)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    QUALITY_MOON_FACTORIAL_ACTION=1
    QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL=1
    ALL_MAIN_FP8_CONTRACT=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp16
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_FP8_CONTRACT=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_FP8_CONTRACT=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp16
    PERSISTENT_RDMA=1
    TAEH3_CROSS_RANK_AUDIO_DECODE=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_OUT_FP8_CONTRACT=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-qkv-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_OUT_QKV_FP8_CONTRACT=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    QKV_E4M3_TRANSPORT=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_OUT_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_OUT_QKV_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp32)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_OUT_QKV_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp32
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_OUT_QKV_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp16
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16-qkv-single-phase)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_OUT_QKV_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    QKV_SINGLE_PHASE=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp16
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    ALL_MAIN_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp16
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    ALL_MAIN_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp16
    PERSISTENT_RDMA=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-audio-overlap)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    ALL_MAIN_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp16
    PERSISTENT_RDMA=1
    TAEH3_AUDIO_DECODE_OVERLAP=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    ALL_MAIN_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp16
    PERSISTENT_RDMA=1
    TAEH3_CROSS_RANK_AUDIO_DECODE=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio-aac)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    ALL_MAIN_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp16
    PERSISTENT_RDMA=1
    TAEH3_CROSS_RANK_AUDIO_DECODE=1
    TAEH3_CROSS_RANK_AUDIO_ENCODE=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-qkv-single-phase)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    ALL_MAIN_FP8_CONTRACT=1
    QKV_E4M3_TRANSPORT=1
    QKV_SINGLE_PHASE=1
    TAEH3_OUTPUT=1
    TAEH3_DTYPE_DEFAULT=fp16
    PERSISTENT_RDMA=1
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    QKV_TRANSPORT_OBSERVER_MODE=calibration
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_FP8_CONTRACT=1
    QKV_TRANSPORT_OBSERVER_MODE=calibration
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_OUT_FP8_CONTRACT=1
    QKV_TRANSPORT_OBSERVER_MODE=calibration
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-qkv-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_OUT_QKV_FP8_CONTRACT=1
    QKV_TRANSPORT_OBSERVER_MODE=calibration
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    QKV_TRANSPORT_OBSERVER_MODE=validation
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_FP8_CONTRACT=1
    QKV_TRANSPORT_OBSERVER_MODE=validation
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_OUT_FP8_CONTRACT=1
    QKV_TRANSPORT_OBSERVER_MODE=validation
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-qkv-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    MLP_OUT_QKV_FP8_CONTRACT=1
    QKV_TRANSPORT_OBSERVER_MODE=validation
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-all-main-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    ALL_MAIN_FP8_CONTRACT=1
    QKV_TRANSPORT_OBSERVER_MODE=calibration
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-all-main-fp8)
    CUMULATIVE_FASTH3_VSA_RDMA=1
    ALL_MAIN_FP8_CONTRACT=1
    QKV_TRANSPORT_OBSERVER_MODE=validation
    ;;
esac

FASTH3_MODE=0
FASTH3_SMOKE_MODE=0
FASTH3_VSA_MODE=0
FASTH3_VARIANT=disabled
FASTH3_VSA_PROVIDER=disabled
FASTH3_VSA_TOPK=0
if [[ "$ACTION" == tp1-sp8-fasth3-dense-adaln-rdma-qk-direct || \
  "$ACTION" == tp2-sp4-fasth3-dense-smoke || \
  "$ACTION" == vllm-omni-tp1-sp8-fasth3-vsa-fastvideo-topk162-nccl || \
  "$ACTION" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-nccl || \
  "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 ]]; then
  FASTH3_MODE=1
fi
if [[ "$ACTION" == tp2-sp4-fasth3-dense-smoke ]]; then
  FASTH3_SMOKE_MODE=1
fi
case "$ACTION" in
  vllm-omni-tp1-sp8-fasth3-vsa-fastvideo-topk162-nccl)
    FASTH3_VSA_MODE=1
    FASTH3_VARIANT=vsa-datafree
    FASTH3_VSA_PROVIDER=fastvideo
    FASTH3_VSA_TOPK=162
    ;;
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-nccl|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-full-vae|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp32|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp16|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-full-vae|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-full-vae|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-taeh3-fp16|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-qkv-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp32|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16-qkv-single-phase|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-qkv-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-qkv-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-all-main-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-all-main-fp8|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-audio-overlap|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio-aac|\
  vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-qkv-single-phase)
    FASTH3_VSA_MODE=1
    FASTH3_VARIANT=vsa-datafree
    FASTH3_VSA_PROVIDER=flashinfer
    FASTH3_VSA_TOPK=162
    ;;
esac
if [[ "$FASTH3_MODE" == 1 && "$FASTH3_VSA_MODE" == 0 ]]; then
  FASTH3_VARIANT=dense-datafree
fi

SCRIPT_DIR="/lustre/raplab/client/sylarl/minimax-h3-native/FastVideo"
WORKSPACE_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
VLLM_SOURCE="${VLLM_OMNI_SOURCE:-$WORKSPACE_DIR/vllm-omni-h3-dlo-latest/vllm-omni}"
VLLM_VENV="${VLLM_OMNI_VENV:-$WORKSPACE_DIR/vllm-omni-h3-dlo-latest/.venv-vllm028}"
MODEL="${VLLM_OMNI_MODEL:-$WORKSPACE_DIR/MiniMax-H3/FL2VA}"
RESULTS_ROOT="${VLLM_OMNI_RESULTS_ROOT:-$WORKSPACE_DIR/results}"
GPU_ORDER="${VLLM_OMNI_CUDA_VISIBLE_DEVICES:-0,4,1,5,2,6,3,7}"
PORT="${VLLM_OMNI_PORT:-8091}"
READY_TIMEOUT="${VLLM_OMNI_READY_TIMEOUT:-3600}"
REQUEST_TIMEOUT="${VLLM_OMNI_REQUEST_TIMEOUT:-7200}"
EXCLUSIVE_GPU_TIMEOUT="${VLLM_OMNI_EXCLUSIVE_GPU_TIMEOUT:-900}"
ENABLE_DIFFUSION_PIPELINE_PROFILER="${VLLM_OMNI_ENABLE_DIFFUSION_PIPELINE_PROFILER:-1}"
[[ "$ENABLE_DIFFUSION_PIPELINE_PROFILER" == 0 || \
   "$ENABLE_DIFFUSION_PIPELINE_PROFILER" == 1 ]] || {
  echo "VLLM_OMNI_ENABLE_DIFFUSION_PIPELINE_PROFILER must be exactly 0 or 1" >&2
  exit 2
}
NSYS_INTERACTIVE_SESSION="${VLLM_OMNI_NSYS_INTERACTIVE_SESSION:-}"
NSYS_INTERACTIVE_OUTPUT="${VLLM_OMNI_NSYS_INTERACTIVE_OUTPUT:-}"
NSYS_INTERACTIVE_BIN="${VLLM_OMNI_NSYS_BIN:-$(command -v nsys || true)}"
if [[ -n "$NSYS_INTERACTIVE_SESSION" ]]; then
  [[ "$NSYS_INTERACTIVE_SESSION" =~ ^[A-Za-z][A-Za-z0-9_.-]*$ ]] || {
    echo "VLLM_OMNI_NSYS_INTERACTIVE_SESSION must be a simple alphanumeric session name" >&2
    exit 2
  }
  [[ -x "$NSYS_INTERACTIVE_BIN" ]] || {
    echo "VLLM_OMNI_NSYS_BIN must name an executable Nsight Systems CLI" >&2
    exit 2
  }
  [[ "$NSYS_INTERACTIVE_OUTPUT" == /* ]] || {
    echo "VLLM_OMNI_NSYS_INTERACTIVE_OUTPUT must be an absolute output prefix" >&2
    exit 2
  }
fi
GPU_IDLE_HEALTH_GATE="${VLLM_OMNI_GPU_IDLE_HEALTH_GATE:-1}"
GPU_IDLE_HEALTH_SAMPLES="${VLLM_OMNI_GPU_IDLE_HEALTH_SAMPLES:-3}"
GPU_IDLE_HEALTH_GRACE_SECONDS="${VLLM_OMNI_GPU_IDLE_HEALTH_GRACE_SECONDS:-5}"
GPU_IDLE_HEALTH_INTERVAL_SECONDS="${VLLM_OMNI_GPU_IDLE_HEALTH_INTERVAL_SECONDS:-1}"
GPU_IDLE_MAX_UTILIZATION_PERCENT="${VLLM_OMNI_GPU_IDLE_MAX_UTILIZATION_PERCENT:-5}"
GPU_IDLE_MAX_MEMORY_MIB="${VLLM_OMNI_GPU_IDLE_MAX_MEMORY_MIB:-256}"
GPU_IDLE_MAX_TEMPERATURE_C="${VLLM_OMNI_GPU_IDLE_MAX_TEMPERATURE_C:-70}"
if [[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 && \
      "${VLLM_OMNI_GPU_BALANCE_HEALTH_GATE-}" != 0 ]]; then
  echo "The Moon quality-factorial campaign requires explicit VLLM_OMNI_GPU_BALANCE_HEALTH_GATE=0 (node-default/unlocked clocks)" >&2
  exit 2
fi
if [[ "$ALL_MAIN_FP8_CONTRACT" == 1 && \
      "${VLLM_OMNI_GPU_BALANCE_HEALTH_GATE-}" != 0 ]]; then
  echo "The all-main FP8 campaign requires explicit VLLM_OMNI_GPU_BALANCE_HEALTH_GATE=0 (node-default/unlocked clocks)" >&2
  exit 2
fi
if [[ "$TAEH3_OUTPUT" == 1 && \
      "${VLLM_OMNI_GPU_BALANCE_HEALTH_GATE-}" != 0 ]]; then
  echo "The TAEH3 cumulative action requires explicit VLLM_OMNI_GPU_BALANCE_HEALTH_GATE=0 (node-default/unlocked clocks)" >&2
  exit 2
fi
if [[ "${VLLM_OMNI_GPU_BALANCE_HEALTH_GATE:-0}" != 0 ]]; then
  echo "This campaign requires VLLM_OMNI_GPU_BALANCE_HEALTH_GATE=0 (node-default/unlocked clocks)" >&2
  exit 2
fi
GPU_BALANCE_HEALTH_GATE=0
GPU_CLOCK_POLICY="node-default/unlocked clocks"
GPU_BALANCE_WARMUP="${VLLM_OMNI_GPU_BALANCE_WARMUP:-3}"
GPU_BALANCE_ROUNDS="${VLLM_OMNI_GPU_BALANCE_ROUNDS:-3}"
GPU_BALANCE_ITERATIONS="${VLLM_OMNI_GPU_BALANCE_ITERATIONS:-5}"
GPU_BALANCE_WORKER_TIMEOUT="${VLLM_OMNI_GPU_BALANCE_WORKER_TIMEOUT:-180}"
GPU_BALANCE_SMI_INTERVAL="${VLLM_OMNI_GPU_BALANCE_SMI_INTERVAL:-0.25}"
GPU_BALANCE_MAX_TIME_RATIO="${VLLM_OMNI_GPU_BALANCE_MAX_TIME_RATIO:-1.08}"
GPU_BALANCE_MAX_MEDIAN_OVER_FLEET="${VLLM_OMNI_GPU_BALANCE_MAX_MEDIAN_OVER_FLEET:-1.08}"
GPU_BALANCE_MIN_CLOCK_RATIO="${VLLM_OMNI_GPU_BALANCE_MIN_CLOCK_RATIO:-0.92}"
GPU_BALANCE_MIN_POWER_RATIO="${VLLM_OMNI_GPU_BALANCE_MIN_POWER_RATIO:-0.85}"
GPU_BALANCE_MIN_LOADED_UTILIZATION_PERCENT="${VLLM_OMNI_GPU_BALANCE_MIN_LOADED_UTILIZATION_PERCENT:-90}"
GPU_BALANCE_MIN_TELEMETRY_SAMPLES="${VLLM_OMNI_GPU_BALANCE_MIN_TELEMETRY_SAMPLES:-3}"
if [[ "$QKV_TRANSPORT_OBSERVER_MODE" != disabled ]]; then
  if [[ -v VLLM_OMNI_WARMUPS && "$VLLM_OMNI_WARMUPS" != 0 ]]; then
    echo "QKV calibration/validation requires VLLM_OMNI_WARMUPS=0" >&2
    exit 2
  fi
  if [[ -v VLLM_OMNI_REPEATS && "$VLLM_OMNI_REPEATS" != 1 ]]; then
    echo "QKV calibration/validation requires VLLM_OMNI_REPEATS=1" >&2
    exit 2
  fi
  WARMUPS=0
  REPEATS=1
elif [[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 ]]; then
  if [[ -v VLLM_OMNI_WARMUPS && "$VLLM_OMNI_WARMUPS" != 0 ]]; then
    echo "Moon quality-factorial actions require VLLM_OMNI_WARMUPS=0" >&2
    exit 2
  fi
  if [[ -v VLLM_OMNI_REPEATS && "$VLLM_OMNI_REPEATS" != 1 ]]; then
    echo "Moon quality-factorial actions require VLLM_OMNI_REPEATS=1" >&2
    exit 2
  fi
  WARMUPS=0
  REPEATS=1
else
  WARMUPS="${VLLM_OMNI_WARMUPS:-1}"
  REPEATS="${VLLM_OMNI_REPEATS:-1}"
fi
if [[ -n "$NSYS_INTERACTIVE_SESSION" && \
      "$REPEATS" != 1 ]]; then
  echo "Sage experiment Nsight capture requires exactly one measured request; capture starts after warmup" >&2
  exit 2
fi
WIDTH="${VLLM_OMNI_WIDTH:-1280}"
HEIGHT="${VLLM_OMNI_HEIGHT:-720}"
if [[ "$FASTH3_MODE" == 1 ]]; then
  DEFAULT_STEPS=4
  DENOISER_EVALUATIONS=4
  RUN_CONTRACT="fasth3-${FASTH3_VARIANT}-4step"
else
  DEFAULT_STEPS=50
  DENOISER_EVALUATIONS=""
  RUN_CONTRACT=base-h3-dense
fi
STEPS="${VLLM_OMNI_STEPS:-$DEFAULT_STEPS}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
if [[ "$FASTH3_MODE" == 1 ]]; then
  if [[ "$FASTH3_VSA_MODE" == 1 ]]; then
    RUN_ROOT_DEFAULT="$RESULTS_ROOT/${ACTION}-$STAMP"
    ADALN_CACHE_DEFAULT="$WORKSPACE_DIR/cache/minimax-h3-fasth3-vsa-datafree-42dc502a-t2va-4step-shift12-3.safetensors"
  else
    RUN_ROOT_DEFAULT="$RESULTS_ROOT/vllm-omni-fasth3-dense-datafree-pro5000-15s-4step-$STAMP"
    ADALN_CACHE_DEFAULT="$WORKSPACE_DIR/cache/minimax-h3-fasth3-dense-datafree-bcf40ca6-t2va-4step-shift12-3.safetensors"
  fi
else
  RUN_ROOT_DEFAULT="$RESULTS_ROOT/vllm-omni-h3-pro5000-comm-15s-${STEPS}sigma-$STAMP"
  ADALN_CACHE_DEFAULT="$WORKSPACE_DIR/cache/minimax-h3-fl2va-t2va-${STEPS}sigma-shift12-3.safetensors"
fi
RUN_ROOT="${VLLM_OMNI_OUTPUT_DIR:-$RUN_ROOT_DEFAULT}"
ADALN_CACHE="${MINIMAX_H3_ADALN_CACHE:-$ADALN_CACHE_DEFAULT}"
if [[ "$FASTH3_VSA_MODE" == 1 ]]; then
  FASTH3_LORA_DEFAULT="$WORKSPACE_DIR/FastH3-LoRA/vsa-datafree/adapter_model.safetensors"
  FASTH3_EXPECTED_SIZE=5339117712
  FASTH3_EXPECTED_SHA256=42dc502a2078f166c396a1fa75f29728d1844363652d345d5ef3e2b444ed6470
else
  FASTH3_LORA_DEFAULT="$WORKSPACE_DIR/FastH3-LoRA/dense-datafree/adapter_model.safetensors"
  FASTH3_EXPECTED_SIZE=1485626152
  FASTH3_EXPECTED_SHA256=4ce198c83132251b7fd0de2503823aa49c53983f068318f66cb19eaefb7fcc12
fi
FASTH3_LORA="${VLLM_OMNI_FASTH3_LORA:-$FASTH3_LORA_DEFAULT}"
FASTH3_BASE_SCHEDULE=(0.999 0.749 0.5 0.25 0.0)
QKV_SINGLE_PHASE_ENV=VLLM_OMNI_FLASHINFER_ULYSSES_QKV_SINGLE_PHASE
QKV_SINGLE_PHASE_ACTION=vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16-qkv-single-phase
QKV_SINGLE_PHASE_ALL_MAIN_PERSISTENT_ACTION=vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-qkv-single-phase
QKV_SINGLE_PHASE_PROTOCOL=flashinfer_standard_layout_qkv_one_open_close_phase_v1
QKV_SINGLE_PHASE_MARKER="FlashInfer PCIe Ulysses standard-layout Q/K/V single phase active:"
QKV_SINGLE_PHASE_EXPECTED_CALLS_PER_WORKER_PER_REQUEST=200
QKV_SINGLE_PHASE_QUALITY_CONTRACT=copy_only_protocol_expected_hash_identical_to_fp16_best_gpu_ab_pending
qkv_single_phase_action_matches() {
  [[ "$1" == "$QKV_SINGLE_PHASE_ACTION" || \
     "$1" == "$QKV_SINGLE_PHASE_ALL_MAIN_PERSISTENT_ACTION" ]]
}
[[ "$QKV_SINGLE_PHASE" == 0 || "$QKV_SINGLE_PHASE" == 1 ]] || {
  echo "Internal QKV single-phase action flag must be exactly 0 or 1" >&2
  exit 2
}
# This protocol candidate must never leak into another rung through a caller's
# shell. Even an externally supplied value of 0 is rejected: the explicit
# action below owns both the opt-in and its recorded provenance.
if [[ -v $QKV_SINGLE_PHASE_ENV ]]; then
  echo "$QKV_SINGLE_PHASE_ENV is runner-owned and accepted only through an explicit QKV single-phase action" >&2
  exit 2
fi
if [[ "$QKV_SINGLE_PHASE" == 1 ]] && ! qkv_single_phase_action_matches "$ACTION"; then
  echo "QKV single-phase is bound to its exact cumulative runner action" >&2
  exit 2
fi
if qkv_single_phase_action_matches "$ACTION" && [[ "$QKV_SINGLE_PHASE" != 1 ]]; then
  echo "The explicit QKV single-phase action lost its internal opt-in" >&2
  exit 2
fi
ALL_MAIN_FP8_FINAL_ACTION=vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16
ALL_MAIN_FP8_PERSISTENT_ACTION=${ALL_MAIN_FP8_FINAL_ACTION}-persistent-rdma
TAEH3_AUDIO_OVERLAP_ACTION=${ALL_MAIN_FP8_PERSISTENT_ACTION}-audio-overlap
TAEH3_AUDIO_OVERLAP_ENV=VLLM_OMNI_MINIMAX_H3_TAEH3_AUDIO_DECODE_OVERLAP
TAEH3_AUDIO_OVERLAP_MARKER=MINIMAX_H3_TAEH3_AUDIO_DECODE_OVERLAP_ACTIVE_V1
TAEH3_CROSS_RANK_AUDIO_ACTION=${ALL_MAIN_FP8_PERSISTENT_ACTION}-cross-rank-audio
TAEH3_CROSS_RANK_AUDIO_ENV=VLLM_OMNI_MINIMAX_H3_TAEH3_CROSS_RANK_AUDIO_DECODE
TAEH3_CROSS_RANK_AUDIO_MARKER=MINIMAX_H3_TAEH3_CROSS_RANK_AUDIO_DECODE_ACTIVE_V1
TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTION=${TAEH3_CROSS_RANK_AUDIO_ACTION}-aac
TAEH3_CROSS_RANK_AUDIO_ENCODE_ENV=VLLM_OMNI_MINIMAX_H3_TAEH3_CROSS_RANK_AUDIO_ENCODE
TAEH3_CROSS_RANK_AUDIO_ENCODE_MARKER=MINIMAX_H3_TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTIVE_V1
ALL_MAIN_FP8_CALIBRATION_ACTION=vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-all-main-fp8
ALL_MAIN_FP8_VALIDATION_ACTION=vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-all-main-fp8
persistent_rdma_action_matches() {
  [[ "$1" == "$ALL_MAIN_FP8_PERSISTENT_ACTION" || \
     "$1" == "$TAEH3_AUDIO_OVERLAP_ACTION" || \
     "$1" == "$TAEH3_CROSS_RANK_AUDIO_ACTION" || \
     "$1" == "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTION" || \
     "$1" == "$MLP_FP8_BF16_WIRE_E2E_ACTION" || \
     "$1" == "$QKV_SINGLE_PHASE_ALL_MAIN_PERSISTENT_ACTION" ]]
}
[[ "$PERSISTENT_RDMA" == 0 || "$PERSISTENT_RDMA" == 1 ]] || {
  echo "Internal persistent-RDMA action flag must be exactly 0 or 1" >&2
  exit 2
}
if [[ "$PERSISTENT_RDMA" == 1 ]] && ! persistent_rdma_action_matches "$ACTION"; then
  echo "Persistent RDMA is bound to its exact cumulative runner action" >&2
  exit 2
fi
if persistent_rdma_action_matches "$ACTION" && [[ "$PERSISTENT_RDMA" != 1 ]]; then
  echo "The explicit persistent-RDMA action lost its internal opt-in" >&2
  exit 2
fi
[[ "$TAEH3_AUDIO_DECODE_OVERLAP" == 0 || "$TAEH3_AUDIO_DECODE_OVERLAP" == 1 ]] || {
  echo "Internal TAEH3/audio overlap flag must be exactly 0 or 1" >&2
  exit 2
}
if [[ -v $TAEH3_AUDIO_OVERLAP_ENV ]]; then
  echo "$TAEH3_AUDIO_OVERLAP_ENV is runner-owned and accepted only through the explicit overlap action" >&2
  exit 2
fi
if [[ "$TAEH3_AUDIO_DECODE_OVERLAP" == 1 && "$ACTION" != "$TAEH3_AUDIO_OVERLAP_ACTION" ]]; then
  echo "TAEH3/audio overlap is bound to its exact cumulative runner action" >&2
  exit 2
fi
if [[ "$ACTION" == "$TAEH3_AUDIO_OVERLAP_ACTION" && "$TAEH3_AUDIO_DECODE_OVERLAP" != 1 ]]; then
  echo "The explicit TAEH3/audio overlap action lost its internal opt-in" >&2
  exit 2
fi
[[ "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 0 || \
   "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 1 ]] || {
  echo "Internal TAEH3 cross-rank audio flag must be exactly 0 or 1" >&2
  exit 2
}
if [[ -v $TAEH3_CROSS_RANK_AUDIO_ENV ]]; then
  echo "$TAEH3_CROSS_RANK_AUDIO_ENV is runner-owned and accepted only through the explicit cross-rank action" >&2
  exit 2
fi
if [[ "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 1 && \
      "$ACTION" != "$TAEH3_CROSS_RANK_AUDIO_ACTION" && \
      "$ACTION" != "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTION" && \
      "$ACTION" != "$MLP_FP8_BF16_WIRE_E2E_ACTION" ]]; then
  echo "TAEH3 cross-rank audio is bound to its exact cumulative runner action" >&2
  exit 2
fi
if [[ ( "$ACTION" == "$TAEH3_CROSS_RANK_AUDIO_ACTION" || \
        "$ACTION" == "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTION" || \
        "$ACTION" == "$MLP_FP8_BF16_WIRE_E2E_ACTION" ) && \
      "$TAEH3_CROSS_RANK_AUDIO_DECODE" != 1 ]]; then
  echo "The explicit TAEH3 cross-rank audio action lost its internal opt-in" >&2
  exit 2
fi
[[ "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 0 || \
   "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 1 ]] || {
  echo "Internal TAEH3 cross-rank AAC flag must be exactly 0 or 1" >&2
  exit 2
}
if [[ -v $TAEH3_CROSS_RANK_AUDIO_ENCODE_ENV ]]; then
  echo "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ENV is runner-owned and accepted only through the explicit AAC action" >&2
  exit 2
fi
if [[ "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 1 && \
      "$ACTION" != "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTION" ]]; then
  echo "TAEH3 cross-rank AAC is bound to its exact cumulative runner action" >&2
  exit 2
fi
if [[ "$ACTION" == "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTION" && \
      "$TAEH3_CROSS_RANK_AUDIO_ENCODE" != 1 ]]; then
  echo "The explicit TAEH3 cross-rank AAC action lost its internal opt-in" >&2
  exit 2
fi
if [[ "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 1 && \
      "$TAEH3_CROSS_RANK_AUDIO_DECODE" != 1 ]]; then
  echo "TAEH3 cross-rank AAC requires cross-rank Audio VAE decode" >&2
  exit 2
fi
if [[ "$TAEH3_AUDIO_DECODE_OVERLAP" == 1 && \
      "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 1 ]]; then
  echo "Same-rank and cross-rank TAEH3/audio overlap are mutually exclusive" >&2
  exit 2
fi
if [[ "$PERSISTENT_RDMA" == 1 ]]; then
  QKV_SINGLE_PHASE_MARKER_CONTRACT=one_per_worker_per_process
else
  QKV_SINGLE_PHASE_MARKER_CONTRACT=one_per_worker_per_request
fi
TAEH3_BACKEND_ENV=VLLM_OMNI_MINIMAX_H3_VIDEO_DECODE_BACKEND
TAEH3_CHECKPOINT_ENV=VLLM_OMNI_MINIMAX_H3_TAEH3_CHECKPOINT
TAEH3_DTYPE_ENV=VLLM_OMNI_MINIMAX_H3_TAEH3_DTYPE
TAEH3_CHUNK_SIZE_ENV=VLLM_OMNI_MINIMAX_H3_TAEH3_CHUNK_SIZE
TAEH3_CHECKPOINT_DEFAULT="$WORKSPACE_DIR/cache/taeh3-62f7591f59dfbb4c3c02b7a621d180a9eeaba26c.safetensors"
TAEH3_EXPECTED_REVISION=62f7591f59dfbb4c3c02b7a621d180a9eeaba26c
TAEH3_EXPECTED_SIZE=22709752
TAEH3_EXPECTED_SHA256=4fd022bfcab08772fe0536b17ea1a3bbb5625be11e397868d1c5d891863d4c13
if [[ "$TAEH3_OUTPUT" == 1 ]]; then
  TAEH3_VIDEO_DECODE_BACKEND="${VLLM_OMNI_MINIMAX_H3_VIDEO_DECODE_BACKEND:-taeh3}"
  TAEH3_CHECKPOINT="${VLLM_OMNI_MINIMAX_H3_TAEH3_CHECKPOINT:-$TAEH3_CHECKPOINT_DEFAULT}"
  TAEH3_DTYPE="${VLLM_OMNI_MINIMAX_H3_TAEH3_DTYPE:-$TAEH3_DTYPE_DEFAULT}"
  TAEH3_CHUNK_SIZE="${VLLM_OMNI_MINIMAX_H3_TAEH3_CHUNK_SIZE:-5}"
  [[ "$TAEH3_VIDEO_DECODE_BACKEND" == taeh3 ]] || {
    echo "$TAEH3_BACKEND_ENV must be exactly taeh3 for the TAEH3 cumulative action" >&2
    exit 2
  }
  [[ "$TAEH3_CHECKPOINT" == /* ]] || {
    echo "$TAEH3_CHECKPOINT_ENV must be an absolute local path" >&2
    exit 2
  }
  [[ "$TAEH3_DTYPE" == "$TAEH3_DTYPE_DEFAULT" ]] || {
    echo "$TAEH3_DTYPE_ENV must be exactly $TAEH3_DTYPE_DEFAULT for this action" >&2
    exit 2
  }
  [[ "$TAEH3_CHUNK_SIZE" == 5 ]] || {
    echo "$TAEH3_CHUNK_SIZE_ENV must be exactly 5 for this validated action" >&2
    exit 2
  }
else
  for taeh3_env in \
    "$TAEH3_BACKEND_ENV" \
    "$TAEH3_CHECKPOINT_ENV" \
    "$TAEH3_DTYPE_ENV" \
    "$TAEH3_CHUNK_SIZE_ENV"; do
    if [[ -v $taeh3_env ]]; then
      echo "$taeh3_env is accepted only by the explicit TAEH3 cumulative action" >&2
      exit 2
    fi
  done
  TAEH3_VIDEO_DECODE_BACKEND=h3-vae
  TAEH3_CHECKPOINT=disabled
  TAEH3_DTYPE=disabled
  TAEH3_CHUNK_SIZE=0
fi
if [[ "$TAEH3_OUTPUT" == 1 ]]; then
  # TAEH3 is a rank-0-local decoder with no DistributedVaeMixin collectives.
  # Keep the generic flag honest instead of passing the native H3 VAE's PP8
  # value and relying on the registry to warn and ignore it.
  VAE_PATCH_PARALLEL_SIZE=1
else
  VAE_PATCH_PARALLEL_SIZE=8
fi
MLP_OUT_QKV_QKV_E4M3_SCALE_SIDECAR="$WORKSPACE_DIR/cache/minimax-h3-fasth3-vsa-datafree-mlp-out-qkv-fp8-bound-qkv-e4m3-sm120-sp8-topk162-15s-seed1101.safetensors"
QUALITY_MOON_ALL_MAIN_FP8_SCALE_SIDECAR="$WORKSPACE_DIR/cache/minimax-h3-moon-teahouse-fullprompt-all-main-fp8-bound-qkv-e4m3-sm120-sp8-topk162-15s-seed1101.safetensors"
QUALITY_MOON_ALL_MAIN_FP8_EXPECTED_WHOLE_SHA256=dcf733d74dc250b0730356f8ef6b592a06a8c722e819a301af861726d65d6db3
QUALITY_MOON_ALL_MAIN_FP8_EXPECTED_PAYLOAD_SHA256=7327a8bb32e007345f4622df21d392dfd7976a858ce0480ebc02aa04ff2f27d5
if [[ "$QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL" == 1 ]]; then
  QKV_E4M3_SCALE_SIDECAR_DEFAULT="$QUALITY_MOON_ALL_MAIN_FP8_SCALE_SIDECAR"
elif [[ "$ALL_MAIN_FP8_CONTRACT" == 1 ]]; then
  QKV_E4M3_SCALE_SIDECAR_DEFAULT="$WORKSPACE_DIR/cache/minimax-h3-fasth3-vsa-datafree-all-main-fp8-bound-qkv-e4m3-sm120-sp8-topk162-15s-seed1101.safetensors"
elif [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 ]]; then
  QKV_E4M3_SCALE_SIDECAR_DEFAULT="$MLP_OUT_QKV_QKV_E4M3_SCALE_SIDECAR"
elif [[ "$MLP_OUT_FP8_CONTRACT" == 1 ]]; then
  QKV_E4M3_SCALE_SIDECAR_DEFAULT="$WORKSPACE_DIR/cache/minimax-h3-fasth3-vsa-datafree-mlp-out-fp8-bound-qkv-e4m3-sm120-sp8-topk162-15s-seed1101.safetensors"
elif [[ "$MLP_FP8_CONTRACT" == 1 ]]; then
  QKV_E4M3_SCALE_SIDECAR_DEFAULT="$WORKSPACE_DIR/cache/minimax-h3-fasth3-vsa-datafree-mlp-fp8-bound-qkv-e4m3-sm120-sp8-topk162-15s-seed1101.safetensors"
else
  QKV_E4M3_SCALE_SIDECAR_DEFAULT="$WORKSPACE_DIR/cache/minimax-h3-fasth3-vsa-datafree-qkv-e4m3-sm120-sp8-topk162-15s-seed1101.safetensors"
fi
QKV_E4M3_SCALE_SIDECAR="${VLLM_OMNI_MINIMAX_H3_QKV_E4M3_SCALE_SIDECAR:-$QKV_E4M3_SCALE_SIDECAR_DEFAULT}"
QKV_E4M3_EXPECTED_WHOLE_SHA256="${VLLM_OMNI_MINIMAX_H3_QKV_E4M3_EXPECTED_WHOLE_SHA256:-}"
QKV_E4M3_EXPECTED_PAYLOAD_SHA256="${VLLM_OMNI_MINIMAX_H3_QKV_E4M3_EXPECTED_PAYLOAD_SHA256:-}"
if [[ "$QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL" == 1 && \
      "$QKV_E4M3_TRANSPORT" == 1 ]]; then
  [[ "$(realpath -m "$QKV_E4M3_SCALE_SIDECAR")" == \
        "$(realpath -m "$QUALITY_MOON_ALL_MAIN_FP8_SCALE_SIDECAR")" ]] || {
    echo "Moon E4M3 quality actions require their exact full-prompt all-main QKV sidecar path" >&2
    exit 2
  }
  if [[ -n "$QKV_E4M3_EXPECTED_WHOLE_SHA256" && \
        "$QKV_E4M3_EXPECTED_WHOLE_SHA256" != \
          "$QUALITY_MOON_ALL_MAIN_FP8_EXPECTED_WHOLE_SHA256" ]]; then
    echo "Moon E4M3 quality actions refuse a non-canonical whole-file sidecar SHA256" >&2
    exit 2
  fi
  if [[ -n "$QKV_E4M3_EXPECTED_PAYLOAD_SHA256" && \
        "$QKV_E4M3_EXPECTED_PAYLOAD_SHA256" != \
          "$QUALITY_MOON_ALL_MAIN_FP8_EXPECTED_PAYLOAD_SHA256" ]]; then
    echo "Moon E4M3 quality actions refuse a non-canonical sidecar payload SHA256" >&2
    exit 2
  fi
  QKV_E4M3_EXPECTED_WHOLE_SHA256="$QUALITY_MOON_ALL_MAIN_FP8_EXPECTED_WHOLE_SHA256"
  QKV_E4M3_EXPECTED_PAYLOAD_SHA256="$QUALITY_MOON_ALL_MAIN_FP8_EXPECTED_PAYLOAD_SHA256"
fi
# ``source_model_revision`` is the immutable base revision recorded in the
# fused FastH3 adapter header.  It is deliberately distinct from the local
# runtime-checkpoint revision, whose exact files are bound by the manifest.
QKV_E4M3_SOURCE_MODEL_REVISION=9bfb6693f2cf6de171db46d1aa586f67d773a1da
QKV_E4M3_KERNEL_PROVIDER=flashinfer-pr4944-cutedsl-sm120
QKV_E4M3_KERNEL_ABI=minimax-h3-vsa-qkv-e4m3-bf16-o-v1
if [[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 ]]; then
  QKV_E4M3_PROMPT_SHA256="${VLLM_OMNI_H3_PROMPT_SHA256:-$QUALITY_MOON_PROMPT_SHA256}"
  QKV_E4M3_PREFIX_TILE_COUNT="${VLLM_OMNI_H3_PREFIX_TILE_COUNT:-27}"
  QKV_E4M3_COMPACT_ROW_COUNT="${VLLM_OMNI_H3_COMPACT_ROW_COUNT:-95823}"
  QKV_E4M3_PADDED_ROW_COUNT="${VLLM_OMNI_H3_PADDED_ROW_COUNT:-105408}"
  QKV_E4M3_SEQUENCE_ROW_COUNT="${VLLM_OMNI_H3_SEQUENCE_ROW_COUNT:-95872}"
  QKV_E4M3_LOCAL_ROW_COUNT="${VLLM_OMNI_H3_LOCAL_ROW_COUNT:-11984}"
else
  QKV_E4M3_PROMPT_SHA256="${VLLM_OMNI_H3_PROMPT_SHA256:-613e0a1beccf83566e3531852c52c2e11daffa3b255222cd67726cdf73c1a563}"
  QKV_E4M3_PREFIX_TILE_COUNT="${VLLM_OMNI_H3_PREFIX_TILE_COUNT:-21}"
  QKV_E4M3_COMPACT_ROW_COUNT="${VLLM_OMNI_H3_COMPACT_ROW_COUNT:-95487}"
  QKV_E4M3_PADDED_ROW_COUNT="${VLLM_OMNI_H3_PADDED_ROW_COUNT:-105024}"
  QKV_E4M3_SEQUENCE_ROW_COUNT="${VLLM_OMNI_H3_SEQUENCE_ROW_COUNT:-95488}"
  QKV_E4M3_LOCAL_ROW_COUNT="${VLLM_OMNI_H3_LOCAL_ROW_COUNT:-11936}"
fi
for qkv_geometry_value in \
  "$QKV_E4M3_PREFIX_TILE_COUNT" \
  "$QKV_E4M3_COMPACT_ROW_COUNT" \
  "$QKV_E4M3_PADDED_ROW_COUNT" \
  "$QKV_E4M3_SEQUENCE_ROW_COUNT" \
  "$QKV_E4M3_LOCAL_ROW_COUNT"; do
  [[ "$qkv_geometry_value" =~ ^[1-9][0-9]*$ ]] || {
    echo "MiniMax H3 prompt geometry values must be positive decimal integers" >&2
    exit 2
  }
done
QKV_E4M3_VIDEO_TILE_COUNT=1620
QKV_E4M3_SP_SIZE=8
if [[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 ]]; then
  # The 457-token Moon packing reaches an observed maximum of 279 selected
  # reverse-O tail rows. Bind the quality matrix to that runtime value so the
  # exact marker validator cannot confuse an oversized capacity (280) with the
  # dynamically trimmed operand (279).
  VSA_O_BUNDLE_KMAX="${VLLM_OMNI_H3_O_BUNDLE_KMAX:-279}"
else
  VSA_O_BUNDLE_KMAX="${VLLM_OMNI_H3_O_BUNDLE_KMAX:-275}"
fi
[[ "$VSA_O_BUNDLE_KMAX" =~ ^[1-9][0-9]*$ ]] || {
  echo "MiniMax H3 reverse-O bundle kmax must be a positive decimal integer" >&2
  exit 2
}
if (( QKV_E4M3_PADDED_ROW_COUNT !=
      (QKV_E4M3_VIDEO_TILE_COUNT + QKV_E4M3_PREFIX_TILE_COUNT) * 64 ||
      QKV_E4M3_SEQUENCE_ROW_COUNT % QKV_E4M3_SP_SIZE != 0 ||
      QKV_E4M3_LOCAL_ROW_COUNT * QKV_E4M3_SP_SIZE !=
        QKV_E4M3_SEQUENCE_ROW_COUNT ||
      QKV_E4M3_COMPACT_ROW_COUNT > QKV_E4M3_PADDED_ROW_COUNT )); then
  echo "MiniMax H3 prompt packing geometry is internally inconsistent" >&2
  exit 2
fi
VSA_O_BUNDLE_COMPACT_COARSE_ROWS=$((
  QKV_E4M3_VIDEO_TILE_COUNT + QKV_E4M3_PREFIX_TILE_COUNT
))
VSA_O_BUNDLE_PRODUCER_ROWS=$((
  QKV_E4M3_SEQUENCE_ROW_COUNT + VSA_O_BUNDLE_KMAX * QKV_E4M3_SP_SIZE
))
VSA_O_BUNDLE_CONSUMER_ROWS=$((
  QKV_E4M3_LOCAL_ROW_COUNT + VSA_O_BUNDLE_KMAX
))
VSA_ELIDED_GATE_OPERAND_BYTES=$((QKV_E4M3_LOCAL_ROW_COUNT * 56 * 128 * 2))
VSA_ELIDED_GATE_REMOTE_WIRE_BYTES=$((QKV_E4M3_LOCAL_ROW_COUNT * 49 * 128 * 2))
VSA_PIGGYBACK_TAIL_OPERAND_BYTES=$((VSA_O_BUNDLE_KMAX * 56 * 128 * 2))
VSA_PIGGYBACK_TAIL_REMOTE_WIRE_BYTES=$((VSA_O_BUNDLE_KMAX * 49 * 128 * 2))
# Legacy 21-prefix-tile defaults remain useful as validator fixtures:
# FLASHINFER_O_BUNDLE_REQUIRED_BYTES=175056896
# elided_gate_operand_bytes=171114496
# elided_gate_remote_wire_bytes=149725184
# piggyback_tail_operand_bytes=3942400
# piggyback_tail_remote_wire_bytes=3449600
QKV_E4M3_OPERAND_BYTES=$((VSA_ELIDED_GATE_OPERAND_BYTES / 2))
QKV_E4M3_REMOTE_WIRE_BYTES=$((VSA_ELIDED_GATE_REMOTE_WIRE_BYTES / 2))
QKV_REMOTE_WIRE_SAVING_BYTES_PER_RANK_REQUEST=$((
  QKV_E4M3_REMOTE_WIRE_BYTES * 3 * 50 * 4
))
QKV_TRANSPORT_OBSERVER_MODE_ENV=VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_MODE
QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR_ENV=VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR
QKV_TRANSPORT_OBSERVER_SCALES_PATH_ENV=VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_SCALES_PATH
QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID_ENV=VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID
QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256_ENV=VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256
QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT_ENV=VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT
QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION_ENV=VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION
QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION_ENV=VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION
QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256_ENV=VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256
QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT=4
QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID=""
QKV_TRANSPORT_OBSERVER_EXECUTION_UUID=""
QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_PATH=""
QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256=""
QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION=""
QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION=""
QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256=""
QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_FILE_SHA256=""
QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR=""
QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_PATH=""
QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_SHA256=""
QKV_TRANSPORT_OBSERVER_VALIDATION_SCALE_SUMMARY=""
QKV_TRANSPORT_OBSERVER_VALIDATION_PROVENANCE_JSON=""
QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH=""
if [[ "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]]; then
  for observer_env in \
    "$QKV_TRANSPORT_OBSERVER_MODE_ENV" \
    "$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR_ENV" \
    "$QKV_TRANSPORT_OBSERVER_SCALES_PATH_ENV" \
    "$QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID_ENV" \
    "$QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256_ENV" \
    "$QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT_ENV" \
    "$QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION_ENV" \
    "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION_ENV" \
    "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256_ENV"; do
    if [[ -v $observer_env ]]; then
      echo "$observer_env must be unset outside the explicit QKV calibration/validation actions" >&2
      exit 2
    fi
  done
else
  for runner_owned_env in \
    "$QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID_ENV" \
    "$QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256_ENV" \
    "$QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT_ENV" \
    "$QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION_ENV" \
    "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION_ENV" \
    "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256_ENV"; do
    if [[ -v $runner_owned_env ]]; then
      echo "$runner_owned_env is runner-owned and must be unset at launch" >&2
      exit 2
    fi
  done
  if [[ -v VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_MODE && \
        "$VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_MODE" != "$QKV_TRANSPORT_OBSERVER_MODE" ]]; then
    echo "$QKV_TRANSPORT_OBSERVER_MODE_ENV must match the explicit $QKV_TRANSPORT_OBSERVER_MODE action" >&2
    exit 2
  fi
  if [[ -v VLLM_OMNI_FLASHINFER_ULYSSES_QKV_E4M3_TRANSPORT && \
        "$VLLM_OMNI_FLASHINFER_ULYSSES_QKV_E4M3_TRANSPORT" != 0 ]]; then
    echo "QKV calibration/validation requires live E4M3 transport to be disabled" >&2
    exit 2
  fi
  QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR="${VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR:-$RUN_ROOT/qkv-transport-observer-$QKV_TRANSPORT_OBSERVER_MODE}"
  [[ "$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR" == /* ]] || {
    echo "$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR_ENV must be an absolute path" >&2
    exit 2
  }
  [[ "$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR" != "$RUN_ROOT" ]] || {
    echo "$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR_ENV must not be the result root" >&2
    exit 2
  }
  if [[ "$QKV_TRANSPORT_OBSERVER_MODE" == calibration ]]; then
    if [[ -v VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_SCALES_PATH ]]; then
      echo "$QKV_TRANSPORT_OBSERVER_SCALES_PATH_ENV must be unset during calibration" >&2
      exit 2
    fi
  else
    QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_PATH="${VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_SCALES_PATH:-}"
    [[ "$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_PATH" == /* ]] || {
      echo "$QKV_TRANSPORT_OBSERVER_SCALES_PATH_ENV must name an explicit absolute draft scale file for validation" >&2
      exit 2
    }
    [[ -f "$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_PATH" ]] || {
      echo "QKV validation draft scale file is missing: $QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_PATH" >&2
      exit 2
    }
    QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_SHA256="$(sha256sum "$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_PATH")"
    QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_SHA256="${QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_SHA256%% *}"
  fi
fi
if [[ "$FASTH3_SMOKE_MODE" == 1 || "$QKV_TRANSPORT_OBSERVER_MODE" != disabled || \
      "$ALL_MAIN_FP8_CONTRACT" == 1 || "$QUALITY_MOON_FACTORIAL_ACTION" == 1 ]]; then
  if [[ ( "$ALL_MAIN_FP8_CONTRACT" == 1 || \
          "$QUALITY_MOON_FACTORIAL_ACTION" == 1 ) && \
        -v VLLM_OMNI_UPLOAD_VIDEOS && "$VLLM_OMNI_UPLOAD_VIDEOS" != 0 ]]; then
    echo "The all-main/quality-factorial campaign requires VLLM_OMNI_UPLOAD_VIDEOS=0" >&2
    exit 2
  fi
  UPLOAD_VIDEOS=0
else
  UPLOAD_VIDEOS="${VLLM_OMNI_UPLOAD_VIDEOS:-1}"
fi
RANKINGS_REPO="${VLLM_OMNI_RANKINGS_REPO:-$WORKSPACE_DIR/vllm-omni-rankings}"
RANKINGS_BRANCH="${VLLM_OMNI_RANKINGS_BRANCH:-main}"
RANKINGS_WEB_BASE="${VLLM_OMNI_RANKINGS_WEB_BASE:-https://github.com/lishunyang12/vllm-omni-rankings}"
VAE_STREAM_TEMPORAL_CAT="${MINIMAX_H3_VAE_DECODER_STREAM_TEMPORAL_CAT:-1}"
GPU_UINT8_OUTPUT="${VLLM_OMNI_MINIMAX_H3_GPU_UINT8_OUTPUT:-0}"
[[ "$GPU_UINT8_OUTPUT" == 0 || "$GPU_UINT8_OUTPUT" == 1 ]] || {
  echo "VLLM_OMNI_MINIMAX_H3_GPU_UINT8_OUTPUT must be 0 or 1" >&2
  exit 2
}
if [[ "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 ]]; then
  CHUNKED_CPU_MP4_OUTPUT_DEFAULT=1
else
  CHUNKED_CPU_MP4_OUTPUT_DEFAULT=0
fi
CHUNKED_CPU_MP4_OUTPUT="${VLLM_OMNI_MINIMAX_H3_CHUNKED_CPU_MP4_OUTPUT:-$CHUNKED_CPU_MP4_OUTPUT_DEFAULT}"
[[ "$CHUNKED_CPU_MP4_OUTPUT" == 0 || "$CHUNKED_CPU_MP4_OUTPUT" == 1 ]] || {
  echo "VLLM_OMNI_MINIMAX_H3_CHUNKED_CPU_MP4_OUTPUT must be 0 or 1" >&2
  exit 2
}
CHUNKED_CPU_MP4_SLOTS="${VLLM_OMNI_MINIMAX_H3_CHUNKED_CPU_MP4_SLOTS:-2}"
[[ "$CHUNKED_CPU_MP4_SLOTS" == 1 || "$CHUNKED_CPU_MP4_SLOTS" == 2 ]] || {
  echo "VLLM_OMNI_MINIMAX_H3_CHUNKED_CPU_MP4_SLOTS must be 1 or 2" >&2
  exit 2
}
if [[ "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 ]]; then
  VSA_FUSED_LAYOUT_DEFAULT=1
else
  VSA_FUSED_LAYOUT_DEFAULT=0
fi
VSA_FUSED_TILE_PACK="${VLLM_OMNI_FASTVIDEO_VSA_FUSED_TILE_PACK:-$VSA_FUSED_LAYOUT_DEFAULT}"
[[ "$VSA_FUSED_TILE_PACK" == 0 || "$VSA_FUSED_TILE_PACK" == 1 ]] || {
  echo "VLLM_OMNI_FASTVIDEO_VSA_FUSED_TILE_PACK must be 0 or 1" >&2
  exit 2
}
VSA_FUSED_UNTILE="${VLLM_OMNI_FASTVIDEO_VSA_FUSED_UNTILE:-$VSA_FUSED_LAYOUT_DEFAULT}"
[[ "$VSA_FUSED_UNTILE" == 0 || "$VSA_FUSED_UNTILE" == 1 ]] || {
  echo "VLLM_OMNI_FASTVIDEO_VSA_FUSED_UNTILE must be 0 or 1" >&2
  exit 2
}
VSA_O_BUNDLE="${VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE:-0}"
if [[ ( "$TAEH3_OUTPUT" == 1 || "$QUALITY_MOON_FACTORIAL_ACTION" == 1 ) && \
      ! -v VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE ]]; then
  VSA_O_BUNDLE=1
fi
[[ "$VSA_O_BUNDLE" == 0 || "$VSA_O_BUNDLE" == 1 ]] || {
  echo "VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE must be 0 or 1" >&2
  exit 2
}
if [[ "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 ]]; then
  VSA_DIRECT_Q2K_DEFAULT=1
  if [[ "$VSA_O_BUNDLE" == 1 ]]; then
    # Stage-2 supersedes the old full-gate+untile epilogue. One explicit
    # O_BUNDLE opt-in is sufficient; an explicit fused-gate override still
    # reaches the mutual-exclusion guard below and fails closed.
    VSA_FUSED_GATE_UNTILE_DEFAULT=0
  else
    VSA_FUSED_GATE_UNTILE_DEFAULT=1
  fi
else
  VSA_DIRECT_Q2K_DEFAULT=0
  VSA_FUSED_GATE_UNTILE_DEFAULT=0
fi
VSA_DIRECT_Q2K="${VLLM_OMNI_FASTVIDEO_VSA_DIRECT_Q2K:-$VSA_DIRECT_Q2K_DEFAULT}"
[[ "$VSA_DIRECT_Q2K" == 0 || "$VSA_DIRECT_Q2K" == 1 ]] || {
  echo "VLLM_OMNI_FASTVIDEO_VSA_DIRECT_Q2K must be 0 or 1" >&2
  exit 2
}
VSA_FUSED_GATE_UNTILE="${VLLM_OMNI_FASTVIDEO_VSA_FUSED_GATE_UNTILE:-$VSA_FUSED_GATE_UNTILE_DEFAULT}"
[[ "$VSA_FUSED_GATE_UNTILE" == 0 || "$VSA_FUSED_GATE_UNTILE" == 1 ]] || {
  echo "VLLM_OMNI_FASTVIDEO_VSA_FUSED_GATE_UNTILE must be 0 or 1" >&2
  exit 2
}
VSA_DEFERRED_GATE_SP="${VLLM_OMNI_FASTVIDEO_VSA_DEFERRED_GATE_SP:-0}"
[[ "$VSA_DEFERRED_GATE_SP" == 0 || "$VSA_DEFERRED_GATE_SP" == 1 ]] || {
  echo "VLLM_OMNI_FASTVIDEO_VSA_DEFERRED_GATE_SP must be 0 or 1" >&2
  exit 2
}
VSA_GATE_COMPUTE_OVERLAP="${VLLM_OMNI_FASTVIDEO_VSA_GATE_COMPUTE_OVERLAP:-0}"
[[ "$VSA_GATE_COMPUTE_OVERLAP" == 0 || "$VSA_GATE_COMPUTE_OVERLAP" == 1 ]] || {
  echo "VLLM_OMNI_FASTVIDEO_VSA_GATE_COMPUTE_OVERLAP must be exactly 0 or 1" >&2
  exit 2
}
ULYSSES_MODE=strict
ULYSSES_RING_SIZE=1
H3_JOINT_ATTENTION_ROWS=0
FLASHINFER_O_PRODUCER_DIRECT="${VLLM_OMNI_FLASHINFER_ULYSSES_O_PRODUCER_DIRECT:-$VSA_FUSED_LAYOUT_DEFAULT}"
[[ "$FLASHINFER_O_PRODUCER_DIRECT" == 0 || "$FLASHINFER_O_PRODUCER_DIRECT" == 1 ]] || {
  echo "VLLM_OMNI_FLASHINFER_ULYSSES_O_PRODUCER_DIRECT must be 0 or 1" >&2
  exit 2
}
VAE_TEMPORAL_PRE_GATHER_PRUNE="${VLLM_OMNI_MINIMAX_H3_VAE_TEMPORAL_PRE_GATHER_PRUNE:-0}"
[[ "$VAE_TEMPORAL_PRE_GATHER_PRUNE" == 0 || "$VAE_TEMPORAL_PRE_GATHER_PRUNE" == 1 ]] || {
  echo "VLLM_OMNI_MINIMAX_H3_VAE_TEMPORAL_PRE_GATHER_PRUNE must be 0 or 1" >&2
  exit 2
}
VAE_TEMPORAL_CHUNK_PARALLEL="${VLLM_OMNI_MINIMAX_H3_VAE_TEMPORAL_CHUNK_PARALLEL:-0}"
[[ "$VAE_TEMPORAL_CHUNK_PARALLEL" == 0 || "$VAE_TEMPORAL_CHUNK_PARALLEL" == 1 ]] || {
  echo "VLLM_OMNI_MINIMAX_H3_VAE_TEMPORAL_CHUNK_PARALLEL must be 0 or 1" >&2
  exit 2
}
VAE_DECODER_TILE_SIZE="${VLLM_OMNI_MINIMAX_H3_VAE_DECODER_TILE_SIZE:-0}"
if [[ ! "$VAE_DECODER_TILE_SIZE" =~ ^(0|[1-9][0-9]*)$ ]] || \
   [[ "$VAE_DECODER_TILE_SIZE" != 0 && $((VAE_DECODER_TILE_SIZE % 16)) -ne 0 ]]; then
  echo "VLLM_OMNI_MINIMAX_H3_VAE_DECODER_TILE_SIZE must be 0 or a positive multiple of 16" >&2
  exit 2
fi
if [[ "$TAEH3_OUTPUT" == 1 ]]; then
  # The full-VAE exact-op kernels are not part of the TAEH3 decoder graph.
  VAE_EXACT_OPS_SM120_DEFAULT=0
elif [[ "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 ]]; then
  VAE_EXACT_OPS_SM120_DEFAULT=1
else
  VAE_EXACT_OPS_SM120_DEFAULT=0
fi
VAE_EXACT_OPS_SM120="${VLLM_OMNI_MINIMAX_H3_VAE_EXACT_OPS_SM120:-$VAE_EXACT_OPS_SM120_DEFAULT}"
[[ "$VAE_EXACT_OPS_SM120" == 0 || "$VAE_EXACT_OPS_SM120" == 1 ]] || {
  echo "VLLM_OMNI_MINIMAX_H3_VAE_EXACT_OPS_SM120 must be 0 or 1" >&2
  exit 2
}
if [[ "$GPU_UINT8_OUTPUT" == 1 && "$CHUNKED_CPU_MP4_OUTPUT" == 1 ]]; then
  echo "GPU uint8 full-clip transport and chunked CPU MP4 output are mutually exclusive" >&2
  exit 2
fi
if [[ "$VSA_FUSED_TILE_PACK" == 1 && "$FASTH3_VSA_MODE" != 1 ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_FUSED_TILE_PACK requires a FastH3 VSA action" >&2
  exit 2
fi
if [[ "$VSA_FUSED_UNTILE" == 1 && "$FASTH3_VSA_MODE" != 1 ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_FUSED_UNTILE requires a FastH3 VSA action" >&2
  exit 2
fi
if [[ "$VSA_FUSED_GATE_UNTILE" == 1 && "$FASTH3_VSA_MODE" != 1 ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_FUSED_GATE_UNTILE requires a FastH3 VSA action" >&2
  exit 2
fi
if [[ "$VSA_FUSED_GATE_UNTILE" == 1 && "$VSA_FUSED_UNTILE" != 1 ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_FUSED_GATE_UNTILE=1 requires VLLM_OMNI_FASTVIDEO_VSA_FUSED_UNTILE=1" >&2
  exit 2
fi
if [[ "$VSA_DEFERRED_GATE_SP" == 1 && "$FASTH3_VSA_MODE" != 1 ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_DEFERRED_GATE_SP=1 requires a FastH3 VSA action" >&2
  exit 2
fi
if [[ "$VSA_DEFERRED_GATE_SP" == 1 && "$VSA_FUSED_GATE_UNTILE" == 1 ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_DEFERRED_GATE_SP and VLLM_OMNI_FASTVIDEO_VSA_FUSED_GATE_UNTILE are mutually exclusive" >&2
  exit 2
fi
if [[ "$VSA_O_BUNDLE" == 1 && "$FASTH3_VSA_MODE" != 1 ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE=1 requires a FastH3 VSA action" >&2
  exit 2
fi
if [[ "$VSA_O_BUNDLE" == 1 && \
      "$CUMULATIVE_FASTH3_VSA_RDMA" != 1 ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE=1 is qualified only on the cumulative FastH3 VSA RDMA producer-direct action" >&2
  exit 2
fi
if [[ "$VSA_O_BUNDLE" == 1 && "$VSA_DEFERRED_GATE_SP" == 1 ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE and VLLM_OMNI_FASTVIDEO_VSA_DEFERRED_GATE_SP are mutually exclusive" >&2
  exit 2
fi
if [[ "$VSA_O_BUNDLE" == 1 && "$VSA_FUSED_GATE_UNTILE" == 1 ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE and VLLM_OMNI_FASTVIDEO_VSA_FUSED_GATE_UNTILE are mutually exclusive" >&2
  exit 2
fi
if [[ "$VSA_DIRECT_Q2K" == 1 && "$FASTH3_VSA_PROVIDER" != flashinfer ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_DIRECT_Q2K=1 requires the FlashInfer FastH3 VSA provider" >&2
  exit 2
fi
if [[ "$FLASHINFER_O_PRODUCER_DIRECT" == 1 && "$VSA_FUSED_UNTILE" != 1 ]]; then
  echo "VLLM_OMNI_FLASHINFER_ULYSSES_O_PRODUCER_DIRECT=1 requires VLLM_OMNI_FASTVIDEO_VSA_FUSED_UNTILE=1" >&2
  exit 2
fi
if [[ "$VSA_O_BUNDLE" == 1 && "$FLASHINFER_O_PRODUCER_DIRECT" != 1 ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE=1 requires VLLM_OMNI_FLASHINFER_ULYSSES_O_PRODUCER_DIRECT=1" >&2
  exit 2
fi
if [[ "$VAE_TEMPORAL_PRE_GATHER_PRUNE" == 1 && "$CHUNKED_CPU_MP4_OUTPUT" != 1 ]]; then
  echo "VLLM_OMNI_MINIMAX_H3_VAE_TEMPORAL_PRE_GATHER_PRUNE requires chunked CPU MP4 output" >&2
  exit 2
fi
if [[ "$VAE_TEMPORAL_CHUNK_PARALLEL" == 1 ]]; then
  [[ "$CHUNKED_CPU_MP4_OUTPUT" == 1 ]] || {
    echo "VLLM_OMNI_MINIMAX_H3_VAE_TEMPORAL_CHUNK_PARALLEL requires chunked CPU MP4 output" >&2
    exit 2
  }
  [[ "$VAE_TEMPORAL_PRE_GATHER_PRUNE" == 0 ]] || {
    echo "MiniMax H3 temporal chunk parallel and temporal pre-gather prune are mutually exclusive" >&2
    exit 2
  }
  [[ "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 ]] || {
    echo "MiniMax H3 temporal chunk parallel is qualified only on the cumulative FastH3 VSA action" >&2
    exit 2
  }
fi
if [[ "$VAE_DECODER_TILE_SIZE" != 0 && \
      "$CUMULATIVE_FASTH3_VSA_RDMA" != 1 ]]; then
  echo "MiniMax H3 VAE decoder tile-size override is qualified only on the cumulative FastH3 VSA action" >&2
  exit 2
fi
if [[ "$VAE_EXACT_OPS_SM120" == 1 && \
      "$CUMULATIVE_FASTH3_VSA_RDMA" != 1 ]]; then
  echo "MiniMax H3 SM120 VAE exact operators are qualified only on the cumulative FastH3 VSA action" >&2
  exit 2
fi
if [[ "$MLP_FP8_CONTRACT" == 1 ]]; then
  FP8_SCOPE_DEFAULT=mlp
elif [[ "$MLP_OUT_FP8_CONTRACT" == 1 ]]; then
  FP8_SCOPE_DEFAULT=mlp-out
elif [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 ]]; then
  FP8_SCOPE_DEFAULT=mlp-out-qkv
elif [[ "$ALL_MAIN_FP8_CONTRACT" == 1 ]]; then
  FP8_SCOPE_DEFAULT=all-main
else
  FP8_SCOPE_DEFAULT=none
fi
SELECTIVE_FP8_CONTRACT="$((MLP_FP8_CONTRACT + MLP_OUT_FP8_CONTRACT + MLP_OUT_QKV_FP8_CONTRACT + ALL_MAIN_FP8_CONTRACT))"
[[ "$SELECTIVE_FP8_CONTRACT" == 0 || "$SELECTIVE_FP8_CONTRACT" == 1 ]] || {
  echo "Exactly one selective-FP8 formal contract may be active" >&2
  exit 2
}
FP8_SCOPE="${VLLM_OMNI_MINIMAX_H3_FP8_SCOPE:-$FP8_SCOPE_DEFAULT}"
case "$FP8_SCOPE" in
  none|mlp|mlp-out|mlp-out-qkv|all-main) ;;
  *)
    echo "VLLM_OMNI_MINIMAX_H3_FP8_SCOPE must be one of none, mlp, mlp-out, mlp-out-qkv, all-main" >&2
    exit 2
    ;;
esac
if [[ "$MLP_FP8_CONTRACT" == 1 && "$FP8_SCOPE" != mlp ]]; then
  echo "The explicit MLP-FP8 action requires VLLM_OMNI_MINIMAX_H3_FP8_SCOPE=mlp" >&2
  exit 2
fi
if [[ "$MLP_OUT_FP8_CONTRACT" == 1 && "$FP8_SCOPE" != mlp-out ]]; then
  echo "The explicit MLP-OUT-FP8 action requires VLLM_OMNI_MINIMAX_H3_FP8_SCOPE=mlp-out" >&2
  exit 2
fi
if [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 && "$FP8_SCOPE" != mlp-out-qkv ]]; then
  echo "The explicit MLP-OUT-QKV-FP8 action requires VLLM_OMNI_MINIMAX_H3_FP8_SCOPE=mlp-out-qkv" >&2
  exit 2
fi
if [[ "$ALL_MAIN_FP8_CONTRACT" == 1 && "$FP8_SCOPE" != all-main ]]; then
  echo "The explicit ALL-MAIN-FP8 action requires VLLM_OMNI_MINIMAX_H3_FP8_SCOPE=all-main" >&2
  exit 2
fi
if [[ "$FP8_SCOPE" == mlp-out-qkv && "$MLP_OUT_QKV_FP8_CONTRACT" != 1 ]]; then
  echo "The formal mlp-out-qkv scope is reachable only through an explicit MLP-OUT-QKV-FP8 action" >&2
  exit 2
fi
if [[ "$FP8_SCOPE" == all-main && "$ALL_MAIN_FP8_CONTRACT" != 1 ]]; then
  echo "The formal all-main scope is reachable only through an explicit ALL-MAIN-FP8 action" >&2
  exit 2
fi
if [[ "$FP8_SCOPE" != none && \
      "$CUMULATIVE_FASTH3_VSA_RDMA" != 1 ]]; then
  echo "Selective H3 online FP8 is qualified only on the cumulative FastH3 VSA action" >&2
  exit 2
fi
if [[ "$ACTION" == tp1-sp8-fasth3-dense-adaln-rdma-qk-direct ]]; then
  QCHUNK_PIPELINE="${VLLM_OMNI_MINIMAX_H3_QCHUNK_PIPELINE:-2}"
else
  QCHUNK_PIPELINE="${VLLM_OMNI_MINIMAX_H3_QCHUNK_PIPELINE:-0}"
fi
if [[ "$VSA_DEFERRED_GATE_SP" == 1 && "$QCHUNK_PIPELINE" != 0 ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_DEFERRED_GATE_SP and MiniMax H3 qchunk are mutually exclusive" >&2
  exit 2
fi
if [[ "$VSA_O_BUNDLE" == 1 && "$QCHUNK_PIPELINE" != 0 ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE and MiniMax H3 qchunk are mutually exclusive" >&2
  exit 2
fi
if [[ "$PERSISTENT_RDMA" == 1 ]]; then
  FLASHINFER_RELEASE_AFTER_DENOISE_DEFAULT=0
elif [[ "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 ]]; then
  FLASHINFER_RELEASE_AFTER_DENOISE_DEFAULT=1
else
  FLASHINFER_RELEASE_AFTER_DENOISE_DEFAULT=0
fi
FLASHINFER_RELEASE_AFTER_DENOISE="${VLLM_OMNI_FLASHINFER_ULYSSES_RELEASE_AFTER_DENOISE:-$FLASHINFER_RELEASE_AFTER_DENOISE_DEFAULT}"
[[ "$FLASHINFER_RELEASE_AFTER_DENOISE" == 0 || "$FLASHINFER_RELEASE_AFTER_DENOISE" == 1 ]] || {
  echo "VLLM_OMNI_FLASHINFER_ULYSSES_RELEASE_AFTER_DENOISE must be 0 or 1" >&2
  exit 2
}
if [[ "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 && \
      "$FLASHINFER_RELEASE_AFTER_DENOISE" == 0 && "$CHUNKED_CPU_MP4_OUTPUT" != 1 ]]; then
  echo "Persistent FlashInfer Ulysses requires qualified chunked CPU MP4 output for this memory-tight SM120 rung" >&2
  exit 2
fi
DLO_TUNED_USE_ALLGATHER="${VLLM_OMNI_DLO_USE_ALLGATHER:-1}"
DLO_TUNED_RESIDENT_LAYERS="${VLLM_OMNI_DLO_RESIDENT_LAYERS:-0}"
ALLOW_SP8_LSA="${VLLM_OMNI_ALLOW_SP8_LSA:-0}"
FLASHINFER_PR_ENV="${VLLM_OMNI_FLASHINFER_PR_ENV:-$WORKSPACE_DIR/fi-pr4876-ulysses-env}"
FLASHINFER_PR_SITE="${VLLM_OMNI_FLASHINFER_PR_SITE:-$FLASHINFER_PR_ENV/site-packages}"
FLASHINFER_WORKSPACE="${VLLM_OMNI_FLASHINFER_WORKSPACE:-$FLASHINFER_PR_ENV/workspace}"
FLASHINFER_EXPECTED_VERSION="0.6.18+pr4876.a6eaf786"
FLASHINFER_EXPECTED_COMMIT="a6eaf78620dddc2ecbbde9a5253d4a52ef3a1951"
FASTVIDEO_KERNEL_PYTHON="${VLLM_OMNI_FASTVIDEO_KERNEL_PYTHON:-$WORKSPACE_DIR/FastVideo/fastvideo-kernel/python}"
FLASHINFER_VSA_ROOT="${VLLM_OMNI_FLASHINFER_VSA_ROOT:-$WORKSPACE_DIR/fi-pr4944-pr4876-combined}"
FLASHINFER_VSA_EXPECTED_COMMIT=f841539c496788eb0221dec2736d0886d1c90ebd
FLASHINFER_VSA_WORKSPACE="${VLLM_OMNI_FLASHINFER_VSA_WORKSPACE:-$WORKSPACE_DIR/.flashinfer-pr4944-pr4876-vllm028-cache}"
# A process cannot import PR #4876 from the legacy overlay and PR #4944 from
# the combined source tree at the same time.  Pin the cumulative action to the
# single checkout containing both changes so import ordering cannot silently
# select only one half of the stack.
if [[ "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 ]]; then
  FLASHINFER_PR_SITE="$FLASHINFER_VSA_ROOT"
  FLASHINFER_WORKSPACE="$FLASHINFER_VSA_WORKSPACE"
  FLASHINFER_EXPECTED_VERSION=0.6.18
  FLASHINFER_EXPECTED_COMMIT="$FLASHINFER_VSA_EXPECTED_COMMIT"
fi
# Size the registered window from the exact prompt packing profile. Stage-2
# appends one fixed kmax tail to every rank's reverse-O operand.
FLASHINFER_BASE_REQUIRED_BYTES="$VSA_ELIDED_GATE_OPERAND_BYTES"
FLASHINFER_O_BUNDLE_REQUIRED_BYTES=$((
  VSA_O_BUNDLE_CONSUMER_ROWS * 56 * 128 * 2
))
if [[ "$VSA_O_BUNDLE" == 1 ]]; then
  FLASHINFER_REQUIRED_BYTES="$FLASHINFER_O_BUNDLE_REQUIRED_BYTES"
else
  FLASHINFER_REQUIRED_BYTES="$FLASHINFER_BASE_REQUIRED_BYTES"
fi
FLASHINFER_MAX_BYTES="${VLLM_OMNI_FLASHINFER_ULYSSES_MAX_BYTES:-$FLASHINFER_REQUIRED_BYTES}"
FLASHINFER_ULYSSES_ROUTE="${VLLM_OMNI_FLASHINFER_ULYSSES_ROUTE:-rdma}"
case "$FLASHINFER_ULYSSES_ROUTE" in
  rdma|hybrid) ;;
  *)
    echo "VLLM_OMNI_FLASHINFER_ULYSSES_ROUTE must be rdma or hybrid" >&2
    exit 2
    ;;
esac
if [[ "$VSA_O_BUNDLE" == 1 && "$FLASHINFER_ULYSSES_ROUTE" != rdma ]]; then
  echo "VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE=1 is qualified only with VLLM_OMNI_FLASHINFER_ULYSSES_ROUTE=rdma" >&2
  exit 2
fi
if [[ "$VSA_GATE_COMPUTE_OVERLAP" == 1 ]]; then
  [[ "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 && "$FASTH3_VSA_MODE" == 1 && \
        "$FASTH3_VSA_PROVIDER" == flashinfer ]] || {
    echo "VSA gate-compute overlap requires the cumulative FlashInfer FastH3 VSA action" >&2
    exit 2
  }
  [[ "$QKV_E4M3_TRANSPORT" == 1 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] || {
    echo "VSA gate-compute overlap requires calibrated E4M3 Q/K/V producer-direct transport" >&2
    exit 2
  }
  [[ "$FLASHINFER_ULYSSES_ROUTE" == rdma && "$FLASHINFER_O_PRODUCER_DIRECT" == 1 ]] || {
    echo "VSA gate-compute overlap requires FlashInfer all-RDMA and reverse-O producer-direct landing" >&2
    exit 2
  }
  [[ "$VSA_O_BUNDLE" == 1 && "$VSA_DIRECT_Q2K" == 1 && \
        "$VSA_FUSED_TILE_PACK" == 1 && "$VSA_FUSED_UNTILE" == 1 ]] || {
    echo "VSA gate-compute overlap requires the exact direct-Q2K fused-layout reverse-O bundle route" >&2
    exit 2
  }
  [[ "$QCHUNK_PIPELINE" == 0 && "$VSA_DEFERRED_GATE_SP" == 0 && \
        "$VSA_FUSED_GATE_UNTILE" == 0 ]] || {
    echo "VSA gate-compute overlap is incompatible with qchunk, deferred-gate SP, or fused gate+untile" >&2
    exit 2
  }
  [[ "$ULYSSES_MODE" == strict && "$ULYSSES_RING_SIZE" == 1 && \
        "$H3_JOINT_ATTENTION_ROWS" == 0 ]] || {
    echo "VSA gate-compute overlap requires strict non-Ring Ulysses with joint rows disabled" >&2
    exit 2
  }
fi
if [[ "$TAEH3_OUTPUT" == 1 ]]; then
  if [[ "$PERSISTENT_RDMA" == 1 ]]; then
    TAEH3_REQUIRED_RELEASE_AFTER_DENOISE=0
  else
    TAEH3_REQUIRED_RELEASE_AFTER_DENOISE=1
  fi
  [[ "$GPU_UINT8_OUTPUT" == 0 && "$CHUNKED_CPU_MP4_OUTPUT" == 1 && \
        "$CHUNKED_CPU_MP4_SLOTS" == 2 ]] || {
    echo "The TAEH3 action requires full-clip GPU uint8 off and chunked CPU MP4 slots=2" >&2
    exit 2
  }
  [[ "$VSA_O_BUNDLE" == 1 && "$VSA_FUSED_TILE_PACK" == 1 && \
        "$VSA_FUSED_UNTILE" == 1 && "$VSA_FUSED_GATE_UNTILE" == 0 && \
        "$VSA_DEFERRED_GATE_SP" == 0 && "$VSA_DIRECT_Q2K" == 1 ]] || {
    echo "The TAEH3 action requires the exact fused-layout reverse-O bundle VSA route" >&2
    exit 2
  }
  [[ "$VSA_GATE_COMPUTE_OVERLAP" == 0 ]] || {
    echo "The TAEH3 action excludes the gate-compute overlap experiment that failed its early-stop gate" >&2
    exit 2
  }
  [[ "$FLASHINFER_O_PRODUCER_DIRECT" == 1 && \
        "$FLASHINFER_ULYSSES_ROUTE" == rdma && \
        "$FLASHINFER_RELEASE_AFTER_DENOISE" == "$TAEH3_REQUIRED_RELEASE_AFTER_DENOISE" ]] || {
    echo "The TAEH3 action requires RDMA Q/K/O producer-direct execution and VLLM_OMNI_FLASHINFER_ULYSSES_RELEASE_AFTER_DENOISE=$TAEH3_REQUIRED_RELEASE_AFTER_DENOISE" >&2
    exit 2
  }
  [[ "$QCHUNK_PIPELINE" == 0 && "$VAE_TEMPORAL_PRE_GATHER_PRUNE" == 0 && \
        "$VAE_TEMPORAL_CHUNK_PARALLEL" == 0 && "$VAE_DECODER_TILE_SIZE" == 0 && \
        "$VAE_EXACT_OPS_SM120" == 0 ]] || {
    echo "The TAEH3 action must not inherit full-H3-VAE/qchunk experiments" >&2
    exit 2
  }
  if [[ "$QUALITY_MOON_BF16_FACTORIAL" == 1 ]]; then
    [[ "$FP8_SCOPE" == none && "$SELECTIVE_FP8_CONTRACT" == 0 && \
          "$QKV_E4M3_TRANSPORT" == 0 && \
          "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] || {
      echo "The Moon BF16/TAEH3 factorial action requires BF16 compute and BF16 QKV wire" >&2
      exit 2
    }
  elif [[ "$QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL" == 1 ]]; then
    [[ "$ALL_MAIN_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == all-main && \
          "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] || {
      echo "The Moon all-main-FP8/TAEH3 factorial action requires its exact FP8 compute scope with the observer disabled" >&2
      exit 2
    }
  elif [[ "$ACTION" == "$MLP_FP8_BF16_WIRE_E2E_ACTION" ]]; then
    [[ "$MLP_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp && \
          "$QKV_E4M3_TRANSPORT" == 0 && \
          "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] || {
      echo "The MLP-only E2E action requires exactly FC1/FC2 FP8 with BF16 QKV transport" >&2
      exit 2
    }
  else
    if [[ "$MLP_OUT_QKV_FP8_CONTRACT" != 1 || "$FP8_SCOPE" != mlp-out-qkv ]] && \
       [[ "$ALL_MAIN_FP8_CONTRACT" != 1 || "$FP8_SCOPE" != all-main ]]; then
      echo "The TAEH3 action requires an exact explicit online-FP8 scope" >&2
      exit 2
    fi
    [[ "$QKV_E4M3_TRANSPORT" == 1 && \
          "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] || {
      echo "The TAEH3 action requires a newly bound E4M3 QKV contract" >&2
      exit 2
    }
  fi
fi
if [[ "$ALL_MAIN_FP8_CONTRACT" == 1 ]]; then
  case "$ACTION" in
    "$ALL_MAIN_FP8_CALIBRATION_ACTION")
      [[ "$QKV_TRANSPORT_OBSERVER_MODE" == calibration && \
            "$QKV_E4M3_TRANSPORT" == 0 && "$TAEH3_OUTPUT" == 0 ]] || {
        echo "The all-main calibration action requires its BF16-wire observer and no output rung" >&2
        exit 2
      }
      ;;
    "$ALL_MAIN_FP8_VALIDATION_ACTION")
      [[ "$QKV_TRANSPORT_OBSERVER_MODE" == validation && \
            "$QKV_E4M3_TRANSPORT" == 0 && "$TAEH3_OUTPUT" == 0 ]] || {
        echo "The all-main validation action requires its BF16-wire observer and no output rung" >&2
        exit 2
      }
      ;;
    "$QUALITY_MOON_ALL_MAIN_FP8_FULL_VAE_ACTION")
      [[ "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
            "$QKV_E4M3_TRANSPORT" == 1 && "$TAEH3_OUTPUT" == 0 && \
            "$VSA_O_BUNDLE" == 1 ]] || {
        echo "Moon Q1D0 requires calibrated E4M3, O-bundle, and the full H3 VAE" >&2
        exit 2
      }
      ;;
    "$QUALITY_MOON_ALL_MAIN_FP8_TAEH3_FP16_ACTION")
      [[ "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
            "$QKV_E4M3_TRANSPORT" == 1 && "$TAEH3_OUTPUT" == 1 && \
            "$TAEH3_DTYPE" == fp16 && "$VSA_O_BUNDLE" == 1 ]] || {
        echo "Moon Q1D1 requires calibrated E4M3, O-bundle, and TAEH3 FP16" >&2
        exit 2
      }
      ;;
    "$QUALITY_MOON_ALL_MAIN_FP8_BF16_WIRE_FULL_VAE_ACTION")
      [[ "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
            "$QKV_E4M3_TRANSPORT" == 0 && "$TAEH3_OUTPUT" == 0 && \
            "$VSA_O_BUNDLE" == 1 ]] || {
        echo "Moon FP8-compute diagnostic requires BF16 QKV wire, O-bundle, and the full H3 VAE" >&2
        exit 2
      }
      ;;
    "$QUALITY_MOON_ALL_MAIN_FP8_BF16_WIRE_TAEH3_FP16_ACTION")
      [[ "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
            "$QKV_E4M3_TRANSPORT" == 0 && "$TAEH3_OUTPUT" == 1 && \
            "$TAEH3_DTYPE" == fp16 && "$VSA_O_BUNDLE" == 1 ]] || {
        echo "Moon qmid_d1 requires BF16 QKV wire, O-bundle, and TAEH3 FP16" >&2
        exit 2
      }
      ;;
    "$ALL_MAIN_FP8_FINAL_ACTION"|"$ALL_MAIN_FP8_PERSISTENT_ACTION"|\
    "$TAEH3_AUDIO_OVERLAP_ACTION"|\
    "$TAEH3_CROSS_RANK_AUDIO_ACTION"|\
    "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTION"|\
    "$QKV_SINGLE_PHASE_ALL_MAIN_PERSISTENT_ACTION")
      [[ "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
            "$QKV_E4M3_TRANSPORT" == 1 && "$TAEH3_OUTPUT" == 1 && \
            "$TAEH3_DTYPE" == fp16 && "$VSA_O_BUNDLE" == 1 ]] || {
        echo "The all-main final action requires calibrated E4M3, O-bundle, and TAEH3 FP16" >&2
        exit 2
      }
      ;;
    *)
      echo "ALL-MAIN-FP8 is restricted to its calibration, validation, Moon qmid/Q1 quality actions, final, and persistent-RDMA actions" >&2
      exit 2
      ;;
  esac
  if [[ "$ACTION" == "$QKV_SINGLE_PHASE_ALL_MAIN_PERSISTENT_ACTION" ]]; then
    [[ "$QKV_SINGLE_PHASE" == 1 && "$PERSISTENT_RDMA" == 1 ]] || {
      echo "The all-main persistent QKV single-phase action lost one of its internal opt-ins" >&2
      exit 2
    }
  else
    [[ "$QKV_SINGLE_PHASE" == 0 ]] || {
      echo "QKV single-phase is restricted to its explicit all-main cumulative action" >&2
      exit 2
    }
  fi
  if [[ "$ACTION" == "$TAEH3_AUDIO_OVERLAP_ACTION" ]]; then
    [[ "$TAEH3_AUDIO_DECODE_OVERLAP" == 1 && "$PERSISTENT_RDMA" == 1 && \
          "$QKV_SINGLE_PHASE" == 0 ]] || {
      echo "The TAEH3/audio overlap action requires persistent RDMA and excludes QKV single-phase" >&2
      exit 2
    }
  else
    [[ "$TAEH3_AUDIO_DECODE_OVERLAP" == 0 ]] || {
      echo "TAEH3/audio overlap must not leak into another ALL-MAIN-FP8 action" >&2
      exit 2
    }
  fi
  if [[ "$ACTION" == "$TAEH3_CROSS_RANK_AUDIO_ACTION" || \
        "$ACTION" == "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTION" ]]; then
    [[ "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 1 && "$PERSISTENT_RDMA" == 1 && \
          "$TAEH3_AUDIO_DECODE_OVERLAP" == 0 && "$QKV_SINGLE_PHASE" == 0 ]] || {
      echo "The TAEH3 cross-rank audio action requires persistent RDMA and excludes the other scheduling candidates" >&2
      exit 2
    }
  else
    [[ "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 0 ]] || {
      echo "TAEH3 cross-rank audio must not leak into another ALL-MAIN-FP8 action" >&2
      exit 2
    }
  fi
  if [[ "$ACTION" == "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTION" ]]; then
    [[ "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 1 ]] || {
      echo "The TAEH3 cross-rank AAC action lost its packet-encoding opt-in" >&2
      exit 2
    }
  else
    [[ "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 0 ]] || {
      echo "TAEH3 cross-rank AAC must not leak into another ALL-MAIN-FP8 action" >&2
      exit 2
    }
  fi
fi
if [[ "$QKV_SINGLE_PHASE" == 1 ]]; then
  [[ "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 && \
        "$FASTH3_VSA_MODE" == 1 && "$FASTH3_VSA_PROVIDER" == flashinfer && \
        "$FASTH3_VSA_TOPK" == 162 ]] || {
    echo "QKV single-phase requires its exact cumulative FastH3 VSA top-k 162 action" >&2
    exit 2
  }
  [[ "$QKV_E4M3_TRANSPORT" == 1 && \
        "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
        "$FLASHINFER_ULYSSES_ROUTE" == rdma && \
        "$FLASHINFER_O_PRODUCER_DIRECT" == 1 && \
        "$FLASHINFER_RELEASE_AFTER_DENOISE" == "$((1 - PERSISTENT_RDMA))" ]] || {
    echo "QKV single-phase requires calibrated E4M3 all-RDMA Q/K/V and producer-direct reverse-O" >&2
    exit 2
  }
  [[ "$VSA_O_BUNDLE" == 1 && "$VSA_DIRECT_Q2K" == 1 && \
        "$VSA_FUSED_TILE_PACK" == 1 && "$VSA_FUSED_UNTILE" == 1 && \
        "$VSA_FUSED_GATE_UNTILE" == 0 && "$VSA_DEFERRED_GATE_SP" == 0 && \
        "$VSA_GATE_COMPUTE_OVERLAP" == 0 && "$QCHUNK_PIPELINE" == 0 ]] || {
    echo "QKV single-phase requires the exact fused-layout O-bundle route and forbids alternate Q/VSA schedules" >&2
    exit 2
  }
  [[ "$TAEH3_OUTPUT" == 1 && "$TAEH3_DTYPE" == fp16 && \
        "$CHUNKED_CPU_MP4_OUTPUT" == 1 && "$CHUNKED_CPU_MP4_SLOTS" == 2 && \
        "$GPU_UINT8_OUTPUT" == 0 && "$VAE_EXACT_OPS_SM120" == 0 ]] || {
    echo "QKV single-phase must stack on the exact TAEH3 FP16 best output path" >&2
    exit 2
  }
  [[ "$DENOISER_EVALUATIONS" == 4 && \
        "$QKV_SINGLE_PHASE_EXPECTED_CALLS_PER_WORKER_PER_REQUEST" == \
          $((DENOISER_EVALUATIONS * 50)) ]] || {
    echo "QKV single-phase expected-call provenance must remain four forwards x 50 main blocks" >&2
    exit 2
  }
fi

PYTHON="$VLLM_VENV/bin/python"
VLLM="$VLLM_VENV/bin/vllm"
FFPROBE="${VLLM_OMNI_FFPROBE:-$WORKSPACE_DIR/ffmpeg-tools/bin/ffprobe}"
ADALN_BUILDER="$VLLM_SOURCE/tools/minimax_h3/build_adaln_cache.py"
QKV_TRANSPORT_SCALE_BUILDER="$VLLM_SOURCE/tools/minimax_h3/build_qkv_transport_scales.py"
GPU_BALANCE_SCRIPT="${VLLM_OMNI_GPU_BALANCE_SCRIPT:-$VLLM_SOURCE/tools/minimax_h3/benchmark_h3_cudnn_sdpa_balance.py}"
GPU_HEALTH_GATE_SOURCE="$SCRIPT_DIR/scripts/benchmark_h3_gpu_health_gate.py"
PROMPT_FILE="${VLLM_OMNI_H3_PROMPT_FILE:-}"
if [[ -n "$PROMPT_FILE" ]]; then
  [[ "$PROMPT_FILE" == /* && -f "$PROMPT_FILE" ]] || {
    echo "VLLM_OMNI_H3_PROMPT_FILE must name an absolute regular file" >&2
    exit 2
  }
  PROMPT="$(<"$PROMPT_FILE")"
  [[ -n "$PROMPT" ]] || {
    echo "VLLM_OMNI_H3_PROMPT_FILE must not be empty" >&2
    exit 2
  }
else
  PROMPT='傍晚小厨房的真人实拍的手 与手绘发光2d动画 融合在一起的影像。夕阳余晖残留在窗边，生活感十足的小厨房里有旧木桌、洗到一半的马克杯、起雾的玻璃瓶、悬挂的抹布。画面带有智能手机单手拍摄的手抖、近距离对焦的犹豫、逆光曝光波动。要像在家中慌忙拍下某个不可思议事件的自然质感，不要广告影像的精心整理。声音只用厨房环境声与手绘生物柔和的电子音、小小的叫声。'
fi

if [[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 ]]; then
  observed_quality_prompt_sha256="$(printf '%s' "$PROMPT" | sha256sum)"
  observed_quality_prompt_sha256="${observed_quality_prompt_sha256%% *}"
  [[ -n "$PROMPT_FILE" && \
        "$observed_quality_prompt_sha256" == "$QUALITY_MOON_PROMPT_SHA256" && \
        "$QKV_E4M3_PROMPT_SHA256" == "$QUALITY_MOON_PROMPT_SHA256" ]] || {
    echo "Moon quality-factorial actions require the exact prompt payload SHA256 $QUALITY_MOON_PROMPT_SHA256" >&2
    exit 2
  }
  [[ "$WIDTH" == 1280 && "$HEIGHT" == 720 && "$STEPS" == 4 && \
        "$DENOISER_EVALUATIONS" == 4 && "$FASTH3_VSA_TOPK" == 162 && \
        "$QKV_E4M3_PREFIX_TILE_COUNT" == 27 && \
        "$QKV_E4M3_COMPACT_ROW_COUNT" == 95823 && \
        "$QKV_E4M3_PADDED_ROW_COUNT" == 105408 && \
        "$QKV_E4M3_SEQUENCE_ROW_COUNT" == 95872 && \
        "$QKV_E4M3_LOCAL_ROW_COUNT" == 11984 && \
        "$VSA_O_BUNDLE_KMAX" == 279 ]] || {
    echo "Moon quality-factorial actions require the exact 362-frame full-prompt packing geometry" >&2
    exit 2
  }
  [[ "$WARMUPS" == 0 && "$REPEATS" == 1 && "$UPLOAD_VIDEOS" == 0 && \
        "$PERSISTENT_RDMA" == 0 && "$FLASHINFER_RELEASE_AFTER_DENOISE" == 1 && \
        "$QKV_SINGLE_PHASE" == 0 && "$VSA_O_BUNDLE" == 1 && \
        "$VSA_FUSED_TILE_PACK" == 1 && "$VSA_FUSED_UNTILE" == 1 && \
        "$VSA_FUSED_GATE_UNTILE" == 0 && "$VSA_DEFERRED_GATE_SP" == 0 && \
        "$VSA_GATE_COMPUTE_OVERLAP" == 0 && "$VSA_DIRECT_Q2K" == 1 && \
        "$FLASHINFER_O_PRODUCER_DIRECT" == 1 && \
        "$FLASHINFER_ULYSSES_ROUTE" == rdma && "$QCHUNK_PIPELINE" == 0 && \
        "$TAEH3_AUDIO_DECODE_OVERLAP" == 0 && \
        "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 0 && \
        "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 0 ]] || {
    echo "Moon quality-factorial actions require the one-shot non-persistent O-bundle contract" >&2
    exit 2
  }
  case "$ACTION" in
    "$QUALITY_MOON_BF16_FULL_VAE_ACTION")
      [[ "$QUALITY_MOON_BF16_FACTORIAL" == 1 && \
            "$SELECTIVE_FP8_CONTRACT" == 0 && "$FP8_SCOPE" == none && \
            "$QKV_E4M3_TRANSPORT" == 0 && \
            "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
            "$TAEH3_OUTPUT" == 0 && "$TAEH3_VIDEO_DECODE_BACKEND" == h3-vae && \
            "$VAE_PATCH_PARALLEL_SIZE" == 8 && "$VAE_EXACT_OPS_SM120" == 1 ]] || {
        echo "Moon Q0D0 requires BF16 compute/wire and the full H3 VAE" >&2
        exit 2
      }
      ;;
    "$QUALITY_MOON_BF16_TAEH3_FP32_ACTION")
      [[ "$QUALITY_MOON_BF16_FACTORIAL" == 1 && \
            "$SELECTIVE_FP8_CONTRACT" == 0 && "$FP8_SCOPE" == none && \
            "$QKV_E4M3_TRANSPORT" == 0 && \
            "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
            "$TAEH3_OUTPUT" == 1 && "$TAEH3_DTYPE" == fp32 && \
            "$VAE_PATCH_PARALLEL_SIZE" == 1 && "$VAE_EXACT_OPS_SM120" == 0 ]] || {
        echo "Moon Q0D1 requires BF16 compute/wire and TAEH3 FP32 only" >&2
        exit 2
      }
      ;;
    "$QUALITY_MOON_BF16_TAEH3_FP16_ACTION")
      [[ "$QUALITY_MOON_BF16_FACTORIAL" == 1 && \
            "$SELECTIVE_FP8_CONTRACT" == 0 && "$FP8_SCOPE" == none && \
            "$QKV_E4M3_TRANSPORT" == 0 && \
            "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
            "$TAEH3_OUTPUT" == 1 && "$TAEH3_DTYPE" == fp16 && \
            "$VAE_PATCH_PARALLEL_SIZE" == 1 && "$VAE_EXACT_OPS_SM120" == 0 ]] || {
        echo "Moon Q0D2 requires BF16 compute/wire and TAEH3 FP16 only" >&2
        exit 2
      }
      ;;
    "$QUALITY_MOON_ALL_MAIN_FP8_FULL_VAE_ACTION")
      [[ "$QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL" == 1 && \
            "$ALL_MAIN_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == all-main && \
            "$QKV_E4M3_TRANSPORT" == 1 && \
            "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
            "$TAEH3_OUTPUT" == 0 && "$TAEH3_VIDEO_DECODE_BACKEND" == h3-vae && \
            "$VAE_PATCH_PARALLEL_SIZE" == 8 && "$VAE_EXACT_OPS_SM120" == 1 && \
            "$QKV_E4M3_SCALE_SIDECAR" == \
              "$QUALITY_MOON_ALL_MAIN_FP8_SCALE_SIDECAR" && \
            "$QKV_E4M3_EXPECTED_WHOLE_SHA256" == \
              "$QUALITY_MOON_ALL_MAIN_FP8_EXPECTED_WHOLE_SHA256" && \
            "$QKV_E4M3_EXPECTED_PAYLOAD_SHA256" == \
              "$QUALITY_MOON_ALL_MAIN_FP8_EXPECTED_PAYLOAD_SHA256" ]] || {
        echo "Moon Q1D0 requires the exact all-main/E4M3 sidecar and full H3 VAE" >&2
        exit 2
      }
      ;;
    "$QUALITY_MOON_ALL_MAIN_FP8_TAEH3_FP16_ACTION")
      [[ "$QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL" == 1 && \
            "$ALL_MAIN_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == all-main && \
            "$QKV_E4M3_TRANSPORT" == 1 && \
            "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
            "$TAEH3_OUTPUT" == 1 && "$TAEH3_DTYPE" == fp16 && \
            "$VAE_PATCH_PARALLEL_SIZE" == 1 && "$VAE_EXACT_OPS_SM120" == 0 && \
            "$QKV_E4M3_SCALE_SIDECAR" == \
              "$QUALITY_MOON_ALL_MAIN_FP8_SCALE_SIDECAR" && \
            "$QKV_E4M3_EXPECTED_WHOLE_SHA256" == \
              "$QUALITY_MOON_ALL_MAIN_FP8_EXPECTED_WHOLE_SHA256" && \
            "$QKV_E4M3_EXPECTED_PAYLOAD_SHA256" == \
              "$QUALITY_MOON_ALL_MAIN_FP8_EXPECTED_PAYLOAD_SHA256" ]] || {
        echo "Moon Q1D1 requires the exact all-main/E4M3 sidecar and TAEH3 FP16 only" >&2
        exit 2
      }
      ;;
    "$QUALITY_MOON_ALL_MAIN_FP8_BF16_WIRE_FULL_VAE_ACTION")
      [[ "$QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL" == 1 && \
            "$ALL_MAIN_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == all-main && \
            "$QKV_E4M3_TRANSPORT" == 0 && \
            "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
            "$TAEH3_OUTPUT" == 0 && "$TAEH3_VIDEO_DECODE_BACKEND" == h3-vae && \
            "$VAE_PATCH_PARALLEL_SIZE" == 8 && "$VAE_EXACT_OPS_SM120" == 1 ]] || {
        echo "Moon FP8-compute diagnostic requires all-main FP8, BF16 QKV wire, and the full H3 VAE" >&2
        exit 2
      }
      ;;
    "$QUALITY_MOON_ALL_MAIN_FP8_BF16_WIRE_TAEH3_FP16_ACTION")
      [[ "$QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL" == 1 && \
            "$ALL_MAIN_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == all-main && \
            "$QKV_E4M3_TRANSPORT" == 0 && \
            "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
            "$TAEH3_OUTPUT" == 1 && "$TAEH3_DTYPE" == fp16 && \
            "$VAE_PATCH_PARALLEL_SIZE" == 1 && "$VAE_EXACT_OPS_SM120" == 0 ]] || {
        echo "Moon qmid_d1 requires all-main FP8, BF16 QKV wire, and TAEH3 FP16 only" >&2
        exit 2
      }
      ;;
    *)
      echo "Internal Moon quality-factorial action registration mismatch" >&2
      exit 2
      ;;
  esac
fi

# Record the two independent quality factors explicitly.  These labels are
# metadata only; the fail-closed assertions above remain the source of truth.
QUALITY_MOON_Q_FACTOR=not_applicable
QUALITY_MOON_D_FACTOR=not_applicable
if [[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 ]]; then
  if [[ "$QUALITY_MOON_BF16_FACTORIAL" == 1 ]]; then
    QUALITY_MOON_Q_FACTOR=bf16_compute_bf16_qkv_wire
  elif [[ "$QKV_E4M3_TRANSPORT" == 1 ]]; then
    QUALITY_MOON_Q_FACTOR=all_main_fp8_e4m3_qkv_wire
  else
    QUALITY_MOON_Q_FACTOR=all_main_fp8_bf16_qkv_wire
  fi
  if [[ "$TAEH3_OUTPUT" == 0 ]]; then
    QUALITY_MOON_D_FACTOR=full_h3_vae
  else
    QUALITY_MOON_D_FACTOR="taeh3_${TAEH3_DTYPE}"
  fi
fi

MLP_FP8_CONFIG_JSON=""
MLP_FP8_CONFIG_SHA256=""
MLP_FP8_CONTRACT_JSON=""
MLP_FP8_CONTRACT_SHA256=""
MLP_FP8_DIT_QUANT_MODE=bf16
if [[ "$FP8_SCOPE" == mlp ]]; then
  MLP_FP8_CONFIG_JSON="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_mlp_fp8_quantization_config_json; print(minimax_h3_mlp_fp8_quantization_config_json())' \
    | tail -n 1)" || {
      echo "Failed to resolve the canonical MiniMax H3 MLP-FP8 config" >&2
      exit 2
    }
  MLP_FP8_CONFIG_SHA256="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_mlp_fp8_config_sha256; print(minimax_h3_mlp_fp8_config_sha256())' \
    | tail -n 1)" || {
      echo "Failed to hash the canonical MiniMax H3 MLP-FP8 config" >&2
      exit 2
    }
  MLP_FP8_CONTRACT_JSON="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_mlp_fp8_contract_json; print(minimax_h3_mlp_fp8_contract_json())' \
    | tail -n 1)" || {
      echo "Failed to resolve the canonical MiniMax H3 MLP-FP8 contract" >&2
      exit 2
    }
  MLP_FP8_CONTRACT_SHA256="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_mlp_fp8_contract_sha256; print(minimax_h3_mlp_fp8_contract_sha256())' \
    | tail -n 1)" || {
      echo "Failed to hash the canonical MiniMax H3 MLP-FP8 contract" >&2
      exit 2
    }
  MLP_FP8_DIT_QUANT_MODE="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import MINIMAX_H3_MLP_FP8_DIT_QUANT_MODE; print(MINIMAX_H3_MLP_FP8_DIT_QUANT_MODE)' \
    | tail -n 1)" || {
      echo "Failed to resolve the canonical MiniMax H3 MLP-FP8 mode" >&2
      exit 2
    }
  [[ "$MLP_FP8_CONFIG_SHA256" =~ ^[0-9a-f]{64}$ && \
        "$MLP_FP8_CONTRACT_SHA256" =~ ^[0-9a-f]{64}$ ]] || {
      echo "Canonical MiniMax H3 MLP-FP8 digests are malformed" >&2
      exit 2
    }
  export VLLM_OMNI_MINIMAX_H3_FP8_SCOPE=mlp
  export VLLM_OMNI_MINIMAX_H3_FP8_CONFIG_SHA256="$MLP_FP8_CONFIG_SHA256"
  export VLLM_OMNI_MINIMAX_H3_FP8_CONTRACT_SHA256="$MLP_FP8_CONTRACT_SHA256"
elif [[ "$FP8_SCOPE" == mlp-out ]]; then
  MLP_FP8_CONFIG_JSON="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_mlp_out_fp8_quantization_config_json; print(minimax_h3_mlp_out_fp8_quantization_config_json())' \
    | tail -n 1)" || {
      echo "Failed to resolve the canonical MiniMax H3 MLP-OUT-FP8 config" >&2
      exit 2
    }
  MLP_FP8_CONFIG_SHA256="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_mlp_out_fp8_config_sha256; print(minimax_h3_mlp_out_fp8_config_sha256())' \
    | tail -n 1)" || {
      echo "Failed to hash the canonical MiniMax H3 MLP-OUT-FP8 config" >&2
      exit 2
    }
  MLP_FP8_CONTRACT_JSON="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_mlp_out_fp8_contract_json; print(minimax_h3_mlp_out_fp8_contract_json())' \
    | tail -n 1)" || {
      echo "Failed to resolve the canonical MiniMax H3 MLP-OUT-FP8 contract" >&2
      exit 2
    }
  MLP_FP8_CONTRACT_SHA256="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_mlp_out_fp8_contract_sha256; print(minimax_h3_mlp_out_fp8_contract_sha256())' \
    | tail -n 1)" || {
      echo "Failed to hash the canonical MiniMax H3 MLP-OUT-FP8 contract" >&2
      exit 2
    }
  MLP_FP8_DIT_QUANT_MODE="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import MINIMAX_H3_MLP_OUT_FP8_DIT_QUANT_MODE; print(MINIMAX_H3_MLP_OUT_FP8_DIT_QUANT_MODE)' \
    | tail -n 1)" || {
      echo "Failed to resolve the canonical MiniMax H3 MLP-OUT-FP8 mode" >&2
      exit 2
    }
  [[ "$MLP_FP8_CONFIG_SHA256" =~ ^[0-9a-f]{64}$ && \
        "$MLP_FP8_CONTRACT_SHA256" =~ ^[0-9a-f]{64}$ ]] || {
      echo "Canonical MiniMax H3 MLP-OUT-FP8 digests are malformed" >&2
      exit 2
    }
  export VLLM_OMNI_MINIMAX_H3_FP8_SCOPE=mlp-out
  export VLLM_OMNI_MINIMAX_H3_FP8_CONFIG_SHA256="$MLP_FP8_CONFIG_SHA256"
  export VLLM_OMNI_MINIMAX_H3_FP8_CONTRACT_SHA256="$MLP_FP8_CONTRACT_SHA256"
elif [[ "$FP8_SCOPE" == mlp-out-qkv ]]; then
  MLP_FP8_CONFIG_JSON="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_mlp_out_qkv_fp8_quantization_config_json; print(minimax_h3_mlp_out_qkv_fp8_quantization_config_json())' \
    | tail -n 1)" || {
      echo "Failed to resolve the canonical MiniMax H3 MLP-OUT-QKV-FP8 config" >&2
      exit 2
    }
  MLP_FP8_CONFIG_SHA256="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_mlp_out_qkv_fp8_config_sha256; print(minimax_h3_mlp_out_qkv_fp8_config_sha256())' \
    | tail -n 1)" || {
      echo "Failed to hash the canonical MiniMax H3 MLP-OUT-QKV-FP8 config" >&2
      exit 2
    }
  MLP_FP8_CONTRACT_JSON="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_mlp_out_qkv_fp8_contract_json; print(minimax_h3_mlp_out_qkv_fp8_contract_json())' \
    | tail -n 1)" || {
      echo "Failed to resolve the canonical MiniMax H3 MLP-OUT-QKV-FP8 contract" >&2
      exit 2
    }
  MLP_FP8_CONTRACT_SHA256="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_mlp_out_qkv_fp8_contract_sha256; print(minimax_h3_mlp_out_qkv_fp8_contract_sha256())' \
    | tail -n 1)" || {
      echo "Failed to hash the canonical MiniMax H3 MLP-OUT-QKV-FP8 contract" >&2
      exit 2
    }
  MLP_FP8_DIT_QUANT_MODE="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import MINIMAX_H3_MLP_OUT_QKV_FP8_DIT_QUANT_MODE; print(MINIMAX_H3_MLP_OUT_QKV_FP8_DIT_QUANT_MODE)' \
    | tail -n 1)" || {
      echo "Failed to resolve the canonical MiniMax H3 MLP-OUT-QKV-FP8 mode" >&2
      exit 2
    }
  [[ "$MLP_FP8_CONFIG_SHA256" =~ ^[0-9a-f]{64}$ && \
        "$MLP_FP8_CONTRACT_SHA256" =~ ^[0-9a-f]{64}$ ]] || {
      echo "Canonical MiniMax H3 MLP-OUT-QKV-FP8 digests are malformed" >&2
      exit 2
    }
  export VLLM_OMNI_MINIMAX_H3_FP8_SCOPE=mlp-out-qkv
  export VLLM_OMNI_MINIMAX_H3_FP8_CONFIG_SHA256="$MLP_FP8_CONFIG_SHA256"
  export VLLM_OMNI_MINIMAX_H3_FP8_CONTRACT_SHA256="$MLP_FP8_CONTRACT_SHA256"
elif [[ "$FP8_SCOPE" == all-main ]]; then
  MLP_FP8_CONFIG_JSON="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_all_main_fp8_quantization_config_json; print(minimax_h3_all_main_fp8_quantization_config_json())' \
    | tail -n 1)" || {
      echo "Failed to resolve the canonical MiniMax H3 ALL-MAIN-FP8 config" >&2
      exit 2
    }
  MLP_FP8_CONFIG_SHA256="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_all_main_fp8_config_sha256; print(minimax_h3_all_main_fp8_config_sha256())' \
    | tail -n 1)" || {
      echo "Failed to hash the canonical MiniMax H3 ALL-MAIN-FP8 config" >&2
      exit 2
    }
  MLP_FP8_CONTRACT_JSON="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_all_main_fp8_contract_json; print(minimax_h3_all_main_fp8_contract_json())' \
    | tail -n 1)" || {
      echo "Failed to resolve the canonical MiniMax H3 ALL-MAIN-FP8 contract" >&2
      exit 2
    }
  MLP_FP8_CONTRACT_SHA256="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import minimax_h3_all_main_fp8_contract_sha256; print(minimax_h3_all_main_fp8_contract_sha256())' \
    | tail -n 1)" || {
      echo "Failed to hash the canonical MiniMax H3 ALL-MAIN-FP8 contract" >&2
      exit 2
    }
  MLP_FP8_DIT_QUANT_MODE="$($PYTHON -c \
    'from vllm_omni.diffusion.models.minimax_h3.fp8_contract import MINIMAX_H3_ALL_MAIN_FP8_DIT_QUANT_MODE; print(MINIMAX_H3_ALL_MAIN_FP8_DIT_QUANT_MODE)' \
    | tail -n 1)" || {
      echo "Failed to resolve the canonical MiniMax H3 ALL-MAIN-FP8 mode" >&2
      exit 2
    }
  [[ "$MLP_FP8_CONFIG_SHA256" =~ ^[0-9a-f]{64}$ && \
        "$MLP_FP8_CONTRACT_SHA256" =~ ^[0-9a-f]{64}$ ]] || {
      echo "Canonical MiniMax H3 ALL-MAIN-FP8 digests are malformed" >&2
      exit 2
    }
  export VLLM_OMNI_MINIMAX_H3_FP8_SCOPE=all-main
  export VLLM_OMNI_MINIMAX_H3_FP8_CONFIG_SHA256="$MLP_FP8_CONFIG_SHA256"
  export VLLM_OMNI_MINIMAX_H3_FP8_CONTRACT_SHA256="$MLP_FP8_CONTRACT_SHA256"
else
  unset VLLM_OMNI_MINIMAX_H3_FP8_CONFIG_SHA256
  unset VLLM_OMNI_MINIMAX_H3_FP8_CONTRACT_SHA256
fi

if [[ "$QKV_TRANSPORT_OBSERVER_MODE" != disabled ]]; then
  [[ "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 && "$FASTH3_VSA_MODE" == 1 && \
        "$FASTH3_VSA_PROVIDER" == flashinfer && "$FASTH3_VSA_TOPK" == 162 ]] || {
    echo "QKV calibration/validation requires the cumulative FlashInfer top-k 162 FastH3 VSA lane" >&2
    exit 2
  }
  [[ "$QKV_E4M3_TRANSPORT" == 0 ]] || {
    echo "QKV calibration/validation must observe BF16 with live E4M3 transport disabled" >&2
    exit 2
  }
  [[ "$WIDTH" == 1280 && "$HEIGHT" == 720 && "$STEPS" == 4 ]] || {
    echo "QKV calibration/validation is pinned to requested 1280x720 and four FastH3 forwards" >&2
    exit 2
  }
  [[ "$WARMUPS" == 0 && "$REPEATS" == 1 && "$DENOISER_EVALUATIONS" == 4 && \
        "$QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT" == 4 ]] || {
    echo "QKV calibration/validation requires one request, no warmup, and exactly four observations" >&2
    exit 2
  }
  [[ "$FLASHINFER_ULYSSES_ROUTE" == rdma && "$QCHUNK_PIPELINE" == 0 ]] || {
    echo "QKV calibration/validation requires all-RDMA FlashInfer Ulysses with qchunk disabled" >&2
    exit 2
  }
  [[ "$FLASHINFER_O_PRODUCER_DIRECT" == 1 && "$VSA_FUSED_TILE_PACK" == 1 && \
        "$VSA_FUSED_UNTILE" == 1 && "$VSA_FUSED_GATE_UNTILE" == 1 && \
        "$VSA_DIRECT_Q2K" == 1 && "$VSA_DEFERRED_GATE_SP" == 0 && \
        "$VSA_O_BUNDLE" == 0 ]] || {
    echo "QKV calibration/validation requires the canonical BF16 Q/K/O-direct VSA layout" >&2
    exit 2
  }
  if [[ "$MLP_FP8_CONTRACT" == 1 ]]; then
    [[ "$FP8_SCOPE" == mlp ]] || {
      echo "MLP-FP8 QKV calibration/validation requires the exact mlp scope" >&2
      exit 2
    }
  elif [[ "$MLP_OUT_FP8_CONTRACT" == 1 ]]; then
    [[ "$FP8_SCOPE" == mlp-out ]] || {
      echo "MLP-OUT-FP8 QKV calibration/validation requires the exact mlp-out scope" >&2
      exit 2
    }
  elif [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 ]]; then
    [[ "$FP8_SCOPE" == mlp-out-qkv ]] || {
      echo "MLP-OUT-QKV-FP8 QKV calibration/validation requires the exact mlp-out-qkv scope" >&2
      exit 2
    }
  elif [[ "$ALL_MAIN_FP8_CONTRACT" == 1 ]]; then
    [[ "$FP8_SCOPE" == all-main ]] || {
      echo "ALL-MAIN-FP8 QKV calibration/validation requires the exact all-main scope" >&2
      exit 2
    }
  else
    [[ "$FP8_SCOPE" == none ]] || {
      echo "BF16-DiT QKV calibration/validation requires VLLM_OMNI_MINIMAX_H3_FP8_SCOPE=none" >&2
      exit 2
    }
  fi
  observed_prompt_sha256="$(printf '%s' "$PROMPT" | sha256sum)"
  observed_prompt_sha256="${observed_prompt_sha256%% *}"
  [[ "$observed_prompt_sha256" == "$QKV_E4M3_PROMPT_SHA256" ]] || {
    echo "Benchmark prompt SHA256 $observed_prompt_sha256 != calibration contract $QKV_E4M3_PROMPT_SHA256" >&2
    exit 2
  }
fi

if [[ "$QKV_E4M3_TRANSPORT" == 1 ]]; then
  [[ "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 ]] || {
    echo "E4M3 QKV transport requires the cumulative FastH3 VSA RDMA lane" >&2
    exit 2
  }
  [[ "$WIDTH" == 1280 && "$HEIGHT" == 720 && "$STEPS" == 4 ]] || {
    echo "The v1 E4M3 QKV scale ABI is pinned to requested 1280x720 and four FastH3 forwards" >&2
    exit 2
  }
  [[ "$FLASHINFER_ULYSSES_ROUTE" == rdma && "$QCHUNK_PIPELINE" == 0 ]] || {
    echo "E4M3 QKV transport requires all-RDMA FlashInfer Ulysses with qchunk disabled" >&2
    exit 2
  }
  [[ "$FLASHINFER_O_PRODUCER_DIRECT" == 1 && "$VSA_FUSED_TILE_PACK" == 1 && \
        "$VSA_FUSED_UNTILE" == 1 && "$VSA_DIRECT_Q2K" == 1 ]] || {
    echo "E4M3 QKV transport requires Q/K/O-direct cumulative VSA layout optimizations" >&2
    exit 2
  }
  if [[ "$MLP_FP8_CONTRACT" == 1 ]]; then
    [[ "$FP8_SCOPE" == mlp ]] || {
      echo "The MLP-FP8 + E4M3 QKV action requires the exact mlp scope" >&2
      exit 2
    }
  elif [[ "$MLP_OUT_FP8_CONTRACT" == 1 ]]; then
    [[ "$FP8_SCOPE" == mlp-out ]] || {
      echo "The MLP-OUT-FP8 + E4M3 QKV action requires the exact mlp-out scope" >&2
      exit 2
    }
  elif [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 ]]; then
    [[ "$FP8_SCOPE" == mlp-out-qkv ]] || {
      echo "The MLP-OUT-QKV-FP8 + E4M3 QKV action requires the exact mlp-out-qkv scope" >&2
      exit 2
    }
  elif [[ "$ALL_MAIN_FP8_CONTRACT" == 1 ]]; then
    [[ "$FP8_SCOPE" == all-main ]] || {
      echo "The ALL-MAIN-FP8 + E4M3 QKV action requires the exact all-main scope" >&2
      exit 2
    }
  else
    [[ "$FP8_SCOPE" == none ]] || {
      echo "The BF16-DiT E4M3 transport A/B requires VLLM_OMNI_MINIMAX_H3_FP8_SCOPE=none" >&2
      exit 2
    }
  fi
  [[ -f "$QKV_E4M3_SCALE_SIDECAR" ]] || {
    echo "Pinned E4M3 QKV scale sidecar is missing: $QKV_E4M3_SCALE_SIDECAR" >&2
    exit 2
  }
  [[ "$QKV_E4M3_EXPECTED_WHOLE_SHA256" =~ ^[0-9a-f]{64}$ ]] || {
    echo "VLLM_OMNI_MINIMAX_H3_QKV_E4M3_EXPECTED_WHOLE_SHA256 must pin the calibrated sidecar" >&2
    exit 2
  }
  [[ "$QKV_E4M3_EXPECTED_PAYLOAD_SHA256" =~ ^[0-9a-f]{64}$ ]] || {
    echo "VLLM_OMNI_MINIMAX_H3_QKV_E4M3_EXPECTED_PAYLOAD_SHA256 must pin the calibrated payload" >&2
    exit 2
  }
  observed_qkv_sidecar_sha256="$(sha256sum "$QKV_E4M3_SCALE_SIDECAR")"
  observed_qkv_sidecar_sha256="${observed_qkv_sidecar_sha256%% *}"
  [[ "$observed_qkv_sidecar_sha256" == "$QKV_E4M3_EXPECTED_WHOLE_SHA256" ]] || {
    echo "E4M3 QKV sidecar SHA256 $observed_qkv_sidecar_sha256 != $QKV_E4M3_EXPECTED_WHOLE_SHA256" >&2
    exit 2
  }
  if [[ "$ALL_MAIN_FP8_CONTRACT" == 1 ]]; then
    [[ "$(realpath "$QKV_E4M3_SCALE_SIDECAR")" != \
          "$(realpath -m "$MLP_OUT_QKV_QKV_E4M3_SCALE_SIDECAR")" ]] || {
      echo "ALL-MAIN-FP8 refuses the old mlp-out-qkv QKV sidecar path" >&2
      exit 2
    }
    if [[ -f "$MLP_OUT_QKV_QKV_E4M3_SCALE_SIDECAR" ]]; then
      old_mlp_out_qkv_sidecar_sha256="$(sha256sum "$MLP_OUT_QKV_QKV_E4M3_SCALE_SIDECAR")"
      old_mlp_out_qkv_sidecar_sha256="${old_mlp_out_qkv_sidecar_sha256%% *}"
      [[ "$observed_qkv_sidecar_sha256" != "$old_mlp_out_qkv_sidecar_sha256" ]] || {
        echo "ALL-MAIN-FP8 refuses the old mlp-out-qkv QKV sidecar hash" >&2
        exit 2
      }
    fi
  fi
  observed_prompt_sha256="$(printf '%s' "$PROMPT" | sha256sum)"
  observed_prompt_sha256="${observed_prompt_sha256%% *}"
  [[ "$observed_prompt_sha256" == "$QKV_E4M3_PROMPT_SHA256" ]] || {
    echo "Benchmark prompt SHA256 $observed_prompt_sha256 != calibrated $QKV_E4M3_PROMPT_SHA256" >&2
    exit 2
  }
fi

SERVER_PID=""
SAMPLER_PID=""
DMON_PID=""
FOREIGN_GPU_MONITOR_PID=""
ACTIVE_CASE=""
CURRENT_CASE=""
SUMMARY_ROW_WRITTEN=0
SUMMARY_TSV="$RUN_ROOT/summary.tsv"
FASTH3_ADALN_BINDING_JSON=""
QKV_E4M3_ARTIFACT_BINDING_JSON=""
QKV_E4M3_BINDING_JSON=""
QKV_E4M3_AUDIT_JSON=""

mkdir -p "$RUN_ROOT"
if [[ "$QKV_TRANSPORT_OBSERVER_MODE" != disabled ]]; then
  if [[ -e "$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR" ]]; then
    [[ -d "$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR" ]] || {
      echo "QKV observer snapshot path is not a directory: $QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR" >&2
      exit 2
    }
    [[ -z "$(find "$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR" -mindepth 1 -maxdepth 1 -print -quit)" ]] || {
      echo "QKV observer snapshot directory must be empty; refusing stale artifacts: $QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR" >&2
      exit 2
    }
  else
    mkdir -p "$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR"
  fi
fi
RUNNER_SCRIPT_SNAPSHOT="$RUN_ROOT/executed-benchmark-script.sh"
GPU_HEALTH_GATE="$RUN_ROOT/executed-benchmark-gpu-health-gate.py"
cp -- "${BASH_SOURCE[0]}" "$RUNNER_SCRIPT_SNAPSHOT"
cp -- "$GPU_HEALTH_GATE_SOURCE" "$GPU_HEALTH_GATE"
sha256sum "$RUNNER_SCRIPT_SNAPSHOT" >"$RUN_ROOT/executed-benchmark-script.sha256"
sha256sum "$GPU_HEALTH_GATE" >"$RUN_ROOT/executed-benchmark-gpu-health-gate.sha256"
exec > >(tee -a "$RUN_ROOT/runner.log") 2>&1

die() {
  echo "ERROR: $*" >&2
  exit 1
}

is_nonnegative_number() {
  [[ "$1" =~ ^[0-9]+([.][0-9]+)?$ ]]
}

is_positive_number() {
  is_nonnegative_number "$1" && awk -v value="$1" 'BEGIN {exit !(value > 0)}'
}

validate_gpu_order() {
  local gpu_id
  local -a gpu_ids
  local -A seen_gpu_ids=()
  [[ "$GPU_ORDER" =~ ^(0|[1-9][0-9]*)(,(0|[1-9][0-9]*)){7}$ ]] || \
    die "VLLM_OMNI_CUDA_VISIBLE_DEVICES must contain exactly eight canonical decimal GPU indices"
  IFS=',' read -r -a gpu_ids <<<"$GPU_ORDER"
  for gpu_id in "${gpu_ids[@]}"; do
    [[ -z "${seen_gpu_ids[$gpu_id]+present}" ]] || \
      die "VLLM_OMNI_CUDA_VISIBLE_DEVICES entries must be unique: $GPU_ORDER"
    seen_gpu_ids[$gpu_id]=1
  done
}

emit_summary_failure() {
  local case_name=$1
  local failure_status=${2:-failed-runtime}
  [[ -f "$SUMMARY_TSV" && "$SUMMARY_ROW_WRITTEN" == 0 ]] || return 0
  {
    printf '%s\t%s' "$case_name" "$failure_status"
    for _ in {1..23}; do
      printf '\t-'
    done
    printf '\n'
  } >>"$SUMMARY_TSV"
  SUMMARY_ROW_WRITTEN=1
}

stop_case() {
  if [[ -n "$FOREIGN_GPU_MONITOR_PID" ]] && \
    kill -0 "$FOREIGN_GPU_MONITOR_PID" 2>/dev/null; then
    kill -TERM "$FOREIGN_GPU_MONITOR_PID" 2>/dev/null || true
    wait "$FOREIGN_GPU_MONITOR_PID" 2>/dev/null || true
  fi
  FOREIGN_GPU_MONITOR_PID=""
  if [[ -n "$SAMPLER_PID" ]] && kill -0 "$SAMPLER_PID" 2>/dev/null; then
    kill -TERM "$SAMPLER_PID" 2>/dev/null || true
    wait "$SAMPLER_PID" 2>/dev/null || true
  fi
  SAMPLER_PID=""
  if [[ -n "$DMON_PID" ]] && kill -0 "$DMON_PID" 2>/dev/null; then
    kill -TERM "$DMON_PID" 2>/dev/null || true
    wait "$DMON_PID" 2>/dev/null || true
  fi
  DMON_PID=""

  if [[ -n "$SERVER_PID" ]] && kill -0 "$SERVER_PID" 2>/dev/null; then
    echo "Stopping $ACTIVE_CASE server process group $SERVER_PID"
    kill -TERM -- "-$SERVER_PID" 2>/dev/null || kill -TERM "$SERVER_PID" 2>/dev/null || true
    for _ in {1..30}; do
      kill -0 "$SERVER_PID" 2>/dev/null || break
      sleep 1
    done
    if kill -0 "$SERVER_PID" 2>/dev/null; then
      kill -KILL -- "-$SERVER_PID" 2>/dev/null || kill -KILL "$SERVER_PID" 2>/dev/null || true
    fi
    wait "$SERVER_PID" 2>/dev/null || true
  fi
  SERVER_PID=""
  ACTIVE_CASE=""
}

cleanup() {
  local status=$?
  trap - EXIT INT TERM
  if (( status != 0 )) && [[ -n "$CURRENT_CASE" ]]; then
    emit_summary_failure "$CURRENT_CASE"
  fi
  stop_case
  exit "$status"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

for command_name in nvidia-smi curl setsid numactl; do
  command -v "$command_name" >/dev/null 2>&1 || die "Required command is missing: $command_name"
done
validate_gpu_order
[[ -x "$PYTHON" ]] || die "Python is missing: $PYTHON"
[[ -x "$VLLM" ]] || die "vLLM is missing: $VLLM"
[[ -x "$FFPROBE" ]] || die "ffprobe is missing: $FFPROBE"
"$PYTHON" -c 'import av' >/dev/null 2>&1 || die "The vLLM Python environment must provide PyAV"
[[ -f "$MODEL/model_index.json" ]] || die "Original MiniMax-H3 FL2VA model is missing: $MODEL"
[[ -f "$MODEL/transformer/model.safetensors.index.json" ]] || die "Native H3 transformer index is missing"
[[ -f "$ADALN_BUILDER" ]] || die "AdaLN builder is missing: $ADALN_BUILDER"
[[ -f "$GPU_HEALTH_GATE" ]] || die "GPU health gate snapshot is missing: $GPU_HEALTH_GATE"
if [[ "$GPU_BALANCE_HEALTH_GATE" == 1 ]]; then
  [[ -f "$GPU_BALANCE_SCRIPT" ]] || die "GPU balance benchmark is missing: $GPU_BALANCE_SCRIPT"
fi
[[ "$PORT" =~ ^[0-9]+$ ]] || die "VLLM_OMNI_PORT must be an integer"
[[ "$EXCLUSIVE_GPU_TIMEOUT" =~ ^[1-9][0-9]*$ ]] || \
  die "VLLM_OMNI_EXCLUSIVE_GPU_TIMEOUT must be a positive integer"
[[ "$GPU_IDLE_HEALTH_GATE" == 0 || "$GPU_IDLE_HEALTH_GATE" == 1 ]] || \
  die "VLLM_OMNI_GPU_IDLE_HEALTH_GATE must be 0 or 1"
[[ "$GPU_BALANCE_HEALTH_GATE" == 0 || "$GPU_BALANCE_HEALTH_GATE" == 1 ]] || \
  die "VLLM_OMNI_GPU_BALANCE_HEALTH_GATE must be 0 or 1"
[[ "$GPU_IDLE_HEALTH_SAMPLES" =~ ^[1-9][0-9]*$ ]] || \
  die "VLLM_OMNI_GPU_IDLE_HEALTH_SAMPLES must be a positive integer"
for value_name in GPU_IDLE_HEALTH_GRACE_SECONDS GPU_IDLE_HEALTH_INTERVAL_SECONDS \
  GPU_IDLE_MAX_UTILIZATION_PERCENT GPU_IDLE_MAX_MEMORY_MIB; do
  is_nonnegative_number "${!value_name}" || die "$value_name must be a nonnegative number"
done
is_positive_number "$GPU_IDLE_MAX_TEMPERATURE_C" || \
  die "VLLM_OMNI_GPU_IDLE_MAX_TEMPERATURE_C must be positive"
for value_name in GPU_BALANCE_WARMUP GPU_BALANCE_ROUNDS GPU_BALANCE_ITERATIONS \
  GPU_BALANCE_MIN_TELEMETRY_SAMPLES; do
  [[ "${!value_name}" =~ ^[1-9][0-9]*$ ]] || die "$value_name must be a positive integer"
done
for value_name in GPU_BALANCE_WORKER_TIMEOUT GPU_BALANCE_SMI_INTERVAL \
  GPU_BALANCE_MAX_TIME_RATIO GPU_BALANCE_MAX_MEDIAN_OVER_FLEET \
  GPU_BALANCE_MIN_CLOCK_RATIO GPU_BALANCE_MIN_POWER_RATIO; do
  is_positive_number "${!value_name}" || die "$value_name must be a positive number"
done
is_nonnegative_number "$GPU_BALANCE_MIN_LOADED_UTILIZATION_PERCENT" || \
  die "VLLM_OMNI_GPU_BALANCE_MIN_LOADED_UTILIZATION_PERCENT must be nonnegative"
[[ "$WIDTH" =~ ^[1-9][0-9]*$ && "$HEIGHT" =~ ^[1-9][0-9]*$ ]] || die "Width and height must be positive integers"
[[ "$STEPS" =~ ^[0-9]+$ ]] && (( STEPS >= 2 )) || die "VLLM_OMNI_STEPS must be at least 2"
if [[ "$FASTH3_MODE" == 1 ]]; then
  [[ "$STEPS" == 4 ]] || die "FastH3 requires num_inference_steps=4 (four DiT forwards)"
  if [[ "$FASTH3_SMOKE_MODE" == 1 ]]; then
    [[ "$QCHUNK_PIPELINE" == 0 ]] || die "The Dense FastH3 smoke requires qchunk off"
  elif [[ "$FASTH3_VSA_MODE" == 1 ]]; then
    [[ "$QCHUNK_PIPELINE" == 0 ]] || die "The formal FastH3 VSA A/B requires qchunk off"
  else
    [[ "$QCHUNK_PIPELINE" == 2 ]] || die "The formal Dense FastH3 action requires qchunk pipeline mode 2"
  fi
else
  DENOISER_EVALUATIONS="$((STEPS - 1))"
fi
if [[ "$FLASHINFER_ULYSSES_ROUTE" == hybrid && "$QCHUNK_PIPELINE" != 0 ]]; then
  die "FlashInfer hybrid routing is currently qualified only with qchunk disabled"
fi
[[ "$WARMUPS" =~ ^[0-9]+$ && "$REPEATS" =~ ^[1-9][0-9]*$ ]] || die "Invalid warmup/repeat count"
[[ "$DLO_TUNED_USE_ALLGATHER" == 0 || "$DLO_TUNED_USE_ALLGATHER" == 1 ]] || \
  die "VLLM_OMNI_DLO_USE_ALLGATHER must be 0 or 1"
[[ "$ALLOW_SP8_LSA" == 0 || "$ALLOW_SP8_LSA" == 1 ]] || \
  die "VLLM_OMNI_ALLOW_SP8_LSA must be 0 or 1"
[[ "$DLO_TUNED_RESIDENT_LAYERS" =~ ^[0-9]+$ ]] && (( DLO_TUNED_RESIDENT_LAYERS <= 50 )) || \
  die "VLLM_OMNI_DLO_RESIDENT_LAYERS must be an integer in [0, 50]"
[[ "$FLASHINFER_MAX_BYTES" =~ ^[1-9][0-9]*$ ]] || \
  die "VLLM_OMNI_FLASHINFER_ULYSSES_MAX_BYTES must be a positive integer"
if [[ "$VSA_O_BUNDLE" == 1 ]]; then
  (( FLASHINFER_MAX_BYTES >= FLASHINFER_O_BUNDLE_REQUIRED_BYTES )) || die \
    "VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE=1 requires FlashInfer capacity >= ${FLASHINFER_O_BUNDLE_REQUIRED_BYTES} bytes"
fi
[[ "$FLASHINFER_RELEASE_AFTER_DENOISE" == 0 || "$FLASHINFER_RELEASE_AFTER_DENOISE" == 1 ]] || \
  die "FlashInfer post-denoise release must be 0 or 1"
if [[ "$FASTH3_VSA_MODE" == 1 ]]; then
  [[ "$FASTH3_VSA_TOPK" == 162 ]] || die "The formal VSA A/B is pinned to top-k 162"
  [[ -f "$FASTVIDEO_KERNEL_PYTHON/fastvideo_kernel/__init__.py" ]] || die \
    "FastVideo kernel Python sources are missing: $FASTVIDEO_KERNEL_PYTHON"
  if [[ "$FASTH3_VSA_PROVIDER" == flashinfer ]]; then
    [[ -f "$FLASHINFER_VSA_ROOT/flashinfer/cute_dsl/sparse/bsa_attn_sm120.py" ]] || die \
      "FlashInfer PR #4944 SM120 VSA kernel is missing: $FLASHINFER_VSA_ROOT"
    observed_fi_vsa_commit="$(git -C "$FLASHINFER_VSA_ROOT" rev-parse HEAD)"
    [[ "$observed_fi_vsa_commit" == "$FLASHINFER_VSA_EXPECTED_COMMIT" ]] || die \
      "FlashInfer combined checkout is $observed_fi_vsa_commit, expected $FLASHINFER_VSA_EXPECTED_COMMIT"
  fi
fi
if [[ "$TAEH3_OUTPUT" == 1 ]]; then
  [[ "$WIDTH" == 1280 && "$HEIGHT" == 720 ]] || die \
    "The validated TAEH3 action is pinned to requested 1280x720 (effective 1280x704)"
  [[ -f "$TAEH3_CHECKPOINT" ]] || die \
    "Pinned TAEH3 checkpoint is missing: $TAEH3_CHECKPOINT"
  taeh3_observed_size="$(stat -c %s "$TAEH3_CHECKPOINT")"
  [[ "$taeh3_observed_size" == "$TAEH3_EXPECTED_SIZE" ]] || die \
    "TAEH3 checkpoint size $taeh3_observed_size != $TAEH3_EXPECTED_SIZE"
  taeh3_observed_sha256="$(sha256sum "$TAEH3_CHECKPOINT")"
  taeh3_observed_sha256="${taeh3_observed_sha256%% *}"
  [[ "$taeh3_observed_sha256" == "$TAEH3_EXPECTED_SHA256" ]] || die \
    "TAEH3 checkpoint SHA256 $taeh3_observed_sha256 != $TAEH3_EXPECTED_SHA256"
  [[ -f "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/taeh3.py" ]] || die \
    "MiniMax H3 TAEH3 bridge is missing from $VLLM_SOURCE"
  "$PYTHON" -c \
    'from vllm_omni.diffusion.models.minimax_h3.taeh3 import taeh3_decoded_pixel_shape; assert taeh3_decoded_pixel_shape((1,24,107,44,80)) == (1,3,362,704,1280)' \
    || die "TAEH3 107-latent-frame production geometry contract failed"
fi

IFS=',' read -r -a GPU_IDS <<<"$GPU_ORDER"
[[ "${#GPU_IDS[@]}" -eq 8 ]] || die "GPU order must contain exactly eight unique GPU IDs"
declare -A SEEN_GPU=()
for gpu_id in "${GPU_IDS[@]}"; do
  [[ "$gpu_id" =~ ^[0-9]+$ ]] || die "Invalid GPU ID: $gpu_id"
  [[ -z "${SEEN_GPU[$gpu_id]:-}" ]] || die "GPU $gpu_id occurs more than once"
  SEEN_GPU[$gpu_id]=1
done

export PYTHONPATH="$VLLM_SOURCE${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONNOUSERSITE=1
IMPORTED_SOURCE="$($PYTHON -c 'import pathlib, vllm_omni; print(pathlib.Path(vllm_omni.__file__).resolve().parents[1])' | tail -n 1)"
[[ "$IMPORTED_SOURCE" == "$(realpath "$VLLM_SOURCE")" ]] || die \
  "vllm_omni imports from $IMPORTED_SOURCE, expected $VLLM_SOURCE"
if [[ "$QKV_TRANSPORT_OBSERVER_MODE" == validation ]]; then
  qkv_validation_prevalidation="$(
    QKV_VALIDATION_SCALES_PATH="$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_PATH" \
      "$PYTHON" - <<'PY'
import json
import os

from vllm_omni.diffusion.models.minimax_h3.qkv_transport_calibration import (
    load_qkv_transport_validation_scales,
    read_qkv_transport_validation_scale_provenance,
)

scales = load_qkv_transport_validation_scales(
    os.environ["QKV_VALIDATION_SCALES_PATH"],
    num_layers=50,
)
provenance = read_qkv_transport_validation_scale_provenance(
    os.environ["QKV_VALIDATION_SCALES_PATH"]
)
print(
    "__QKV_VALIDATION_SCALE_SUMMARY__"
    + json.dumps(
        {
            "dtype": str(scales.dtype),
            "max": float(scales.max().item()),
            "min": float(scales.min().item()),
            "shape": list(scales.shape),
        },
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    )
)
print(
    "__QKV_VALIDATION_PROVENANCE__"
    + json.dumps(
        provenance.to_dict(),
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    )
)
PY
  )" || die "QKV validation draft scale tensor failed strict prevalidation"
  QKV_TRANSPORT_OBSERVER_VALIDATION_SCALE_SUMMARY="$(
    sed -n 's/^__QKV_VALIDATION_SCALE_SUMMARY__//p' \
      <<<"$qkv_validation_prevalidation"
  )"
  QKV_TRANSPORT_OBSERVER_VALIDATION_PROVENANCE_JSON="$(
    sed -n 's/^__QKV_VALIDATION_PROVENANCE__//p' \
      <<<"$qkv_validation_prevalidation"
  )"
  [[ -n "$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALE_SUMMARY" && \
        -n "$QKV_TRANSPORT_OBSERVER_VALIDATION_PROVENANCE_JSON" ]] || die \
    "QKV validation draft prevalidation returned incomplete lineage"
fi

validate_fasth3_adapter() {
  [[ "$FASTH3_MODE" == 1 ]] || return 0
  [[ -f "$FASTH3_LORA" ]] || die "Pinned ${FASTH3_VARIANT} FastH3 adapter is missing: $FASTH3_LORA"
  local observed_size observed_sha
  observed_size="$(stat -c %s "$FASTH3_LORA")"
  [[ "$observed_size" == "$FASTH3_EXPECTED_SIZE" ]] || die \
    "${FASTH3_VARIANT} FastH3 adapter size $observed_size != $FASTH3_EXPECTED_SIZE"
  observed_sha="$(sha256sum "$FASTH3_LORA")"
  observed_sha="${observed_sha%% *}"
  [[ "$observed_sha" == "$FASTH3_EXPECTED_SHA256" ]] || die \
    "${FASTH3_VARIANT} FastH3 adapter SHA256 $observed_sha != $FASTH3_EXPECTED_SHA256"
  echo "FastH3 adapter contract: $FASTH3_VARIANT, size=$observed_size, sha256=$observed_sha"
}

validate_fasth3_adapter

if [[ "$QKV_E4M3_TRANSPORT" == 1 ]]; then
  qkv_sidecar_inspection="$(
    QKV_SCALE_PATH="$QKV_E4M3_SCALE_SIDECAR" \
    QKV_EXPECTED_PAYLOAD_SHA256="$QKV_E4M3_EXPECTED_PAYLOAD_SHA256" \
    "$PYTHON" - <<'PY'
import json
import os

import torch

from vllm_omni.diffusion.models.minimax_h3.qkv_transport_scales import (
    MiniMaxH3QKVTransportScales,
    read_minimax_h3_qkv_transport_scale_binding,
)

path = os.environ["QKV_SCALE_PATH"]
binding = read_minimax_h3_qkv_transport_scale_binding(path)
if binding.payload_sha256 != os.environ["QKV_EXPECTED_PAYLOAD_SHA256"]:
    raise SystemExit(
        f"QKV sidecar payload {binding.payload_sha256} != "
        f"{os.environ['QKV_EXPECTED_PAYLOAD_SHA256']}"
    )
loader = MiniMaxH3QKVTransportScales(path, runtime_binding=binding)
rows = loader.load()
audit = loader.audit_tensors
required = {
    "observed_absmax",
    "finite_count",
    "nonfinite_count",
    "numel",
    "observation_count",
    "saturation_count",
}
if set(audit) != required:
    raise SystemExit(
        f"formal QKV sidecar audit mismatch: missing={sorted(required - set(audit))}, "
        f"unexpected={sorted(set(audit) - required)}"
    )
if bool((audit["nonfinite_count"] != 0).any()):
    raise SystemExit("QKV sidecar audit contains non-finite values")
if bool((audit["saturation_count"] != 0).any()):
    raise SystemExit("QKV sidecar audit contains E4M3 saturation")
scales = torch.tensor(rows, dtype=torch.float32)
summary = {
    "audit_tensor_names": sorted(audit),
    "finite_count": int(audit["finite_count"].sum().item()),
    "nonfinite_count": int(audit["nonfinite_count"].sum().item()),
    "observation_count_min": int(audit["observation_count"].min().item()),
    "observation_count_max": int(audit["observation_count"].max().item()),
    "observed_absmax_max": float(audit["observed_absmax"].max().item()),
    "saturation_count": int(audit["saturation_count"].sum().item()),
    "scale_shape": list(scales.shape),
    "scale_order": ["q", "k", "v"],
    "scale_min": float(scales.min().item()),
    "scale_max": float(scales.max().item()),
}
print("__QKV_E4M3_BINDING__" + json.dumps(binding.to_dict(), separators=(",", ":"), sort_keys=True))
print("__QKV_E4M3_AUDIT__" + json.dumps(summary, separators=(",", ":"), sort_keys=True))
PY
  )"
  QKV_E4M3_BINDING_JSON="$(
    sed -n 's/^__QKV_E4M3_BINDING__//p' <<<"$qkv_sidecar_inspection"
  )"
  QKV_E4M3_AUDIT_JSON="$(
    sed -n 's/^__QKV_E4M3_AUDIT__//p' <<<"$qkv_sidecar_inspection"
  )"
  [[ -n "$QKV_E4M3_BINDING_JSON" && -n "$QKV_E4M3_AUDIT_JSON" ]] || die \
    "QKV E4M3 sidecar inspection returned incomplete evidence"
  QKV_E4M3_ARTIFACT_BINDING_JSON="$QKV_E4M3_BINDING_JSON"
fi

# Refuse a distilled release. A base_schedule is the local runtime's explicit
# marker for a distilled few-step checkpoint.
MODEL_INDEX="$MODEL/model_index.json" "$PYTHON" - <<'PY'
import json
import os

path = os.environ["MODEL_INDEX"]
release = json.load(open(path, encoding="utf-8")).get("_minimax_h3") or {}
if str(release.get("partition", "")).lower() != "fl2va":
    raise SystemExit(f"Not an FL2VA partition: {path}")
if release.get("base_schedule") is not None:
    raise SystemExit(f"Refusing distilled H3 checkpoint with base_schedule: {path}")
print("Base checkpoint contract: original FL2VA (no distilled base_schedule)")
PY

printf 'case\tstatus\tcold_start_s\twarmup_s\te2e_s\tencoder_s\tdit_s\tdecode_total_s\tvideo_vae_path_s\taudio_vae_s\tpipeline_forward_s\tengine_exec_s\tstage_gen_s\tasync_output_residual_wait_s\tpostprocess_s\tstage_unattributed_residual_s\tmp4_encode_s\tapi_http_residual_s\tdenoise_updates\tavg_profiled_step_ms\tmedia_s\trtf\tpeak_gpu_mib\toutput\tgithub_url\n' >"$SUMMARY_TSV"

{
  echo "utc_start=$STAMP"
  echo "action=$ACTION"
  echo "quality_moon_factorial_action=$QUALITY_MOON_FACTORIAL_ACTION"
  echo "quality_moon_prompt_sha256=$([[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 ]] && echo "$QUALITY_MOON_PROMPT_SHA256" || echo not_applicable)"
  echo "quality_moon_q_factor=$QUALITY_MOON_Q_FACTOR"
  echo "quality_moon_d_factor=$QUALITY_MOON_D_FACTOR"
  echo "quality_moon_one_shot=$QUALITY_MOON_FACTORIAL_ACTION"
  echo "quality_moon_o_bundle_kmax=$([[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 ]] && echo "$VSA_O_BUNDLE_KMAX" || echo not_applicable)"
  echo "source=$VLLM_SOURCE"
  echo "model=$MODEL"
  echo "run_contract=$RUN_CONTRACT"
  echo "physical_gpu_order=$GPU_ORDER"
  echo "gpu_idle_health_gate=$GPU_IDLE_HEALTH_GATE"
  echo "gpu_idle_health_samples=$GPU_IDLE_HEALTH_SAMPLES"
  echo "gpu_idle_health_grace_seconds=$GPU_IDLE_HEALTH_GRACE_SECONDS"
  echo "gpu_idle_health_interval_seconds=$GPU_IDLE_HEALTH_INTERVAL_SECONDS"
  echo "gpu_idle_max_utilization_percent=$GPU_IDLE_MAX_UTILIZATION_PERCENT"
  echo "gpu_idle_max_memory_mib=$GPU_IDLE_MAX_MEMORY_MIB"
  echo "gpu_idle_max_temperature_c=$GPU_IDLE_MAX_TEMPERATURE_C"
  echo "gpu_balance_health_gate=$GPU_BALANCE_HEALTH_GATE"
  echo "gpu_clock_policy=$GPU_CLOCK_POLICY"
  echo "diffusion_pipeline_profiler=$ENABLE_DIFFUSION_PIPELINE_PROFILER"
  echo "launcher_omp_num_threads=${OMP_NUM_THREADS-<unset>}"
  echo "launcher_vllm_omp_num_threads_set_by_vllm=${VLLM_OMP_NUM_THREADS_SET_BY_VLLM-<unset>}"
  echo "launcher_mkl_num_threads=${MKL_NUM_THREADS-<unset>}"
  echo "launcher_openblas_num_threads=${OPENBLAS_NUM_THREADS-<unset>}"
  echo "launcher_numexpr_num_threads=${NUMEXPR_NUM_THREADS-<unset>}"
  echo "gpu_balance_probe=independent_cudnn_sdpa_exact_h3_sp8_before_model_load"
  echo "gpu_balance_probe_warmup=$GPU_BALANCE_WARMUP"
  echo "gpu_balance_probe_rounds=$GPU_BALANCE_ROUNDS"
  echo "gpu_balance_probe_iterations=$GPU_BALANCE_ITERATIONS"
  echo "gpu_balance_max_time_ratio=$GPU_BALANCE_MAX_TIME_RATIO"
  echo "gpu_balance_max_median_over_fleet=$GPU_BALANCE_MAX_MEDIAN_OVER_FLEET"
  echo "gpu_balance_min_clock_ratio=$GPU_BALANCE_MIN_CLOCK_RATIO"
  echo "gpu_balance_min_power_ratio=$GPU_BALANCE_MIN_POWER_RATIO"
  echo "gpu_balance_min_loaded_utilization_percent=$GPU_BALANCE_MIN_LOADED_UTILIZATION_PERCENT"
  echo "gpu_balance_min_telemetry_samples=$GPU_BALANCE_MIN_TELEMETRY_SAMPLES"
  if [[ "$FASTH3_MODE" == 1 ]]; then
    echo "request=${WIDTH}x${HEIGHT},24fps,15s,FastH3_4_forwards_5_fixed_sigma_positions,shift_12_3,seed_1101"
    echo "fasth3_adapter=$FASTH3_LORA"
    echo "fasth3_adapter_size=$FASTH3_EXPECTED_SIZE"
    echo "fasth3_adapter_sha256=$FASTH3_EXPECTED_SHA256"
    echo "fasth3_base_schedule=${FASTH3_BASE_SCHEDULE[*]}"
  else
    echo "request=${WIDTH}x${HEIGHT},24fps,15s,${STEPS}_sigma_points,shift_12_3,seed_1101"
  fi
  echo "effective_canvas=$(( WIDTH / 32 * 32 ))x$(( HEIGHT / 32 * 32 ))"
  echo "denoiser_evaluations=$DENOISER_EVALUATIONS"
  if [[ "$FASTH3_VSA_MODE" == 1 ]]; then
    echo "attention=FASTVIDEO_VSA_H3_tile64"
    echo "fastH3_few_step_distillation=enabled_vsa_datafree"
    echo "vsa=enabled"
    echo "vsa_compute_provider=$FASTH3_VSA_PROVIDER"
    echo "vsa_topk=$FASTH3_VSA_TOPK"
    if [[ "$CUMULATIVE_FASTH3_VSA_RDMA" == 1 ]]; then
      echo "vsa_a2a_backend=flashinfer-pcie-${FLASHINFER_ULYSSES_ROUTE}"
      echo "vsa_qk_producer_direct=enabled"
    else
      echo "vsa_a2a_backend=nccl"
      echo "vsa_qk_producer_direct=disabled"
    fi
  else
    echo "attention=CUDNN_ATTN_dense"
    echo "fastH3_few_step_distillation=$([[ "$FASTH3_MODE" == 1 ]] && echo enabled_dense_datafree || echo disabled)"
    echo "vsa=disabled"
  fi
  echo "approximate_dit_cache=disabled"
  echo "vae_stream_temporal_cat=$VAE_STREAM_TEMPORAL_CAT"
  echo "h3_qchunk_pipeline=$QCHUNK_PIPELINE"
  echo "chunked_cpu_mp4_output=$CHUNKED_CPU_MP4_OUTPUT"
  echo "chunked_cpu_mp4_slots=$CHUNKED_CPU_MP4_SLOTS"
  echo "video_decode_backend=$TAEH3_VIDEO_DECODE_BACKEND"
  echo "vae_patch_parallel_size=$VAE_PATCH_PARALLEL_SIZE"
  echo "taeh3_output=$TAEH3_OUTPUT"
  echo "taeh3_audio_decode_overlap=$TAEH3_AUDIO_DECODE_OVERLAP"
  echo "taeh3_audio_decode_overlap_env=$TAEH3_AUDIO_OVERLAP_ENV"
  echo "taeh3_audio_decode_overlap_runtime_marker=$TAEH3_AUDIO_OVERLAP_MARKER"
  echo "taeh3_audio_decode_overlap_quality_contract=$([[ "$TAEH3_AUDIO_DECODE_OVERLAP" == 1 ]] && echo schedule_only_same_decoder_outputs || echo disabled)"
  echo "taeh3_cross_rank_audio_decode=$TAEH3_CROSS_RANK_AUDIO_DECODE"
  echo "taeh3_cross_rank_audio_decode_env=$TAEH3_CROSS_RANK_AUDIO_ENV"
  echo "taeh3_cross_rank_audio_decode_runtime_marker=$TAEH3_CROSS_RANK_AUDIO_MARKER"
  echo "taeh3_cross_rank_audio_decode_quality_contract=$([[ "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 1 ]] && echo rank_placement_only_exact_mp4_sha256_repeat3_validated_20260908 || echo disabled)"
  echo "taeh3_cross_rank_audio_encode=$TAEH3_CROSS_RANK_AUDIO_ENCODE"
  echo "taeh3_cross_rank_audio_encode_env=$TAEH3_CROSS_RANK_AUDIO_ENCODE_ENV"
  echo "taeh3_cross_rank_audio_encode_runtime_marker=$TAEH3_CROSS_RANK_AUDIO_ENCODE_MARKER"
  echo "taeh3_cross_rank_audio_encode_quality_contract=$([[ "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 1 ]] && echo independent_aac_packets_exact_cpu_mp4_ab_validated_full_e2e_sha_pending || echo disabled)"
  if [[ "$TAEH3_OUTPUT" == 1 ]]; then
    echo "taeh3_checkpoint=$TAEH3_CHECKPOINT"
    echo "taeh3_checkpoint_revision=$TAEH3_EXPECTED_REVISION"
    echo "taeh3_checkpoint_size=$TAEH3_EXPECTED_SIZE"
    echo "taeh3_checkpoint_sha256=$TAEH3_EXPECTED_SHA256"
    echo "taeh3_dtype=$TAEH3_DTYPE"
    echo "taeh3_chunk_size=$TAEH3_CHUNK_SIZE"
    echo "taeh3_output_rank_policy=rank0_only_full_video_vae_not_loaded"
    echo "taeh3_quality_contract=lossy_approximate_decoder_${TAEH3_DTYPE}"
    echo "taeh3_expected_output=22_chunks_362_frames_1280x704"
    echo "taeh3_marker_contract=loaded:1,active:8,decoded:1_per_request"
  fi
  echo "vsa_fused_tile_pack=$VSA_FUSED_TILE_PACK"
  echo "vsa_fused_untile=$VSA_FUSED_UNTILE"
  echo "vsa_fused_gate_untile=$VSA_FUSED_GATE_UNTILE"
  echo "vsa_fused_gate_untile_quality_contract=$([[ "$VSA_FUSED_GATE_UNTILE" == 1 ]] && echo production_shape_bit_exact_sm120_micro_full_sp8_pending || echo disabled)"
  echo "vsa_deferred_gate_sp=$VSA_DEFERRED_GATE_SP"
  echo "vsa_deferred_gate_sp_quality_contract=$([[ "$VSA_DEFERRED_GATE_SP" == 1 ]] && echo bf16_bit_exact_sp2_nccl_and_rdma_validated_full_sp8_e2e_pending || echo disabled)"
  echo "vsa_o_bundle=$VSA_O_BUNDLE"
  echo "vsa_o_bundle_quality_contract=$([[ "$VSA_O_BUNDLE" == 1 ]] && echo bf16_bit_exact_sm120_sp2_rdma_full_sp8_e2e_pending || echo disabled)"
  echo "vsa_gate_compute_overlap=$VSA_GATE_COMPUTE_OVERLAP"
  echo "vsa_gate_compute_overlap_quality_contract=$([[ "$VSA_GATE_COMPUTE_OVERLAP" == 1 ]] && echo unchanged_bf16_projection_schedule_only_full_sp8_hash_ab_pending || echo disabled)"
  echo "vsa_gate_compute_overlap_runtime_marker=MINIMAX_H3_VSA_GATE_COMPUTE_OVERLAP_ACTIVE_V1"
  echo "vsa_gate_compute_overlap_request_counters=not_exposed_nvtx_trace_required"
  echo "vsa_gate_compute_overlap_nvtx_side_prefix=minimax_h3.gate_compress.side:"
  echo "vsa_gate_compute_overlap_nvtx_wait_prefix=minimax_h3.gate_compress.wait:"
  echo "vsa_gate_compute_overlap_nvtx_expected_ranges_per_rank_4step_request=side:200,wait:200"
  echo "flashinfer_required_bytes=$FLASHINFER_REQUIRED_BYTES"
  echo "flashinfer_max_bytes=$FLASHINFER_MAX_BYTES"
  echo "ulysses_mode=$ULYSSES_MODE"
  echo "ulysses_ring_size=$ULYSSES_RING_SIZE"
  echo "h3_joint_attention_rows=$H3_JOINT_ATTENTION_ROWS"
  echo "vsa_direct_q2k=$VSA_DIRECT_Q2K"
  echo "flashinfer_o_producer_direct=$FLASHINFER_O_PRODUCER_DIRECT"
  echo "vae_temporal_pre_gather_prune=$VAE_TEMPORAL_PRE_GATHER_PRUNE"
  echo "vae_temporal_chunk_parallel=$VAE_TEMPORAL_CHUNK_PARALLEL"
  echo "vae_temporal_chunk_parallel_quality_contract=$([[ "$VAE_TEMPORAL_CHUNK_PARALLEL" == 1 ]] && echo eager_bit_exact_candidate_requires_gpu_multiseed_ab || echo disabled)"
  echo "vae_temporal_chunk_parallel_compile=disabled"
  echo "vae_temporal_chunk_parallel_perf_contract=same_sequential_tile_compute_collective_reduction_benchmark_required"
  echo "vae_decoder_tile_size=$VAE_DECODER_TILE_SIZE"
  echo "vae_decoder_tile_quality_contract=$([[ "$VAE_DECODER_TILE_SIZE" == 0 ]] && echo checkpoint_default || echo numerical_non_bit_exact_tile_context_and_blend_boundaries)"
  echo "vae_exact_ops_sm120=$VAE_EXACT_OPS_SM120"
  echo "vae_exact_ops_sm120_quality_contract=$([[ "$VAE_EXACT_OPS_SM120" == 1 ]] && echo bitwise_micro_validated_all_rank_dispatch_counters_full_sp8_raw_equivalence_pending || echo disabled)"
  echo "minimax_h3_fp8_scope=$FP8_SCOPE"
  echo "minimax_h3_mlp_fp8_formal_contract=$MLP_FP8_CONTRACT"
  echo "minimax_h3_mlp_out_fp8_formal_contract=$MLP_OUT_FP8_CONTRACT"
  if [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 ]]; then
    echo "minimax_h3_mlp_out_qkv_fp8_formal_contract=1"
  fi
  echo "minimax_h3_all_main_fp8_formal_contract=$ALL_MAIN_FP8_CONTRACT"
  echo "minimax_h3_selective_fp8_formal_contract=$SELECTIVE_FP8_CONTRACT"
  echo "minimax_h3_fp8_dit_quant_mode=$MLP_FP8_DIT_QUANT_MODE"
  echo "minimax_h3_fp8_config_sha256=${MLP_FP8_CONFIG_SHA256:-disabled}"
  echo "minimax_h3_fp8_contract_sha256=${MLP_FP8_CONTRACT_SHA256:-disabled}"
  echo "minimax_h3_fp8_quality_contract=$([[ "$FP8_SCOPE" == none ]] && echo bf16 || echo lossy_online_per_tensor_fp8)"
  echo "qkv_e4m3_transport=$QKV_E4M3_TRANSPORT"
  echo "qkv_single_phase=$QKV_SINGLE_PHASE"
  echo "qkv_single_phase_env=$QKV_SINGLE_PHASE_ENV"
  echo "qkv_single_phase_env_owner=runner"
  echo "qkv_single_phase_protocol=$QKV_SINGLE_PHASE_PROTOCOL"
  echo "qkv_single_phase_quality_contract=$([[ "$QKV_SINGLE_PHASE" == 1 ]] && echo "$QKV_SINGLE_PHASE_QUALITY_CONTRACT" || echo disabled)"
  echo "qkv_single_phase_runtime_marker=$QKV_SINGLE_PHASE_MARKER"
  echo "qkv_single_phase_marker_contract=$QKV_SINGLE_PHASE_MARKER_CONTRACT"
  echo "qkv_single_phase_expected_workers=8"
  echo "qkv_single_phase_expected_calls_per_worker_per_request=$QKV_SINGLE_PHASE_EXPECTED_CALLS_PER_WORKER_PER_REQUEST"
  echo "qkv_single_phase_observed_call_count=not_exposed_by_runtime_activation_marker_only"
  if [[ "$QKV_SINGLE_PHASE" == 1 ]]; then
    echo "qkv_single_phase_flashinfer_source=$FLASHINFER_VSA_ROOT"
    echo "qkv_single_phase_flashinfer_git_status=$RUN_ROOT/qkv-single-phase-flashinfer-git-status.txt"
    echo "qkv_single_phase_flashinfer_git_diff=$RUN_ROOT/qkv-single-phase-flashinfer-git-diff.patch"
    echo "qkv_single_phase_flashinfer_untracked_sha256=$RUN_ROOT/qkv-single-phase-flashinfer-untracked-sha256.txt"
  fi
  echo "qkv_compute_dtype=bfloat16"
  if [[ "$FP8_SCOPE" == mlp-out-qkv || "$FP8_SCOPE" == all-main ]]; then
    echo "qkv_projection_compute_dtype=float8_e4m3fn"
    echo "qkv_projection_output_dtype=bfloat16"
  fi
  echo "vsa_gate_compress_compute_dtype=$([[ "$FP8_SCOPE" == all-main ]] && echo float8_e4m3fn || echo bfloat16)"
  echo "vsa_gate_compress_output_dtype=bfloat16"
  echo "qkv_wire_dtype=$([[ "$QKV_E4M3_TRANSPORT" == 1 ]] && echo float8_e4m3fn || echo bfloat16)"
  echo "reverse_o_dtype=bfloat16"
  echo "qkv_transport_quality_contract=$([[ "$QKV_E4M3_TRANSPORT" == 1 ]] && echo lossy_static_per_block_e4m3_transport || echo bf16)"
  echo "qkv_transport_observer_mode=$QKV_TRANSPORT_OBSERVER_MODE"
  echo "qkv_transport_observer_snapshot_format=$([[ "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] && echo disabled || echo provenance_bound_v3)"
  echo "qkv_transport_observer_timing_rung=$([[ "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] && echo not_applicable || echo 0)"
  echo "qkv_transport_observer_enforce_eager=$([[ "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] && echo 0 || echo 1)"
  if [[ "$QKV_TRANSPORT_OBSERVER_MODE" != disabled ]]; then
    echo "qkv_transport_observer_formal_sidecar_finalized=0"
    echo "qkv_transport_observer_formal_go=0"
    echo "qkv_transport_observer_snapshot_dir=$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR"
    echo "qkv_transport_observer_expected_source_ranks=0,1,2,3,4,5,6,7"
    echo "qkv_transport_observer_expected_layers=50"
    echo "qkv_transport_observer_expected_components=q,k,v"
  fi
  if [[ "$QKV_TRANSPORT_OBSERVER_MODE" == validation ]]; then
    echo "qkv_transport_observer_validation_scales_path=$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_PATH"
    echo "qkv_transport_observer_validation_scales_sha256=$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_SHA256"
    echo "qkv_transport_observer_validation_scale_summary=$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALE_SUMMARY"
  fi
  if [[ "$QKV_E4M3_TRANSPORT" == 1 ]]; then
    echo "qkv_e4m3_scale_sidecar=$QKV_E4M3_SCALE_SIDECAR"
    echo "qkv_e4m3_scale_sidecar_sha256=$QKV_E4M3_EXPECTED_WHOLE_SHA256"
    echo "qkv_e4m3_payload_sha256=$QKV_E4M3_EXPECTED_PAYLOAD_SHA256"
    echo "qkv_e4m3_source_model_revision=$QKV_E4M3_SOURCE_MODEL_REVISION"
    echo "qkv_e4m3_kernel_provider=$QKV_E4M3_KERNEL_PROVIDER"
    echo "qkv_e4m3_kernel_abi=$QKV_E4M3_KERNEL_ABI"
    echo "qkv_e4m3_binding=$QKV_E4M3_BINDING_JSON"
    echo "qkv_e4m3_audit=$QKV_E4M3_AUDIT_JSON"
    echo "qkv_bf16_operand_bytes=$VSA_ELIDED_GATE_OPERAND_BYTES"
    echo "qkv_e4m3_operand_bytes=$QKV_E4M3_OPERAND_BYTES"
    echo "qkv_bf16_remote_wire_bytes=$VSA_ELIDED_GATE_REMOTE_WIRE_BYTES"
    echo "qkv_e4m3_remote_wire_bytes=$QKV_E4M3_REMOTE_WIRE_BYTES"
    echo "qkv_remote_wire_saving_bytes_per_rank_request=$QKV_REMOTE_WIRE_SAVING_BYTES_PER_RANK_REQUEST"
    echo "flashinfer_capacity_basis=largest_bf16_reverse_o$([[ "$VSA_O_BUNDLE" == 1 ]] && echo _bundle)"
  fi
  echo "flashinfer_release_after_denoise=$FLASHINFER_RELEASE_AFTER_DENOISE"
  echo "per_step_synchronized_profiler=$([[ "$ENABLE_DIFFUSION_PIPELINE_PROFILER" == 1 ]] && echo enabled || echo disabled)"
  echo "async_output_residual_wait=consumer_blocking_tail_until_background_D2H_SHM_unpack_output_ready"
  echo "stage_unattributed_residual=max(0,stage_gen_s-engine_exec_s-async_output_residual_wait_s-postprocess_s)"
  echo "api_http_residual=max(0,e2e_s-stage_gen_s-mp4_encode_s)"
  echo "timing_boundary=client_POST_/v1/videos/sync_to_complete_validated_H264_AAC_MP4"
  echo "source_git_head=$(git -C "$VLLM_SOURCE" rev-parse HEAD)"
  "$PYTHON" - <<'PY'
import importlib.metadata
import torch
for package in ("vllm", "vllm-omni"):
    print(f"{package}={importlib.metadata.version(package)}")
print(f"torch={torch.__version__}")
print(f"torch_cuda={torch.version.cuda}")
PY
  sha256sum \
    "$SCRIPT_DIR/benchmark_vllm_omni_h3_comm_15s.sh" \
    "$GPU_HEALTH_GATE" \
    "$GPU_BALANCE_SCRIPT" \
    "$VLLM_SOURCE/vllm_omni/diffusion/diffusion_engine.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/distributed/a2a_permute.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/distributed/flashinfer_ulysses.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/distributed/csrc/a2a_permute.cu" \
    "$VLLM_SOURCE/vllm_omni/diffusion/attention/backends/fastvideo_vsa.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/attention/ops/minimax_h3_vsa_layout.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/attention/ops/minimax_h3_vsa_deferred_gate.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/attention/ops/minimax_h3_vsa_owner_route.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/attention/ops/minimax_h3_vsa_o_bundle.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/attention/ops/minimax_h3_vsa_gate_compute_overlap.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/attention/parallel/ulysses.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/attention/layer.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/layers/fused_qk_norm_rope.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/data.py" \
    "$VLLM_SOURCE/vllm_omni/metrics/stats.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/fasth3.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/chunked_cpu_output.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/taeh3.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/pipeline_minimax_h3.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/minimax_h3_transformer.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/qkv_transport_calibration.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/qkv_transport_scales.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/temporal_chunk_parallel.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/ops/__init__.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/ops/vae/__init__.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/ops/vae/dispatch.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/ops/vae/qk_norm_rope.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/ops/vae/scaled_residual.py" \
    "$VLLM_SOURCE/vllm_omni/diffusion/models/minimax_h3/vae.py" \
    "$MODEL/model_index.json" \
    "$MODEL/video_vae/klvae.py"
  if [[ "$QKV_E4M3_TRANSPORT" == 1 ]]; then
    sha256sum "$QKV_E4M3_SCALE_SIDECAR"
  fi
  if [[ "$QKV_SINGLE_PHASE" == 1 ]]; then
    sha256sum \
      "$FLASHINFER_VSA_ROOT/flashinfer/comm/ulysses.py" \
      "$FLASHINFER_VSA_ROOT/csrc/ulysses_pcie.cu" \
      "$FLASHINFER_VSA_ROOT/csrc/ulysses_pcie_transport.cuh"
  fi
  if [[ "$FASTH3_VSA_MODE" == 1 && "$FASTH3_VSA_PROVIDER" == flashinfer ]]; then
    sha256sum \
      "$FLASHINFER_VSA_ROOT/flashinfer/cute_dsl/sparse/bsa_attn_sm120.py" \
      "$FLASHINFER_VSA_ROOT/flashinfer/cute_dsl/sparse/sm120_blk64/batched_static_scheduler.py" \
      "$FLASHINFER_VSA_ROOT/flashinfer/cute_dsl/sparse/sm120_blk64/flash_fwd_sm120.py"
  fi
  if [[ "$TAEH3_OUTPUT" == 1 ]]; then
    sha256sum "$TAEH3_CHECKPOINT"
  fi
  nvidia-smi
  nvidia-smi topo -m
  numactl --hardware
} >"$RUN_ROOT/environment.txt" 2>&1

# The optimization worktree is intentionally under active development.  A
# commit id alone cannot reproduce a dirty-tree measurement, so retain the
# exact tracked diff plus identities for every untracked source file.
git -C "$VLLM_SOURCE" status --short --branch >"$RUN_ROOT/source-git-status.txt"
git -C "$VLLM_SOURCE" diff --binary >"$RUN_ROOT/source-git-diff.patch"
while IFS= read -r relative_path; do
  sha256sum "$VLLM_SOURCE/$relative_path"
done < <(git -C "$VLLM_SOURCE" ls-files --others --exclude-standard) \
  >"$RUN_ROOT/source-untracked-sha256.txt"
if [[ "$QKV_SINGLE_PHASE" == 1 ]]; then
  git -C "$FLASHINFER_VSA_ROOT" status --short --branch \
    >"$RUN_ROOT/qkv-single-phase-flashinfer-git-status.txt"
  git -C "$FLASHINFER_VSA_ROOT" diff --binary \
    >"$RUN_ROOT/qkv-single-phase-flashinfer-git-diff.patch"
  while IFS= read -r relative_path; do
    sha256sum "$FLASHINFER_VSA_ROOT/$relative_path"
  done < <(git -C "$FLASHINFER_VSA_ROOT" ls-files --others --exclude-standard) \
    >"$RUN_ROOT/qkv-single-phase-flashinfer-untracked-sha256.txt"
fi
if [[ "$FASTH3_VSA_MODE" == 1 && "$FASTH3_VSA_PROVIDER" == flashinfer ]]; then
  git -C "$FLASHINFER_VSA_ROOT" status --short --branch \
    >"$RUN_ROOT/flashinfer-vsa-git-status.txt"
  git -C "$FLASHINFER_VSA_ROOT" diff --binary \
    >"$RUN_ROOT/flashinfer-vsa-git-diff.patch"
  while IFS= read -r relative_path; do
    sha256sum "$FLASHINFER_VSA_ROOT/$relative_path"
  done < <(git -C "$FLASHINFER_VSA_ROOT" ls-files --others --exclude-standard) \
    >"$RUN_ROOT/flashinfer-vsa-untracked-sha256.txt"
fi

{
  printf 'prompt=%s\n' "$PROMPT"
  printf 'width=%s\nheight=%s\nfps=24\nnum_inference_steps=%s\nflow_shift=12\nseed=1101\n' \
    "$WIDTH" "$HEIGHT" "$STEPS"
  printf 'aspect_ratio=16:9\nquality_contract=%s\n' \
    "$([[ "$FASTH3_VSA_MODE" == 1 ]] && echo distilled_vsa_student || ([[ "$FASTH3_MODE" == 1 ]] && echo distilled_dense_student || echo lossless_base_h3))"
  printf 'vae_decoder_tile_size=%s\nvae_decoder_tile_quality_contract=%s\n' \
    "$VAE_DECODER_TILE_SIZE" \
    "$([[ "$VAE_DECODER_TILE_SIZE" == 0 ]] && echo checkpoint_default || echo numerical_non_bit_exact_tile_context_and_blend_boundaries)"
  printf 'vae_temporal_chunk_parallel=%s\nvae_temporal_chunk_parallel_quality_contract=%s\n' \
    "$VAE_TEMPORAL_CHUNK_PARALLEL" \
    "$([[ "$VAE_TEMPORAL_CHUNK_PARALLEL" == 1 ]] && echo eager_bit_exact_candidate_requires_gpu_multiseed_ab || echo disabled)"
  printf 'vae_exact_ops_sm120=%s\nvae_exact_ops_sm120_quality_contract=%s\n' \
    "$VAE_EXACT_OPS_SM120" \
    "$([[ "$VAE_EXACT_OPS_SM120" == 1 ]] && echo bitwise_micro_validated_all_rank_dispatch_counters_full_sp8_raw_equivalence_pending || echo disabled)"
  printf 'vsa_fused_gate_untile=%s\nvsa_fused_gate_untile_quality_contract=%s\n' \
    "$VSA_FUSED_GATE_UNTILE" \
    "$([[ "$VSA_FUSED_GATE_UNTILE" == 1 ]] && echo production_shape_bit_exact_sm120_micro_full_sp8_pending || echo disabled)"
  printf 'vsa_deferred_gate_sp=%s\nvsa_deferred_gate_sp_quality_contract=%s\n' \
    "$VSA_DEFERRED_GATE_SP" \
    "$([[ "$VSA_DEFERRED_GATE_SP" == 1 ]] && echo bf16_bit_exact_sp2_nccl_and_rdma_validated_full_sp8_e2e_pending || echo disabled)"
  printf 'vsa_o_bundle=%s\nvsa_o_bundle_quality_contract=%s\n' \
    "$VSA_O_BUNDLE" \
    "$([[ "$VSA_O_BUNDLE" == 1 ]] && echo bf16_bit_exact_sm120_sp2_rdma_full_sp8_e2e_pending || echo disabled)"
  printf 'vsa_gate_compute_overlap=%s\nvsa_gate_compute_overlap_quality_contract=%s\n' \
    "$VSA_GATE_COMPUTE_OVERLAP" \
    "$([[ "$VSA_GATE_COMPUTE_OVERLAP" == 1 ]] && echo unchanged_bf16_projection_schedule_only_full_sp8_hash_ab_pending || echo disabled)"
  printf 'vsa_gate_compute_overlap_runtime_marker=MINIMAX_H3_VSA_GATE_COMPUTE_OVERLAP_ACTIVE_V1\n'
  printf 'vsa_gate_compute_overlap_request_counters=not_exposed_nvtx_trace_required\n'
  printf 'vsa_gate_compute_overlap_nvtx_side_prefix=minimax_h3.gate_compress.side:\n'
  printf 'vsa_gate_compute_overlap_nvtx_wait_prefix=minimax_h3.gate_compress.wait:\n'
  printf 'vsa_gate_compute_overlap_nvtx_expected_ranges_per_rank_4step_request=side:200,wait:200\n'
  printf 'video_decode_backend=%s\ntaeh3_output=%s\n' \
    "$TAEH3_VIDEO_DECODE_BACKEND" "$TAEH3_OUTPUT"
  printf 'vae_patch_parallel_size=%s\n' "$VAE_PATCH_PARALLEL_SIZE"
  printf 'taeh3_audio_decode_overlap=%s\ntaeh3_audio_decode_overlap_env=%s\n' \
    "$TAEH3_AUDIO_DECODE_OVERLAP" "$TAEH3_AUDIO_OVERLAP_ENV"
  printf 'taeh3_audio_decode_overlap_runtime_marker=%s\ntaeh3_audio_decode_overlap_quality_contract=%s\n' \
    "$TAEH3_AUDIO_OVERLAP_MARKER" \
    "$([[ "$TAEH3_AUDIO_DECODE_OVERLAP" == 1 ]] && echo schedule_only_same_decoder_outputs || echo disabled)"
  printf 'taeh3_cross_rank_audio_decode=%s\ntaeh3_cross_rank_audio_decode_env=%s\n' \
    "$TAEH3_CROSS_RANK_AUDIO_DECODE" "$TAEH3_CROSS_RANK_AUDIO_ENV"
  printf 'taeh3_cross_rank_audio_decode_runtime_marker=%s\ntaeh3_cross_rank_audio_decode_quality_contract=%s\n' \
    "$TAEH3_CROSS_RANK_AUDIO_MARKER" \
    "$([[ "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 1 ]] && echo rank_placement_only_exact_mp4_sha256_repeat3_validated_20260908 || echo disabled)"
  printf 'taeh3_cross_rank_audio_encode=%s\ntaeh3_cross_rank_audio_encode_env=%s\n' \
    "$TAEH3_CROSS_RANK_AUDIO_ENCODE" "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ENV"
  printf 'taeh3_cross_rank_audio_encode_runtime_marker=%s\ntaeh3_cross_rank_audio_encode_quality_contract=%s\n' \
    "$TAEH3_CROSS_RANK_AUDIO_ENCODE_MARKER" \
    "$([[ "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 1 ]] && echo independent_aac_packets_exact_cpu_mp4_ab_validated_full_e2e_sha_pending || echo disabled)"
  if [[ "$TAEH3_OUTPUT" == 1 ]]; then
    printf 'taeh3_checkpoint=%s\ntaeh3_checkpoint_revision=%s\ntaeh3_checkpoint_sha256=%s\n' \
      "$TAEH3_CHECKPOINT" "$TAEH3_EXPECTED_REVISION" "$TAEH3_EXPECTED_SHA256"
    printf 'taeh3_dtype=%s\ntaeh3_chunk_size=%s\ntaeh3_expected_output=22_chunks_362_frames_1280x704\n' \
      "$TAEH3_DTYPE" "$TAEH3_CHUNK_SIZE"
    printf 'taeh3_quality_contract=lossy_approximate_decoder_%s\n' "$TAEH3_DTYPE"
  fi
  printf 'flashinfer_required_bytes=%s\n' "$FLASHINFER_REQUIRED_BYTES"
  printf 'flashinfer_max_bytes=%s\n' "$FLASHINFER_MAX_BYTES"
  printf 'qkv_e4m3_transport=%s\nqkv_compute_dtype=bfloat16\nqkv_wire_dtype=%s\nreverse_o_dtype=bfloat16\n' \
    "$QKV_E4M3_TRANSPORT" \
    "$([[ "$QKV_E4M3_TRANSPORT" == 1 ]] && echo float8_e4m3fn || echo bfloat16)"
  printf 'minimax_h3_fp8_scope=%s\nminimax_h3_all_main_fp8_formal_contract=%s\n' \
    "$FP8_SCOPE" "$ALL_MAIN_FP8_CONTRACT"
  printf 'vsa_gate_compress_compute_dtype=%s\nvsa_gate_compress_output_dtype=bfloat16\n' \
    "$([[ "$FP8_SCOPE" == all-main ]] && echo float8_e4m3fn || echo bfloat16)"
  printf 'qkv_single_phase=%s\nqkv_single_phase_env=%s\nqkv_single_phase_env_owner=runner\n' \
    "$QKV_SINGLE_PHASE" "$QKV_SINGLE_PHASE_ENV"
  printf 'qkv_single_phase_protocol=%s\nqkv_single_phase_quality_contract=%s\n' \
    "$QKV_SINGLE_PHASE_PROTOCOL" \
    "$([[ "$QKV_SINGLE_PHASE" == 1 ]] && echo "$QKV_SINGLE_PHASE_QUALITY_CONTRACT" || echo disabled)"
  printf 'qkv_single_phase_runtime_marker=%s\n' "$QKV_SINGLE_PHASE_MARKER"
  printf 'qkv_single_phase_marker_contract=%s\nqkv_single_phase_expected_workers=8\n' \
    "$QKV_SINGLE_PHASE_MARKER_CONTRACT"
  printf 'qkv_single_phase_expected_calls_per_worker_per_request=%s\nqkv_single_phase_observed_call_count=not_exposed_by_runtime_activation_marker_only\n' \
    "$QKV_SINGLE_PHASE_EXPECTED_CALLS_PER_WORKER_PER_REQUEST"
  printf 'qkv_transport_observer_mode=%s\nqkv_transport_observer_timing_rung=%s\n' \
    "$QKV_TRANSPORT_OBSERVER_MODE" \
    "$([[ "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] && echo not_applicable || echo 0)"
  if [[ "$QKV_TRANSPORT_OBSERVER_MODE" != disabled ]]; then
    printf 'qkv_transport_observer_snapshot_dir=%s\nqkv_transport_observer_snapshot_format=provenance_bound_v3\n' \
      "$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR"
  fi
  if [[ "$QKV_TRANSPORT_OBSERVER_MODE" == validation ]]; then
    printf 'qkv_transport_observer_validation_scales_path=%s\nqkv_transport_observer_validation_scales_sha256=%s\n' \
      "$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_PATH" \
      "$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_SHA256"
  fi
  if [[ "$QKV_E4M3_TRANSPORT" == 1 ]]; then
    printf 'qkv_transport_quality_contract=lossy_static_per_block_e4m3_transport\n'
    printf 'qkv_e4m3_scale_sidecar=%s\nqkv_e4m3_scale_sidecar_sha256=%s\nqkv_e4m3_payload_sha256=%s\n' \
      "$QKV_E4M3_SCALE_SIDECAR" "$QKV_E4M3_EXPECTED_WHOLE_SHA256" \
      "$QKV_E4M3_EXPECTED_PAYLOAD_SHA256"
    printf 'qkv_e4m3_binding=%s\nqkv_e4m3_audit=%s\n' \
      "$QKV_E4M3_BINDING_JSON" "$QKV_E4M3_AUDIT_JSON"
  fi
  printf 'ulysses_mode=%s\nulysses_ring_size=%s\nh3_joint_attention_rows=%s\n' \
    "$ULYSSES_MODE" "$ULYSSES_RING_SIZE" "$H3_JOINT_ATTENTION_ROWS"
  printf 'extra_params={"task":"t2va","duration":15,"audio_flow_shift":3.0}\n'
} >"$RUN_ROOT/request.txt"

"$VLLM" serve --omni --help=all >"$RUN_ROOT/vllm-serve-help.txt" 2>&1
for required_flag in --omni --tensor-parallel-size --usp --ulysses-a2a-permute \
  --enable-distributed-layerwise-offload --dlo-use-allgather \
  --dlo-no-use-allgather --dlo-resident-layers \
  --enable-diffusion-pipeline-profiler; do
  grep -q -- "$required_flag" "$RUN_ROOT/vllm-serve-help.txt" || die "vLLM build lacks $required_flag"
done
if [[ "$FASTH3_MODE" == 1 ]]; then
  for required_flag in --task-type --lora-path; do
    grep -q -- "$required_flag" "$RUN_ROOT/vllm-serve-help.txt" || die "vLLM build lacks $required_flag"
  done
fi
if [[ "$FASTH3_VSA_MODE" == 1 ]]; then
  for required_flag in --diffusion-attention-config; do
    grep -q -- "$required_flag" "$RUN_ROOT/vllm-serve-help.txt" || die "vLLM build lacks $required_flag"
  done
fi
if [[ "$QKV_TRANSPORT_OBSERVER_MODE" != disabled ]]; then
  for required_flag in --enforce-eager --max-num-seqs; do
    grep -q -- "$required_flag" "$RUN_ROOT/vllm-serve-help.txt" || die \
      "vLLM build lacks $required_flag required by the QKV observer"
  done
fi
if [[ "$FP8_SCOPE" != none ]]; then
  grep -q -- --diffusion-quantization-config "$RUN_ROOT/vllm-serve-help.txt" || \
    die "vLLM build lacks --diffusion-quantization-config"
fi

busy_gpu_processes() {
  nvidia-smi --query-compute-apps=gpu_bus_id,pid,process_name,used_memory \
    --format=csv,noheader,nounits 2>/dev/null || true
}

require_idle_gpus() {
  local busy deadline last_busy=""
  deadline=$((SECONDS + EXCLUSIVE_GPU_TIMEOUT))
  while true; do
    busy="$(busy_gpu_processes)"
    if [[ -z "${busy//[[:space:]]/}" ]]; then
      [[ -z "$last_busy" ]] || echo "All eight GPUs are now idle; continuing"
      return 0
    fi
    if [[ "$busy" != "$last_busy" ]]; then
      echo "Waiting for existing GPU compute processes to exit:" >&2
      echo "$busy" >&2
      last_busy="$busy"
    fi
    if (( SECONDS >= deadline )); then
      die "All eight GPUs did not become idle within ${EXCLUSIVE_GPU_TIMEOUT}s; this runner never terminates unrelated jobs"
    fi
    sleep 2
  done
}

run_gpu_idle_health_gate() {
  local case_dir=$1
  local label=$2
  local report="$case_dir/gpu-health-${label}.json"

  if [[ "$GPU_IDLE_HEALTH_GATE" != 1 ]]; then
    printf 'status=disabled\nenv=VLLM_OMNI_GPU_IDLE_HEALTH_GATE\n' \
      >"$case_dir/gpu-health-${label}-disabled.txt"
    echo "WARNING: idle GPU health gate is disabled for $label" >&2
    return 0
  fi

  if ! "$PYTHON" "$GPU_HEALTH_GATE" idle \
    --gpu-ids "$GPU_ORDER" \
    --samples "$GPU_IDLE_HEALTH_SAMPLES" \
    --grace-seconds "$GPU_IDLE_HEALTH_GRACE_SECONDS" \
    --interval-seconds "$GPU_IDLE_HEALTH_INTERVAL_SECONDS" \
    --max-utilization-percent "$GPU_IDLE_MAX_UTILIZATION_PERCENT" \
    --max-memory-mib "$GPU_IDLE_MAX_MEMORY_MIB" \
    --max-temperature-c "$GPU_IDLE_MAX_TEMPERATURE_C" \
    --output "$report"; then
    die "Idle GPU health gate failed at $label; inspect $report"
  fi
}

run_gpu_balance_health_gate() {
  local case_dir=$1
  local raw_report="$case_dir/gpu-health-balance-raw.json"
  local validation_report="$case_dir/gpu-health-balance-validation.json"
  local stdout_report="$case_dir/gpu-health-balance-stdout.json"
  local stderr_report="$case_dir/gpu-health-balance-stderr.log"

  if [[ "$GPU_BALANCE_HEALTH_GATE" != 1 ]]; then
    printf 'status=disabled\nenv=VLLM_OMNI_GPU_BALANCE_HEALTH_GATE\n' \
      >"$case_dir/gpu-health-balance-disabled.txt"
    echo "WARNING: independent eight-GPU balance gate is disabled" >&2
    return 0
  fi

  # This exact H3-SP8 probe allocates about 1.2 GiB per device in short-lived
  # child processes.  Run it before AdaLN construction or server/model load,
  # then require both process and telemetry-idle cleanup before continuing.
  require_idle_gpus
  if ! CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES="$GPU_ORDER" \
    "$PYTHON" "$GPU_BALANCE_SCRIPT" \
    --devices 8 \
    --warmup "$GPU_BALANCE_WARMUP" \
    --rounds "$GPU_BALANCE_ROUNDS" \
    --iterations "$GPU_BALANCE_ITERATIONS" \
    --worker-timeout "$GPU_BALANCE_WORKER_TIMEOUT" \
    --smi-interval "$GPU_BALANCE_SMI_INTERVAL" \
    --json-out "$raw_report" \
    >"$stdout_report" 2>"$stderr_report"; then
    sed -n '1,240p' "$stderr_report" >&2 || true
    die "Independent eight-GPU balance probe failed; inspect $stdout_report and $stderr_report"
  fi

  if ! "$PYTHON" "$GPU_HEALTH_GATE" validate-balance \
    --input "$raw_report" \
    --gpu-ids "$GPU_ORDER" \
    --max-time-ratio "$GPU_BALANCE_MAX_TIME_RATIO" \
    --max-median-over-fleet "$GPU_BALANCE_MAX_MEDIAN_OVER_FLEET" \
    --min-clock-ratio "$GPU_BALANCE_MIN_CLOCK_RATIO" \
    --min-power-ratio "$GPU_BALANCE_MIN_POWER_RATIO" \
    --min-loaded-utilization-percent "$GPU_BALANCE_MIN_LOADED_UTILIZATION_PERCENT" \
    --min-telemetry-samples "$GPU_BALANCE_MIN_TELEMETRY_SAMPLES" \
    --output "$validation_report"; then
    die "Independent eight-GPU balance validation failed; inspect $validation_report"
  fi

  require_idle_gpus
  run_gpu_idle_health_gate "$case_dir" post-balance
}

run_gpu_health_gates() {
  local case_dir=$1
  run_gpu_idle_health_gate "$case_dir" pre-balance
  run_gpu_balance_health_gate "$case_dir"
}

# Return success when PID belongs to the server process tree.  A direct setsid
# launch keeps the vLLM workers in SERVER_PID's process group.  Nsight
# interactive launch inserts nsys-launcher and gives vLLM a child process
# group, so ancestry is the stable ownership relation in that mode.
pid_is_server_descendant() {
  local current=$1 parent depth=0
  [[ -n "$SERVER_PID" ]] || return 1
  while [[ "$current" =~ ^[0-9]+$ ]] && (( current > 1 && depth < 32 )); do
    [[ "$current" == "$SERVER_PID" ]] && return 0
    parent="$(ps -o ppid= -p "$current" 2>/dev/null | tr -d '[:space:]')"
    [[ "$parent" =~ ^[0-9]+$ ]] || return 1
    current="$parent"
    ((depth += 1))
  done
  return 1
}

# Return only GPU compute processes outside the vLLM server process group/tree.
foreign_gpu_processes() {
  local row bus_id pid process_name used_memory pgid owner
  while IFS= read -r row; do
    [[ -n "${row//[[:space:]]/}" ]] || continue
    IFS=',' read -r bus_id pid process_name used_memory <<<"$row"
    pid="${pid//[[:space:]]/}"
    [[ "$pid" =~ ^[0-9]+$ ]] || continue
    pgid="$(ps -o pgid= -p "$pid" 2>/dev/null | tr -d '[:space:]')"
    # The process can disappear between nvidia-smi and ps.
    [[ -n "$pgid" ]] || continue
    if [[ -z "$SERVER_PID" ]] || \
       { [[ "$pgid" != "$SERVER_PID" ]] && ! pid_is_server_descendant "$pid"; }; then
      owner="$(ps -o user= -p "$pid" 2>/dev/null | tr -d '[:space:]')"
      printf '%s,pid=%s,pgid=%s,user=%s,process=%s,memory_mib=%s\n' \
        "${bus_id//[[:space:]]/}" "$pid" "$pgid" "${owner:-unknown}" \
        "${process_name# }" "${used_memory//[[:space:]]/}"
    fi
  done < <(busy_gpu_processes)
}

wait_for_exclusive_gpu_ownership() {
  local case_dir=$1
  local label=$2
  local deadline foreign
  deadline=$((SECONDS + EXCLUSIVE_GPU_TIMEOUT))
  while true; do
    foreign="$(foreign_gpu_processes)"
    if [[ -z "${foreign//[[:space:]]/}" ]]; then
      printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ) exclusive" \
        >"$case_dir/${label}-gpu-exclusivity-preflight.txt"
      return 0
    fi
    {
      printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ) waiting"
      printf '%s\n' "$foreign"
    } >"$case_dir/${label}-gpu-exclusivity-preflight.txt"
    if (( SECONDS >= deadline )); then
      echo "Foreign GPU processes did not clear before $label:" >&2
      echo "$foreign" >&2
      die "Exclusive GPU ownership was not obtained within ${EXCLUSIVE_GPU_TIMEOUT}s"
    fi
    sleep 2
  done
}

start_foreign_gpu_monitor() {
  local case_dir=$1
  local label=$2
  local monitor_log="$case_dir/${label}-foreign-gpu-processes.log"
  : >"$monitor_log"
  (
    local foreign
    while kill -0 "$SERVER_PID" 2>/dev/null; do
      foreign="$(foreign_gpu_processes)"
      if [[ -n "${foreign//[[:space:]]/}" ]]; then
        {
          printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
          printf '%s\n' "$foreign"
        } >>"$monitor_log"
      fi
      sleep 1
    done
  ) &
  FOREIGN_GPU_MONITOR_PID=$!
}

stop_foreign_gpu_monitor() {
  if [[ -n "$FOREIGN_GPU_MONITOR_PID" ]] && \
    kill -0 "$FOREIGN_GPU_MONITOR_PID" 2>/dev/null; then
    kill -TERM "$FOREIGN_GPU_MONITOR_PID" 2>/dev/null || true
    wait "$FOREIGN_GPU_MONITOR_PID" 2>/dev/null || true
  fi
  FOREIGN_GPU_MONITOR_PID=""
}

port_is_busy() {
  curl -fsS --max-time 1 "http://127.0.0.1:$PORT/health" >/dev/null 2>&1
}

prepare_video_upload() {
  # Keep upload-disabled benchmark A/Bs from inheriting the failed [[ ]]
  # status at top level under `set -e`.
  [[ "$UPLOAD_VIDEOS" == 1 ]] || return 0
  [[ -d "$RANKINGS_REPO/.git" ]] || die "Rankings checkout is missing: $RANKINGS_REPO"
  [[ -z "$(git -C "$RANKINGS_REPO" status --porcelain)" ]] || \
    die "Rankings checkout is not clean: $RANKINGS_REPO"
  git -C "$RANKINGS_REPO" var GIT_AUTHOR_IDENT >/dev/null || \
    die "Configure a Git author name and email in $RANKINGS_REPO"
  GIT_TERMINAL_PROMPT=0 git -C "$RANKINGS_REPO" fetch origin "$RANKINGS_BRANCH" >&2
  git -C "$RANKINGS_REPO" merge --ff-only "origin/$RANKINGS_BRANCH" >&2
  GIT_TERMINAL_PROMPT=0 git -C "$RANKINGS_REPO" push --dry-run origin "HEAD:$RANKINGS_BRANCH"
}

upload_case_video() {
  local case_name=$1
  local source_video=$2
  local destination_dir
  if [[ "$FASTH3_VSA_MODE" == 1 ]]; then
    destination_dir="videos/minimax-fasth3-vsa-datafree-pro5000-sm120-vllm-omni-t2va-15s-4step"
  elif [[ "$FASTH3_MODE" == 1 ]]; then
    destination_dir="videos/minimax-fasth3-dense-datafree-pro5000-sm120-t2va-15s-4step"
  else
    destination_dir="videos/minimax-h3-pro5000-sm120-t2va-15s-${STEPS}sigma"
  fi
  local destination_name="${STAMP}-${case_name}.mp4"
  local destination_rel="$destination_dir/$destination_name"

  if [[ "$UPLOAD_VIDEOS" != 1 ]]; then
    printf '%s' '-'
    return
  fi

  GIT_TERMINAL_PROMPT=0 git -C "$RANKINGS_REPO" fetch origin "$RANKINGS_BRANCH" >&2 || return
  git -C "$RANKINGS_REPO" merge --ff-only "origin/$RANKINGS_BRANCH" >&2 || return
  mkdir -p "$RANKINGS_REPO/$destination_dir" || return
  cp -- "$source_video" "$RANKINGS_REPO/$destination_rel" || return
  git -C "$RANKINGS_REPO" add -- "$destination_rel" || return
  git -C "$RANKINGS_REPO" commit -m \
    "Add MiniMax-H3 PRO 5000 ${case_name} 15s ${RUN_CONTRACT} video" >&2 || return
  GIT_TERMINAL_PROMPT=0 git -C "$RANKINGS_REPO" push origin "HEAD:$RANKINGS_BRANCH" >&2 || return
  printf '%s/blob/%s/%s' "$RANKINGS_WEB_BASE" "$RANKINGS_BRANCH" "$destination_rel"
}

prepare_lsa_toolkit() {
  # Keep nvcc and the CUDA headers on the exact PyTorch CUDA minor. The venv
  # can be partially upgraded (currently nvcc 13.3 with runtime headers 13.2),
  # which CCCL correctly rejects as an incompatible toolchain.
  local default_cuda="$WORKSPACE_DIR/toolchains/cuda-13.2.78-full/nvidia/cu13"
  local cuda_home="${VLLM_OMNI_CUDA_HOME:-$default_cuda}"
  [[ -x "$cuda_home/bin/nvcc" && -f "$cuda_home/include/cuda.h" ]] || die \
    "Fused A2A requires a complete CUDA toolkit: $cuda_home"
  CUDA_HOME_CANDIDATE="$cuda_home" "$PYTHON" - <<'PY'
import os
import re
import subprocess
from pathlib import Path

import torch

cuda_home = Path(os.environ["CUDA_HOME_CANDIDATE"])
nvcc = subprocess.check_output([str(cuda_home / "bin/nvcc"), "--version"], text=True)
match = re.search(r"release\s+(\d+\.\d+)", nvcc)
nvcc_minor = match.group(1) if match else "unknown"
torch_minor = str(torch.version.cuda)
if nvcc_minor != torch_minor:
    raise SystemExit(
        f"LSA CUDA mismatch: nvcc={nvcc_minor}, torch.version.cuda={torch_minor}, CUDA_HOME={cuda_home}"
    )
print(f"LSA CUDA toolchain: nvcc={nvcc_minor}, torch={torch_minor}, CUDA_HOME={cuda_home}")
PY
  export CUDA_HOME="$cuda_home"
  export PATH="$CUDA_HOME/bin:$PATH"
  export LD_LIBRARY_PATH="$CUDA_HOME/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
  export TORCH_CUDA_ARCH_LIST="12.0"
  export MAX_JOBS="${MAX_JOBS:-8}"

  # torch's extension build lock is not process-wide. Build once here so that
  # eight spawned workers never race to import a not-yet-linked shared object.
  echo "Prebuilding fused Ulysses A2A extension"
  "$PYTHON" -c \
    'from vllm_omni.diffusion.distributed.a2a_permute import ensure_a2a_permute_available; ensure_a2a_permute_available()'
}

prepare_flashinfer_ulysses_rdma() {
  local default_cuda="$WORKSPACE_DIR/toolchains/cuda-13.2.78-full/nvidia/cu13"
  local cuda_home="${VLLM_OMNI_CUDA_HOME:-$default_cuda}"
  local cached_so="$FLASHINFER_WORKSPACE/.cache/flashinfer/$FLASHINFER_EXPECTED_VERSION/120f/cached_ops/ulysses_pcie/ulysses_pcie.so"

  [[ "$WIDTH" == 1280 && "$HEIGHT" == 720 ]] || die \
    "The pinned FlashInfer capacity is validated only for the 1280x720 (effective 1280x704) H3 run"
  (( FLASHINFER_MAX_BYTES >= FLASHINFER_REQUIRED_BYTES )) || die \
    "FlashInfer capacity must cover the ${FLASHINFER_REQUIRED_BYTES}-byte maximum packed H3 SP8 operand for this route"
  [[ -f "$FLASHINFER_PR_SITE/flashinfer/_build_meta.py" ]] || die \
    "Pinned FlashInfer PR #4876 overlay is missing: $FLASHINFER_PR_SITE"
  [[ -x "$cuda_home/bin/nvcc" && -f "$cuda_home/include/cuda.h" ]] || die \
    "FlashInfer PCIe requires the complete CUDA 13.2 toolkit: $cuda_home"
  [[ -f "$cached_so" ]] || die \
    "Pinned SM120 ulysses_pcie JIT artifact is missing: $cached_so"

  # The overlay contains only FlashInfer, while the active dirty vLLM-Omni
  # source remains next in PYTHONPATH so AdaLN/profiling/VAE patches stack.
  export PYTHONPATH="$FLASHINFER_PR_SITE:$PYTHONPATH"
  export FLASHINFER_WORKSPACE_BASE="$FLASHINFER_WORKSPACE"
  export FLASHINFER_ULYSSES_PCIE_ROUTE="$FLASHINFER_ULYSSES_ROUTE"
  export FLASHINFER_CUDA_ARCH_LIST=12.0f
  export CUDA_HOME="$cuda_home"
  export FLASHINFER_NVCC="$CUDA_HOME/bin/nvcc"
  export FLASHINFER_EXTRA_LDFLAGS="-L$CUDA_HOME/lib"
  export PATH="$CUDA_HOME/bin:$PATH"
  export LD_LIBRARY_PATH="$CUDA_HOME/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
  export TORCH_CUDA_ARCH_LIST=12.0
  export VLLM_OMNI_ULYSSES_A2A_BACKEND=flashinfer-pcie
  if [[ "$FLASHINFER_ULYSSES_ROUTE" == rdma ]]; then
    export VLLM_OMNI_FLASHINFER_ULYSSES_REQUIRE_RDMA=1
  else
    # FlashInfer has no REQUIRE_HYBRID switch.  Fail-closed validation below
    # checks all eight armed communicator markers for transport=hybrid, so an
    # all-P2P/NCCL fallback can never become an accepted measurement.
    export VLLM_OMNI_FLASHINFER_ULYSSES_REQUIRE_RDMA=0
  fi
  export VLLM_OMNI_FLASHINFER_ULYSSES_MAX_BYTES="$FLASHINFER_MAX_BYTES"

  EXPECTED_VERSION="$FLASHINFER_EXPECTED_VERSION" \
    EXPECTED_COMMIT="$FLASHINFER_EXPECTED_COMMIT" \
    EXPECTED_SITE="$FLASHINFER_PR_SITE" \
    EXPECTED_ROUTE="$FLASHINFER_ULYSSES_ROUTE" \
    "$PYTHON" - <<'PY'
import os
from pathlib import Path

import flashinfer
from flashinfer.comm.ulysses import missing_ulysses_pcie_dependencies
from vllm_omni.diffusion.distributed.flashinfer_ulysses import (
    ensure_flashinfer_pcie_available,
)

observed_site = Path(flashinfer.__file__).resolve().parents[1]
expected_site = Path(os.environ["EXPECTED_SITE"]).resolve()
if observed_site != expected_site:
    raise SystemExit(f"FlashInfer imports from {observed_site}, expected {expected_site}")
if flashinfer.__version__ != os.environ["EXPECTED_VERSION"]:
    raise SystemExit(
        f"FlashInfer version {flashinfer.__version__!r} != {os.environ['EXPECTED_VERSION']!r}"
    )
if flashinfer.__git_commit__ != os.environ["EXPECTED_COMMIT"]:
    raise SystemExit(
        f"FlashInfer commit {flashinfer.__git_commit__!r} != {os.environ['EXPECTED_COMMIT']!r}"
    )
missing = missing_ulysses_pcie_dependencies()
if missing:
    raise SystemExit(f"FlashInfer PCIe JIT dependencies missing: {missing}")
ensure_flashinfer_pcie_available()
print(
    f"FlashInfer PCIe overlay: version={flashinfer.__version__} "
    f"commit={flashinfer.__git_commit__} route={os.environ['EXPECTED_ROUTE']}"
)
PY
}

prepare_fasth3_vsa_runtime() {
  [[ "$FASTH3_VSA_MODE" == 1 ]] || return 0

  # Use only FastVideo's package source here.  Prepending the separate
  # FastVideo virtualenv's site-packages would also replace this vLLM env's
  # CUDA-13.2 PyTorch with the CUDA-13.0 build.
  export PYTHONPATH="$FASTVIDEO_KERNEL_PYTHON:$PYTHONPATH"
  if [[ "$FASTH3_VSA_PROVIDER" == flashinfer ]]; then
    export PYTHONPATH="$FLASHINFER_VSA_ROOT:$PYTHONPATH"
    export FLASHINFER_WORKSPACE_BASE="$FLASHINFER_VSA_WORKSPACE"
    export FLASH_ATTENTION_CUTE_DSL_CACHE_ENABLED=0
    unset FLASH_ATTENTION_CUTE_DSL_CACHE_DIR
    mkdir -p "$FLASHINFER_WORKSPACE_BASE"
  fi

  EXPECTED_PROVIDER="$FASTH3_VSA_PROVIDER" \
    EXPECTED_FASTVIDEO_ROOT="$FASTVIDEO_KERNEL_PYTHON" \
    EXPECTED_FLASHINFER_ROOT="$FLASHINFER_VSA_ROOT" \
    EXPECTED_FLASHINFER_COMMIT="$FLASHINFER_VSA_EXPECTED_COMMIT" \
    "$PYTHON" - <<'PY'
import importlib.util
import os
from pathlib import Path

fastvideo_root = Path(os.environ["EXPECTED_FASTVIDEO_ROOT"]).resolve()
spec = importlib.util.find_spec("fastvideo_kernel")
if spec is None or spec.origin is None:
    raise SystemExit("fastvideo_kernel cannot be resolved")
fastvideo_origin = Path(spec.origin).resolve()
if not fastvideo_origin.is_relative_to(fastvideo_root):
    raise SystemExit(
        f"fastvideo_kernel import escaped package-only source: "
        f"origin={fastvideo_origin}, root={fastvideo_root}"
    )
print(f"FastVideo kernel source: {fastvideo_origin}")

if os.environ["EXPECTED_PROVIDER"] == "flashinfer":
    import flashinfer

    flashinfer_root = Path(os.environ["EXPECTED_FLASHINFER_ROOT"]).resolve()
    flashinfer_origin = Path(flashinfer.__file__).resolve()
    if not flashinfer_origin.is_relative_to(flashinfer_root):
        raise SystemExit(
            f"FlashInfer import escaped combined checkout: "
            f"origin={flashinfer_origin}, root={flashinfer_root}"
        )
    observed_commit = str(getattr(flashinfer, "__git_commit__", ""))
    if observed_commit != os.environ["EXPECTED_FLASHINFER_COMMIT"]:
        raise SystemExit(
            f"FlashInfer runtime commit {observed_commit!r} != "
            f"{os.environ['EXPECTED_FLASHINFER_COMMIT']!r}"
        )
    kernel = importlib.util.find_spec("flashinfer.cute_dsl.sparse.bsa_attn_sm120")
    if kernel is None or kernel.origin is None:
        raise SystemExit("FlashInfer SM120 blk64 VSA module cannot be resolved")
    print(
        f"FlashInfer VSA provider: origin={flashinfer_origin} "
        f"commit={observed_commit} kernel={Path(kernel.origin).resolve()}"
    )
PY
}

build_adaln_cache() {
  if [[ -f "$ADALN_CACHE" && "${MINIMAX_H3_REBUILD_ADALN_CACHE:-0}" != 1 ]]; then
    echo "Reusing exact AdaLN sidecar: $ADALN_CACHE"
    return
  fi
  require_idle_gpus
  mkdir -p "$(dirname "$ADALN_CACHE")"
  if [[ "$FASTH3_MODE" == 1 ]]; then
    echo "Building exact ${FASTH3_VARIANT} four-forward AdaLN sidecar on physical GPU ${GPU_IDS[0]}"
    CUDA_VISIBLE_DEVICES="${GPU_IDS[0]}" "$PYTHON" "$ADALN_BUILDER" \
      --transformer-path "$MODEL/transformer" \
      --model-variant fl2va \
      --mode t2va \
      --fasth3-adapter "$FASTH3_LORA" \
      --base-schedule "${FASTH3_BASE_SCHEDULE[@]}" \
      --flow-shift 12 \
      --audio-flow-shift 3 \
      --output "$ADALN_CACHE"
  else
    echo "Building exact ${STEPS}-sigma AdaLN sidecar on physical GPU ${GPU_IDS[0]}"
    CUDA_VISIBLE_DEVICES="${GPU_IDS[0]}" "$PYTHON" "$ADALN_BUILDER" \
      --transformer-path "$MODEL/transformer" \
      --model-variant fl2va \
      --mode t2va \
      --num-inference-steps "$STEPS" \
      --flow-shift 12 \
      --audio-flow-shift 3 \
      --output "$ADALN_CACHE"
  fi
}

prevalidate_fasth3_adaln_sidecar() {
  [[ "$FASTH3_MODE" == 1 ]] || return 0
  ADALN_CACHE_PATH="$ADALN_CACHE" \
  FASTH3_ADAPTER_PATH="$FASTH3_LORA" \
  FASTH3_EXPECTED_SHA256="$FASTH3_EXPECTED_SHA256" \
  FASTH3_EXPECTED_SIZE="$FASTH3_EXPECTED_SIZE" \
  "$PYTHON" - <<'PY'
import json
import os

from vllm_omni.diffusion.models.minimax_h3.adaln_cache import (
    prevalidate_minimax_h3_fasth3_adaln_sidecar,
)

binding = prevalidate_minimax_h3_fasth3_adaln_sidecar(
    os.environ["ADALN_CACHE_PATH"],
    adapter_path=os.environ["FASTH3_ADAPTER_PATH"],
    model_variant="fl2va",
    mode="t2va",
    base_schedule=(0.999, 0.749, 0.5, 0.25, 0.0),
    flow_shift=12.0,
    audio_flow_shift=3.0,
)
adapter = binding.fasth3_adapter
if adapter is None:
    raise SystemExit("FastH3 sidecar prevalidation returned no adapter identity")
if adapter.sha256 != os.environ["FASTH3_EXPECTED_SHA256"]:
    raise SystemExit(
        f"FastH3 sidecar adapter SHA256 {adapter.sha256} does not match pinned "
        f"{os.environ['FASTH3_EXPECTED_SHA256']}"
    )
if adapter.size_bytes != int(os.environ["FASTH3_EXPECTED_SIZE"]):
    raise SystemExit(
        f"FastH3 sidecar adapter size {adapter.size_bytes} does not match pinned "
        f"{os.environ['FASTH3_EXPECTED_SIZE']}"
    )
print(
    "__FASTH3_ADALN_BINDING__"
    + json.dumps(
        binding.to_dict(),
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    )
)
PY
}

prevalidate_fasth3_qkv_e4m3_sidecar() {
  [[ "$QKV_E4M3_TRANSPORT" == 1 ]] || return 0
  ADALN_BINDING_JSON="$FASTH3_ADALN_BINDING_JSON" \
  QKV_ARTIFACT_BINDING_JSON="$QKV_E4M3_ARTIFACT_BINDING_JSON" \
  QKV_SCALE_PATH="$QKV_E4M3_SCALE_SIDECAR" \
  QKV_EXPECTED_PAYLOAD_SHA256="$QKV_E4M3_EXPECTED_PAYLOAD_SHA256" \
  QKV_SOURCE_MODEL_REVISION="$QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION" \
  QKV_RUNTIME_CHECKPOINT_REVISION="$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION" \
  QKV_RUNTIME_MANIFEST_SHA256="$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256" \
  QKV_KERNEL_PROVIDER="$QKV_E4M3_KERNEL_PROVIDER" \
  QKV_KERNEL_ABI="$QKV_E4M3_KERNEL_ABI" \
  QKV_DIT_QUANT_MODE="$MLP_FP8_DIT_QUANT_MODE" \
  QKV_PROMPT_SHA256="$QKV_E4M3_PROMPT_SHA256" \
  QKV_PREFIX_TILE_COUNT="$QKV_E4M3_PREFIX_TILE_COUNT" \
  QKV_COMPACT_ROW_COUNT="$QKV_E4M3_COMPACT_ROW_COUNT" \
  QKV_PADDED_ROW_COUNT="$QKV_E4M3_PADDED_ROW_COUNT" \
  "$PYTHON" - <<'PY'
import json
import os

import torch

from vllm_omni.diffusion.models.minimax_h3.adaln_cache import (
    MiniMaxH3AdalnCacheBinding,
)
from vllm_omni.diffusion.models.minimax_h3.qkv_transport_scales import (
    MiniMaxH3QKVTransportMediaProfile,
    MiniMaxH3QKVTransportScaleBinding,
    MiniMaxH3QKVTransportScales,
    prevalidate_minimax_h3_qkv_transport_scale_sidecar,
)

adaln_binding = MiniMaxH3AdalnCacheBinding.from_dict(
    json.loads(os.environ["ADALN_BINDING_JSON"])
)
adapter = adaln_binding.fasth3_adapter
if adapter is None:
    raise SystemExit("QKV transport scale prevalidation requires an adapter-bound AdaLN sidecar")
adapter_header = json.loads(adapter.header_identity)
if not isinstance(adapter_header, dict):
    raise SystemExit("FastH3 adapter header identity must be a JSON object")
if adapter_header.get("base_revision") != os.environ["QKV_SOURCE_MODEL_REVISION"]:
    raise SystemExit(
        "QKV source_model_revision does not match the fused adapter base revision"
    )
artifact_binding = MiniMaxH3QKVTransportScaleBinding.from_dict(
    json.loads(os.environ["QKV_ARTIFACT_BINDING_JSON"])
)
if artifact_binding.expected_observation_count != 4:
    raise SystemExit("formal QKV E4M3 sidecar must bind exactly four observations")

media = MiniMaxH3QKVTransportMediaProfile(
    width=1280,
    height=720,
    fps=24,
    num_frames=362,
    requested_duration_seconds=15.0,
    seed=1101,
    prompt_sha256=os.environ["QKV_PROMPT_SHA256"],
    effective_width=1280,
    effective_height=704,
    video_shape=(107, 22, 40),
    video_tile_count=1620,
    prefix_tile_count=int(os.environ["QKV_PREFIX_TILE_COUNT"]),
    compact_row_count=int(os.environ["QKV_COMPACT_ROW_COUNT"]),
    padded_row_count=int(os.environ["QKV_PADDED_ROW_COUNT"]),
)
binding = prevalidate_minimax_h3_qkv_transport_scale_sidecar(
    os.environ["QKV_SCALE_PATH"],
    source_model_revision=os.environ["QKV_SOURCE_MODEL_REVISION"],
    runtime_checkpoint_revision=os.environ["QKV_RUNTIME_CHECKPOINT_REVISION"],
    runtime_checkpoint_manifest_sha256=os.environ["QKV_RUNTIME_MANIFEST_SHA256"],
    campaign_uuid=artifact_binding.campaign_uuid,
    run_contract_sha256=artifact_binding.run_contract_sha256,
    expected_observation_count=artifact_binding.expected_observation_count,
    adapter=adapter,
    base_schedule=(0.999, 0.749, 0.5, 0.25, 0.0),
    flow_shift=12.0,
    audio_flow_shift=3.0,
    kernel_provider=os.environ["QKV_KERNEL_PROVIDER"],
    kernel_abi=os.environ["QKV_KERNEL_ABI"],
    media_profile=media,
    expected_payload_sha256=os.environ["QKV_EXPECTED_PAYLOAD_SHA256"],
    dit_quant_mode=os.environ["QKV_DIT_QUANT_MODE"],
)
loader = MiniMaxH3QKVTransportScales(
    os.environ["QKV_SCALE_PATH"],
    runtime_binding=binding,
)
rows = loader.load()
audit = loader.audit_tensors
required_audit = {
    "observed_absmax",
    "finite_count",
    "nonfinite_count",
    "numel",
    "observation_count",
    "saturation_count",
}
if set(audit) != required_audit:
    raise SystemExit(
        "formal QKV E4M3 sidecar requires exact audit tensors; "
        f"missing={sorted(required_audit - set(audit))}, "
        f"unexpected={sorted(set(audit) - required_audit)}"
    )
if bool((audit["nonfinite_count"] != 0).any()):
    raise SystemExit("QKV E4M3 calibration audit contains non-finite observations")
if bool((audit["saturation_count"] != 0).any()):
    raise SystemExit("QKV E4M3 validation audit contains saturated values")
if not torch.equal(
    audit["finite_count"] + audit["nonfinite_count"],
    audit["numel"],
):
    raise SystemExit("QKV E4M3 audit sample counts are inconsistent")
if not bool((audit["observation_count"] > 0).all()):
    raise SystemExit("QKV E4M3 audit does not cover every layer/component")

scales = torch.tensor(rows, dtype=torch.float32)
summary = {
    "audit_tensor_names": sorted(audit),
    "finite_count": int(audit["finite_count"].sum().item()),
    "nonfinite_count": int(audit["nonfinite_count"].sum().item()),
    "observation_count_min": int(audit["observation_count"].min().item()),
    "observation_count_max": int(audit["observation_count"].max().item()),
    "observed_absmax_max": float(audit["observed_absmax"].max().item()),
    "saturation_count": int(audit["saturation_count"].sum().item()),
    "scale_shape": list(scales.shape),
    "scale_order": ["q", "k", "v"],
    "scale_min": float(scales.min().item()),
    "scale_max": float(scales.max().item()),
}
print(
    "__QKV_E4M3_BINDING__"
    + json.dumps(
        binding.to_dict(),
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    )
)
print(
    "__QKV_E4M3_AUDIT__"
    + json.dumps(summary, allow_nan=False, separators=(",", ":"), sort_keys=True)
)
PY
}

probe_media() {
  local media_path=$1
  local report_path=$2
  MEDIA_PATH="$media_path" REPORT_PATH="$report_path" FFPROBE="$FFPROBE" "$PYTHON" - <<'PY'
import json
import os
from pathlib import Path
import subprocess
from fractions import Fraction

media_path = Path(os.environ["MEDIA_PATH"])
report_path = Path(os.environ["REPORT_PATH"])
expected_duration = 15.0
duration_tolerance = 0.25
ffprobe = os.environ["FFPROBE"]

if not media_path.is_file() or media_path.stat().st_size <= 0:
    raise SystemExit(f"media contract failed: missing or empty file: {media_path}")

result = subprocess.run(
    [
        ffprobe,
        "-v",
        "error",
        "-show_entries",
        "format=duration,size:stream=index,codec_type,codec_name,width,height,avg_frame_rate,duration",
        "-of",
        "json",
        str(media_path),
    ],
    check=False,
    capture_output=True,
    text=True,
)
if result.returncode != 0:
    report_path.write_text(
        f"ffprobe_exit={result.returncode}\nffprobe_stderr={result.stderr.strip()}\n",
        encoding="utf-8",
    )
    raise SystemExit(f"media contract failed: ffprobe rejected {media_path}; see {report_path}")

metadata = json.loads(result.stdout)
streams = metadata.get("streams", [])
format_info = metadata.get("format", {})
try:
    duration = float(format_info.get("duration", 0.0))
except (TypeError, ValueError):
    duration = 0.0

video_streams = [stream for stream in streams if stream.get("codec_type") == "video"]
audio_streams = [stream for stream in streams if stream.get("codec_type") == "audio"]
problems = []
if abs(duration - expected_duration) > duration_tolerance:
    problems.append(
        f"duration={duration:.6f}, expected {expected_duration:.3f}+/-{duration_tolerance:.3f}s"
    )
if len(video_streams) != 1:
    problems.append(f"video_stream_count={len(video_streams)}, expected 1")
else:
    video = video_streams[0]
    if video.get("codec_name") != "h264":
        problems.append(f"video_codec={video.get('codec_name')!r}, expected 'h264'")
    if (video.get("width"), video.get("height")) != (1280, 704):
        problems.append(
            f"video_geometry={video.get('width')}x{video.get('height')}, expected 1280x704"
        )
    try:
        fps = float(Fraction(video.get("avg_frame_rate", "0/1")))
    except (TypeError, ValueError, ZeroDivisionError):
        fps = 0.0
    if abs(fps - 24.0) > 1e-6:
        problems.append(f"video_fps={fps:.6f}, expected 24")
if len(audio_streams) != 1:
    problems.append(f"audio_stream_count={len(audio_streams)}, expected 1")
elif audio_streams[0].get("codec_name") != "aac":
    problems.append(f"audio_codec={audio_streams[0].get('codec_name')!r}, expected 'aac'")

lines = [
    f"duration={duration:.6f}",
    f"size={media_path.stat().st_size}",
    f"contract_status={'failed' if problems else 'ok'}",
]
for stream in streams:
    index = stream.get("index", "unknown")
    lines.append(f"stream.{index}.type={stream.get('codec_type')}")
    lines.append(f"stream.{index}.codec={stream.get('codec_name')}")
    if stream.get("codec_type") == "video":
        lines.append(f"stream.{index}.width={stream.get('width')}")
        lines.append(f"stream.{index}.height={stream.get('height')}")
        lines.append(f"stream.{index}.fps={stream.get('avg_frame_rate')}")
for problem in problems:
    lines.append(f"contract_error={problem}")
report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
if problems:
    raise SystemExit(
        f"media contract failed for {media_path}: {'; '.join(problems)}; see {report_path}"
    )
print(f"{duration:.6f}")
PY
}

validate_taeh3_output_artifact() {
  local media_path=$1
  local case_dir=$2
  local report_path="$case_dir/taeh3-output-manifest.txt"
  [[ "$TAEH3_OUTPUT" == 1 ]] || return 0

  if ! MEDIA_PATH="$media_path" \
    REPORT_PATH="$report_path" \
    RUNTIME_REPORT="$case_dir/taeh3-runtime-validation.txt" \
    FFPROBE="$FFPROBE" \
    ACTION="$ACTION" \
    GPU_CLOCK_POLICY="$GPU_CLOCK_POLICY" \
    TAEH3_CHECKPOINT="$TAEH3_CHECKPOINT" \
    TAEH3_CHECKPOINT_SHA256="$TAEH3_EXPECTED_SHA256" \
    TAEH3_DTYPE="$TAEH3_DTYPE" \
    "$PYTHON" - <<'TAEH3_OUTPUT_VALIDATOR_PY'
import hashlib
import json
import os
from fractions import Fraction
from pathlib import Path
import subprocess

media_path = Path(os.environ["MEDIA_PATH"])
report_path = Path(os.environ["REPORT_PATH"])
runtime_report = Path(os.environ["RUNTIME_REPORT"])
problems: list[str] = []

if not media_path.is_file() or media_path.stat().st_size <= 0:
    problems.append(f"missing_or_empty_media={media_path}")
if not runtime_report.is_file():
    problems.append(f"missing_runtime_report={runtime_report}")
else:
    runtime_lines = runtime_report.read_text(encoding="utf-8", errors="replace").splitlines()
    if "validation_status=ok" not in runtime_lines:
        problems.append("taeh3_runtime_validation_not_ok")

metadata: dict[str, object] = {}
if not problems:
    result = subprocess.run(
        [
            os.environ["FFPROBE"],
            "-v",
            "error",
            "-count_frames",
            "-show_entries",
            (
                "format=duration,size:"
                "stream=index,codec_type,codec_name,width,height,avg_frame_rate,"
                "nb_read_frames,nb_frames,sample_rate,channels"
            ),
            "-of",
            "json",
            str(media_path),
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        problems.append(f"ffprobe_exit={result.returncode}:{result.stderr.strip()}")
    else:
        metadata = json.loads(result.stdout)

streams = metadata.get("streams", []) if isinstance(metadata, dict) else []
video_streams = [stream for stream in streams if stream.get("codec_type") == "video"]
audio_streams = [stream for stream in streams if stream.get("codec_type") == "audio"]
video: dict[str, object] = video_streams[0] if len(video_streams) == 1 else {}
audio: dict[str, object] = audio_streams[0] if len(audio_streams) == 1 else {}
if metadata:
    if len(video_streams) != 1:
        problems.append(f"video_stream_count={len(video_streams)}")
    if len(audio_streams) != 1:
        problems.append(f"audio_stream_count={len(audio_streams)}")
    if video:
        if video.get("codec_name") != "h264":
            problems.append(f"video_codec={video.get('codec_name')!r}")
        if (video.get("width"), video.get("height")) != (1280, 704):
            problems.append(f"video_geometry={video.get('width')}x{video.get('height')}")
        try:
            fps = Fraction(str(video.get("avg_frame_rate", "0/1")))
        except (ValueError, ZeroDivisionError):
            fps = Fraction(0, 1)
        if fps != Fraction(24, 1):
            problems.append(f"video_fps={fps}")
        raw_frames = video.get("nb_read_frames") or video.get("nb_frames")
        try:
            frame_count = int(str(raw_frames))
        except (TypeError, ValueError):
            frame_count = -1
        if frame_count != 362:
            problems.append(f"video_frames={frame_count}, expected=362")
    if audio:
        if audio.get("codec_name") != "aac":
            problems.append(f"audio_codec={audio.get('codec_name')!r}")
        if str(audio.get("sample_rate")) != "32000":
            problems.append(f"audio_sample_rate={audio.get('sample_rate')!r}")
        try:
            channels = int(str(audio.get("channels")))
        except (TypeError, ValueError):
            channels = -1
        if channels != 2:
            problems.append(f"audio_channels={channels}, expected=2")

digest = "missing"
size = 0
if media_path.is_file():
    size = media_path.stat().st_size
    sha = hashlib.sha256()
    with media_path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            sha.update(block)
    digest = sha.hexdigest()

lines = [
    f"action={os.environ['ACTION']}",
    f"gpu_clock_policy={os.environ['GPU_CLOCK_POLICY']}",
    "video_decode_backend=taeh3",
    f"taeh3_dtype={os.environ['TAEH3_DTYPE']}",
    "taeh3_chunk_size=5",
    "taeh3_decoded_chunks=22",
    "video_frames=362",
    "video_geometry=1280x704",
    "video_fps=24",
    "video_codec=h264",
    "audio_codec=aac",
    "audio_sample_rate=32000",
    "audio_channels=2",
    "chunked_cpu_mp4_slots=2",
    "nvenc=disabled",
    f"taeh3_checkpoint={os.environ['TAEH3_CHECKPOINT']}",
    f"taeh3_checkpoint_sha256={os.environ['TAEH3_CHECKPOINT_SHA256']}",
    f"runtime_validation={runtime_report}",
    f"media_path={media_path}",
    f"media_size={size}",
    f"media_sha256={digest}",
    f"finalized_mp4={'false' if problems else 'true'}",
    f"validation_status={'failed' if problems else 'ok'}",
]
lines.extend(f"error={problem}" for problem in problems)
report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
if problems:
    raise SystemExit("TAEH3 finalized-MP4 contract failed: " + "; ".join(problems))
TAEH3_OUTPUT_VALIDATOR_PY
  then
    echo "TAEH3 finalized-MP4 validation failed; see $report_path" >&2
    return 1
  fi
  local manifest_sha256
  manifest_sha256="$(sha256sum "$report_path")"
  manifest_sha256="${manifest_sha256%% *}"
  {
    echo "taeh3_output_manifest=$report_path"
    echo "taeh3_output_manifest_sha256=$manifest_sha256"
    echo "taeh3_finalized_mp4=true"
  } >>"$case_dir/config.txt"
  {
    echo "taeh3_output_manifest=$report_path"
    echo "taeh3_output_manifest_sha256=$manifest_sha256"
    echo "taeh3_finalized_mp4=true"
  } >>"$RUN_ROOT/environment.txt"
}

profile_stage_max() {
  local request_log=$1
  local stage_name=$2
  awk -v key="MiniMaxH3Pipeline.${stage_name} took " '
    index($0, key) {
      value = substr($0, index($0, key) + length(key))
      sub(/s.*/, "", value)
      if (!found || value + 0 > maximum) maximum = value + 0
      found = 1
    }
    END { if (found) printf "%.6f", maximum; else printf "-" }
  ' "$request_log"
}

request_stat_seconds() {
  local request_log=$1
  local field_name=$2
  local divisor=${3:-1}
  awk -F'|' -v key="$field_name" -v divisor="$divisor" '
    function trim(value) {
      sub(/^[[:space:]]+/, "", value)
      sub(/[[:space:]]+$/, "", value)
      return value
    }
    {
      field = trim($2)
      if (field == key) {
        value = trim($3)
        gsub(/,/, "", value)
        if (value ~ /^[-+]?[0-9]+([.][0-9]+)?([eE][-+]?[0-9]+)?$/) {
          result = (value + 0) / divisor
          found = 1
        }
      }
    }
    END { if (found) printf "%.6f", result; else printf "-" }
  ' "$request_log"
}

mp4_encode_seconds() {
  local request_log=$1
  awk -v key="Video response encoding (MP4 bytes): " '
    index($0, key) {
      value = substr($0, index($0, key) + length(key))
      sub(/ ms.*/, "", value)
      if (value ~ /^[-+]?[0-9]+([.][0-9]+)?([eE][-+]?[0-9]+)?$/) {
        result = (value + 0) / 1000.0
        found = 1
      }
    }
    END { if (found) printf "%.6f", result; else printf "-" }
  ' "$request_log"
}

average_metric_files() {
  awk '
    $1 ~ /^[0-9]+([.][0-9]+)?$/ { sum += $1; count += 1 }
    END { if (count) printf "%.6f", sum / count; else printf "-" }
  ' "$@"
}

write_request_profile() {
  local label=$1
  local case_dir=$2
  local request_log=$3
  local encoder_s dit_s decode_total_s video_vae_raw_s video_vae_nvenc_s video_vae_chunked_s video_vae_path_s audio_vae_s
  local pipeline_forward_s engine_exec_s stage_gen_s
  local async_output_residual_wait_s postprocess_s stage_unattributed_residual_s
  local mp4_encode_s api_http_residual_s e2e_s

  encoder_s="$(profile_stage_max "$request_log" encode_prompt)"
  dit_s="$(profile_stage_max "$request_log" diffuse)"
  decode_total_s="$(profile_stage_max "$request_log" decode)"
  video_vae_raw_s="$(profile_stage_max "$request_log" video_vae.decode_latent)"
  video_vae_nvenc_s="$(profile_stage_max "$request_log" video_vae.decode_latent_to_nvenc)"
  video_vae_chunked_s="$(profile_stage_max "$request_log" video_vae.decode_latent_to_chunked_cpu_mp4)"
  if [[ "$video_vae_raw_s" != - ]]; then
    video_vae_path_s="$video_vae_raw_s"
  elif [[ "$video_vae_chunked_s" != - ]]; then
    video_vae_path_s="$video_vae_chunked_s"
  else
    video_vae_path_s="$video_vae_nvenc_s"
  fi
  audio_vae_s="$(profile_stage_max "$request_log" audio_vae.decode_latent)"
  pipeline_forward_s="$(profile_stage_max "$request_log" forward)"
  engine_exec_s="$(request_stat_seconds "$request_log" diffusion_engine_exec_time_s)"
  stage_gen_s="$(request_stat_seconds "$request_log" stage_gen_time_ms 1000)"
  async_output_residual_wait_s="$(request_stat_seconds \
    "$request_log" async_output_residual_wait_time_s)"
  postprocess_s="$(request_stat_seconds "$request_log" postprocess_time_s)"
  mp4_encode_s="$(mp4_encode_seconds "$request_log")"
  e2e_s="$(<"$case_dir/${label}-e2e-seconds.txt")"
  stage_unattributed_residual_s="$(awk \
    -v stage="$stage_gen_s" -v engine="$engine_exec_s" \
    -v output_wait="$async_output_residual_wait_s" -v post="$postprocess_s" '
      BEGIN {
        if (stage == "-" || engine == "-" || output_wait == "-" || post == "-") {
          printf "-"
          exit
        }
        residual = stage - engine - output_wait - post
        if (residual < 0) residual = 0
        printf "%.6f", residual
      }
    ')"
  api_http_residual_s="$(awk \
    -v e2e="$e2e_s" -v stage="$stage_gen_s" -v mp4="$mp4_encode_s" '
      BEGIN {
        if (e2e == "-" || stage == "-" || mp4 == "-") { printf "-"; exit }
        residual = e2e - stage - mp4
        if (residual < 0) residual = 0
        printf "%.6f", residual
      }
    ')"
  printf '%s\n' "$encoder_s" >"$case_dir/${label}-encoder-seconds.txt"
  printf '%s\n' "$dit_s" >"$case_dir/${label}-dit-seconds.txt"
  printf '%s\n' "$decode_total_s" >"$case_dir/${label}-decode-total-seconds.txt"
  printf '%s\n' "$video_vae_raw_s" >"$case_dir/${label}-video-vae-raw-seconds.txt"
  printf '%s\n' "$video_vae_nvenc_s" >"$case_dir/${label}-video-vae-nvenc-seconds.txt"
  printf '%s\n' "$video_vae_chunked_s" >"$case_dir/${label}-video-vae-chunked-seconds.txt"
  printf '%s\n' "$video_vae_path_s" >"$case_dir/${label}-video-vae-path-seconds.txt"
  printf '%s\n' "$audio_vae_s" >"$case_dir/${label}-audio-vae-seconds.txt"
  printf '%s\n' "$pipeline_forward_s" >"$case_dir/${label}-pipeline-forward-seconds.txt"
  printf '%s\n' "$engine_exec_s" >"$case_dir/${label}-engine-exec-seconds.txt"
  printf '%s\n' "$stage_gen_s" >"$case_dir/${label}-stage-gen-seconds.txt"
  printf '%s\n' "$async_output_residual_wait_s" \
    >"$case_dir/${label}-async-output-residual-wait-seconds.txt"
  printf '%s\n' "$postprocess_s" >"$case_dir/${label}-postprocess-seconds.txt"
  printf '%s\n' "$stage_unattributed_residual_s" \
    >"$case_dir/${label}-stage-unattributed-residual-seconds.txt"
  printf '%s\n' "$mp4_encode_s" >"$case_dir/${label}-mp4-encode-seconds.txt"
  printf '%s\n' "$api_http_residual_s" \
    >"$case_dir/${label}-api-http-residual-seconds.txt"
  grep 'MiniMax H3 NVENC output:' "$request_log" \
    >"$case_dir/${label}-nvenc-output.txt" || true
  grep 'MiniMax H3 output complete: route=finalized_chunk_gpu_u8_pinned_d2h_pyav_libx264' \
    "$request_log" >"$case_dir/${label}-chunked-cpu-mp4-output.txt" || true

  printf 'step\ttotal_steps\trank_observations\tmax_rank_seconds\n' \
    >"$case_dir/${label}-dit-step-times.tsv"
  awk '
    match($0, /\[MiniMaxH3StepProfiler\] step=[0-9]+\/[0-9]+ took [0-9.]+s/) {
      item = substr($0, RSTART, RLENGTH)
      sub(/^.*step=/, "", item)
      split(item, fields, /[\/ ]/)
      step = fields[1] + 0
      total = fields[2] + 0
      value = fields[4]
      sub(/s$/, "", value)
      if (!(step in maximum) || value + 0 > maximum[step]) maximum[step] = value + 0
      if (!(step in totals)) totals[step] = total
      else if (totals[step] != total) totals[step] = -1
      # tqdm may prefix a profiler record with an earlier worker label on the
      # same physical line (carriage-return progress output).  Attribute the
      # record to the last pid before the matched profiler marker, not the
      # first pid on the line.
      worker = ""
      prefix = substr($0, 1, RSTART - 1)
      while (match(prefix, /pid=[0-9]+/)) {
        worker = substr(prefix, RSTART, RLENGTH)
        prefix = substr(prefix, RSTART + RLENGTH)
      }
      observation_key = step SUBSEP worker
      if (worker != "" && !(observation_key in seen)) {
        seen[observation_key] = 1
        observations[step] += 1
      }
      if (step > max_step) max_step = step
    }
    END {
      for (step = 1; step <= max_step; step++)
        if (step in maximum)
          printf "%d\t%d\t%d\t%.6f\n", step, totals[step], observations[step], maximum[step]
    }
  ' "$request_log" >>"$case_dir/${label}-dit-step-times.tsv"

  if [[ "$label" == measured-* && "$ENABLE_DIFFUSION_PIPELINE_PROFILER" == 1 ]]; then
    [[ "$encoder_s" != - && "$dit_s" != - && "$decode_total_s" != - && \
      "$video_vae_path_s" != - && "$audio_vae_s" != - && \
      "$pipeline_forward_s" != - && "$engine_exec_s" != - && \
      "$stage_gen_s" != - && "$async_output_residual_wait_s" != - && \
      "$postprocess_s" != - && "$mp4_encode_s" != - ]] || \
      die "Missing measured stage timings in $request_log"
    awk -F'\t' -v expected_steps="$DENOISER_EVALUATIONS" -v expected_ranks="${#GPU_IDS[@]}" '
      NR == 1 { next }
      {
        rows += 1
        if ($1 + 0 != rows || $2 + 0 != expected_steps || $3 + 0 != expected_ranks) bad = 1
      }
      END { exit !(!bad && rows == expected_steps) }
    ' "$case_dir/${label}-dit-step-times.tsv" || die \
      "Measured DiT step log must contain all $DENOISER_EVALUATIONS steps from all ${#GPU_IDS[@]} ranks"
  elif [[ "$label" == measured-* ]]; then
    [[ "$engine_exec_s" != - && "$stage_gen_s" != - && \
      "$async_output_residual_wait_s" != - && "$postprocess_s" != - && \
      "$mp4_encode_s" != - ]] || \
      die "Missing measured request timings in $request_log"
    if grep -q '\[DiffusionPipelineProfiler\]\|\[MiniMaxH3StepProfiler\]' "$request_log"; then
      die "Diffusion profiler records leaked into profiler-disabled request $request_log"
    fi
  fi
}

request_video() {
  local label=$1
  local case_dir=$2
  local output_path=$3
  local server_log=$4
  local start_ns end_ns elapsed first_log_line last_log_line request_log
  local monitor_log=""

  first_log_line="$(( $(wc -l <"$server_log") + 1 ))"
  if [[ "$label" == measured-* ]]; then
    wait_for_exclusive_gpu_ownership "$case_dir" "$label"
    monitor_log="$case_dir/${label}-foreign-gpu-processes.log"
    start_foreign_gpu_monitor "$case_dir" "$label"
  fi
  start_ns="$(date +%s%N)"
  curl --fail-with-body --silent --show-error --max-time "$REQUEST_TIMEOUT" \
    -X POST "http://127.0.0.1:$PORT/v1/videos/sync" \
    --form-string "prompt=$PROMPT" \
    -F "width=$WIDTH" \
    -F "height=$HEIGHT" \
    -F 'fps=24' \
    -F "num_inference_steps=$STEPS" \
    -F 'flow_shift=12' \
    -F 'seed=1101' \
    -F 'aspect_ratio=16:9' \
    -F 'quality=lossless' \
    -F 'extra_params={"task":"t2va","duration":15,"audio_flow_shift":3.0}' \
    -o "$output_path"
  end_ns="$(date +%s%N)"
  if [[ "$label" == measured-* ]]; then
    stop_foreign_gpu_monitor
    if [[ -s "$monitor_log" ]]; then
      echo "Foreign GPU activity overlapped $label:" >&2
      cat "$monitor_log" >&2
      die "$label is contaminated and cannot be accepted as a formal sample"
    fi
  fi
  elapsed="$(awk -v start="$start_ns" -v end="$end_ns" 'BEGIN {printf "%.3f", (end-start)/1000000000}')"
  printf '%s\n' "$elapsed" >"$case_dir/${label}-e2e-seconds.txt"
  probe_media "$output_path" "$case_dir/${label}-media.txt" >/dev/null
  sleep 1
  last_log_line="$(wc -l <"$server_log")"
  request_log="$case_dir/${label}-server.log"
  sed -n "${first_log_line},${last_log_line}p" "$server_log" >"$request_log"
  write_request_profile "$label" "$case_dir" "$request_log"
  echo "$ACTIVE_CASE $label E2E: $elapsed s"
}

start_sampler() {
  local case_dir=$1
  (
    while kill -0 "$SERVER_PID" 2>/dev/null; do
      local_ts="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
      nvidia-smi --query-gpu=index,memory.used,utilization.gpu,power.draw \
        --format=csv,noheader,nounits 2>/dev/null | sed "s/^/$local_ts,/"
      sleep 1
    done
  ) >"$case_dir/gpu-samples.csv" &
  SAMPLER_PID=$!
  # Include wall-clock timestamps so request-only PCIe windows can be compared
  # without estimating dmon's sampling cadence from row counts.
  nvidia-smi dmon -s t -d 1 -c 3600 -o DT >"$case_dir/pcie-dmon.txt" 2>&1 &
  DMON_PID=$!
  echo "$DMON_PID" >"$case_dir/pcie-dmon.pid"
}

stop_sampler() {
  local case_dir=$1
  if [[ -n "$SAMPLER_PID" ]] && kill -0 "$SAMPLER_PID" 2>/dev/null; then
    kill -TERM "$SAMPLER_PID" 2>/dev/null || true
    wait "$SAMPLER_PID" 2>/dev/null || true
  fi
  SAMPLER_PID=""
  if [[ -n "$DMON_PID" ]] && kill -0 "$DMON_PID" 2>/dev/null; then
    kill -TERM "$DMON_PID" 2>/dev/null || true
    wait "$DMON_PID" 2>/dev/null || true
  fi
  DMON_PID=""
}

validate_taeh3_server_log() {
  local server_log=$1
  local case_dir=$2
  local expected_sp=$3
  local require_complete_request_set=$4
  local report_path="$case_dir/taeh3-runtime-validation.txt"

  if ! EXPECTED_LOCAL_ROWS="$QKV_E4M3_LOCAL_ROW_COUNT" "$PYTHON" - \
      "$server_log" \
      "$case_dir" \
      "$TAEH3_OUTPUT" \
      "$expected_sp" \
      "$require_complete_request_set" \
      "$WARMUPS" \
      "$REPEATS" \
      "$TAEH3_EXPECTED_REVISION" \
      "$TAEH3_EXPECTED_SHA256" \
      "$TAEH3_DTYPE" \
      "$TAEH3_AUDIO_DECODE_OVERLAP" \
      "$TAEH3_AUDIO_OVERLAP_MARKER" \
      "$ENABLE_DIFFUSION_PIPELINE_PROFILER" \
      "$TAEH3_CROSS_RANK_AUDIO_DECODE" \
      "$TAEH3_CROSS_RANK_AUDIO_MARKER" \
      "$TAEH3_CROSS_RANK_AUDIO_ENCODE" \
      "$TAEH3_CROSS_RANK_AUDIO_ENCODE_MARKER" >"$report_path" <<'TAEH3_LOG_VALIDATOR_PY'
import re
import sys
from pathlib import Path

if len(sys.argv) not in {11, 13, 14, 16, 18}:
    raise SystemExit(
        "TAEH3 validator expected 10 base arguments, optionally followed by "
        "the overlap contract, profiler state, cross-rank contract, and AAC contract"
    )

(
    server_log_raw,
    case_dir_raw,
    enabled_raw,
    expected_sp_raw,
    require_complete_raw,
    warmups_raw,
    repeats_raw,
    expected_revision,
    expected_sha256,
    expected_dtype,
) = sys.argv[1:11]

# Keep the standalone validator backward-compatible with its original TAEH3
# contract tests.  Production runner calls always provide both overlap fields
# and the explicit profiler state.
if len(sys.argv) >= 13:
    overlap_enabled_raw, overlap_marker = sys.argv[11:13]
else:
    overlap_enabled_raw = "0"
    overlap_marker = "MINIMAX_H3_TAEH3_AUDIO_DECODE_OVERLAP_ACTIVE_V1"
profiler_enabled_raw = sys.argv[13] if len(sys.argv) in {14, 16, 18} else "1"
if len(sys.argv) >= 16:
    profiler_enabled_raw = sys.argv[13]
    cross_rank_enabled_raw, cross_rank_marker = sys.argv[14:16]
else:
    cross_rank_enabled_raw = "0"
    cross_rank_marker = "MINIMAX_H3_TAEH3_CROSS_RANK_AUDIO_DECODE_ACTIVE_V1"
if len(sys.argv) == 18:
    cross_rank_encode_enabled_raw, cross_rank_encode_marker = sys.argv[16:18]
else:
    cross_rank_encode_enabled_raw = "0"
    cross_rank_encode_marker = "MINIMAX_H3_TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTIVE_V1"

enabled = int(enabled_raw)
expected_torch_dtype = {"fp32": "float32", "fp16": "float16"}.get(expected_dtype)
if enabled and expected_torch_dtype is None:
    raise SystemExit(f"unsupported expected TAEH3 dtype: {expected_dtype!r}")

server_log = Path(server_log_raw)
case_dir = Path(case_dir_raw)
expected_sp = int(expected_sp_raw)
require_complete = int(require_complete_raw)
expected_requests = int(warmups_raw) + int(repeats_raw)
overlap_enabled = int(overlap_enabled_raw)
profiler_enabled = int(profiler_enabled_raw)
cross_rank_enabled = int(cross_rank_enabled_raw)
cross_rank_encode_enabled = int(cross_rank_encode_enabled_raw)
if profiler_enabled not in {0, 1}:
    raise SystemExit(
        f"invalid diffusion pipeline profiler state: {profiler_enabled_raw!r}"
    )
if cross_rank_enabled not in {0, 1}:
    raise SystemExit(
        f"invalid TAEH3 cross-rank audio state: {cross_rank_enabled_raw!r}"
    )
if cross_rank_encode_enabled not in {0, 1}:
    raise SystemExit(
        f"invalid TAEH3 cross-rank AAC state: {cross_rank_encode_enabled_raw!r}"
    )
marker = "MINIMAX_H3_TAEH3 marker=v1 "
completion_prefix = "MiniMax H3 output complete: "
expected_route = "finalized_chunk_gpu_u8_pinned_d2h_pyav_libx264"
worker_re = re.compile(r"\(DiffusionWorker_SP([0-9]+) pid=[0-9]+\)")
errors: list[str] = []


def records(path: Path, prefix: str) -> list[tuple[str, dict[str, str]]]:
    result = []
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if prefix not in line:
            continue
        fields: dict[str, str] = {}
        for token in line.split(prefix, 1)[1].split():
            if "=" not in token:
                continue
            key, value = token.split("=", 1)
            fields[key] = value.rstrip(",")
        result.append((line, fields))
    return result


def check_exact_fields(
    context: str,
    record: dict[str, str],
    expected: dict[str, str],
) -> None:
    if record != expected:
        errors.append(f"{context}: fields={record!r}, expected={expected!r}")


all_markers = records(server_log, marker)
request_logs = sorted(case_dir.glob("warmup-*-server.log")) + sorted(
    case_dir.glob("measured-*-server.log")
)
loaded = [(line, fields) for line, fields in all_markers if fields.get("status") == "loaded"]
active = [(line, fields) for line, fields in all_markers if fields.get("status") == "active"]
decoded = [(line, fields) for line, fields in all_markers if fields.get("status") == "decoded"]
known_count = len(loaded) + len(active) + len(decoded)

print(f"required={enabled}")
print(f"expected_sp={expected_sp}")
print(f"require_complete_request_set={require_complete}")
print(f"expected_request_count={expected_requests}")
print(f"observed_request_log_count={len(request_logs)}")
print(f"loaded_marker_count={len(loaded)}")
print(f"active_marker_count={len(active)}")
print(f"decoded_marker_count={len(decoded)}")
overlap_lines = [
    line
    for line in server_log.read_text(encoding="utf-8", errors="replace").splitlines()
    if overlap_marker in line
]
overlap_ranks = []
for line in overlap_lines:
    worker = worker_re.search(line)
    if worker is None:
        errors.append("taeh3_audio_overlap_marker_missing_worker_rank")
    else:
        overlap_ranks.append(int(worker.group(1)))
print(f"taeh3_audio_overlap_required={overlap_enabled}")
print(f"diffusion_pipeline_profiler_required={profiler_enabled}")
print(f"taeh3_audio_overlap_marker_count={len(overlap_lines)}")
print(f"taeh3_audio_overlap_ranks={sorted(overlap_ranks)!r}")
if overlap_enabled:
    if sorted(overlap_ranks) != list(range(expected_sp)):
        errors.append(
            f"taeh3_audio_overlap_ranks={sorted(overlap_ranks)!r}, "
            f"expected={list(range(expected_sp))!r}"
        )
    if any("profiler_barrier=route_local_cuda_events" not in line for line in overlap_lines):
        errors.append("taeh3_audio_overlap_marker_missing_route_local_profiler_contract")
elif overlap_lines:
    errors.append(f"unrequested_taeh3_audio_overlap_marker_count={len(overlap_lines)}")

cross_rank_lines = [
    line
    for line in server_log.read_text(encoding="utf-8", errors="replace").splitlines()
    if cross_rank_marker in line
]
cross_rank_ranks = []
cross_rank_output_ranks = []
cross_rank_audio_ranks = []
for line in cross_rank_lines:
    worker = worker_re.search(line)
    if worker is None:
        errors.append("taeh3_cross_rank_audio_marker_missing_worker_rank")
        continue
    rank = int(worker.group(1))
    cross_rank_ranks.append(rank)
    fields = {}
    for token in line.split(cross_rank_marker, 1)[1].split():
        if "=" in token:
            key, value = token.split("=", 1)
            fields[key] = value.rstrip(",")
    if fields.get("output_rank") == "True":
        cross_rank_output_ranks.append(rank)
    elif fields.get("output_rank") != "False":
        errors.append(
            f"taeh3_cross_rank_audio_rank_{rank}_invalid_output_rank="
            f"{fields.get('output_rank')!r}"
        )
    if fields.get("audio_rank") == "True":
        cross_rank_audio_ranks.append(rank)
    elif fields.get("audio_rank") != "False":
        errors.append(
            f"taeh3_cross_rank_audio_rank_{rank}_invalid_audio_rank="
            f"{fields.get('audio_rank')!r}"
        )
    if fields.get("world_size") != str(expected_sp):
        errors.append(
            f"taeh3_cross_rank_audio_rank_{rank}_world_size="
            f"{fields.get('world_size')!r}, expected={expected_sp!r}"
        )
    if not fields.get("device", "").startswith("cuda:"):
        errors.append(
            f"taeh3_cross_rank_audio_rank_{rank}_device={fields.get('device')!r}"
        )

print(f"taeh3_cross_rank_audio_required={cross_rank_enabled}")
print(f"taeh3_cross_rank_audio_marker_count={len(cross_rank_lines)}")
print(f"taeh3_cross_rank_audio_ranks={sorted(cross_rank_ranks)!r}")
print(f"taeh3_cross_rank_audio_output_ranks={cross_rank_output_ranks!r}")
print(f"taeh3_cross_rank_audio_decode_ranks={cross_rank_audio_ranks!r}")
if cross_rank_enabled:
    if sorted(cross_rank_ranks) != list(range(expected_sp)):
        errors.append(
            f"taeh3_cross_rank_audio_ranks={sorted(cross_rank_ranks)!r}, "
            f"expected={list(range(expected_sp))!r}"
        )
    if cross_rank_output_ranks != [0]:
        errors.append(
            f"taeh3_cross_rank_audio_output_ranks={cross_rank_output_ranks!r}, "
            "expected=[0]"
        )
    if cross_rank_audio_ranks != [1]:
        errors.append(
            f"taeh3_cross_rank_audio_decode_ranks={cross_rank_audio_ranks!r}, "
            "expected=[1]"
        )
elif cross_rank_lines:
    errors.append(
        f"unrequested_taeh3_cross_rank_audio_marker_count={len(cross_rank_lines)}"
    )

cross_rank_encode_lines = [
    line
    for line in server_log.read_text(encoding="utf-8", errors="replace").splitlines()
    if cross_rank_encode_marker in line
]
cross_rank_encode_ranks = []
cross_rank_encode_output_ranks = []
cross_rank_encode_worker_ranks = []
for line in cross_rank_encode_lines:
    worker = worker_re.search(line)
    if worker is None:
        errors.append("taeh3_cross_rank_audio_encode_marker_missing_worker_rank")
        continue
    rank = int(worker.group(1))
    cross_rank_encode_ranks.append(rank)
    fields = {}
    for token in line.split(cross_rank_encode_marker, 1)[1].split():
        if "=" in token:
            key, value = token.split("=", 1)
            fields[key] = value.rstrip(",")
    if fields.get("output_rank") == "True":
        cross_rank_encode_output_ranks.append(rank)
    elif fields.get("output_rank") != "False":
        errors.append(
            f"taeh3_cross_rank_audio_encode_rank_{rank}_invalid_output_rank="
            f"{fields.get('output_rank')!r}"
        )
    if fields.get("encode_rank") == "True":
        cross_rank_encode_worker_ranks.append(rank)
    elif fields.get("encode_rank") != "False":
        errors.append(
            f"taeh3_cross_rank_audio_encode_rank_{rank}_invalid_encode_rank="
            f"{fields.get('encode_rank')!r}"
        )
    if fields.get("world_size") != str(expected_sp):
        errors.append(
            f"taeh3_cross_rank_audio_encode_rank_{rank}_world_size="
            f"{fields.get('world_size')!r}, expected={expected_sp!r}"
        )
    if not fields.get("device", "").startswith("cuda:"):
        errors.append(
            f"taeh3_cross_rank_audio_encode_rank_{rank}_device="
            f"{fields.get('device')!r}"
        )
    if fields.get("codec") != "aac":
        errors.append(
            f"taeh3_cross_rank_audio_encode_rank_{rank}_codec="
            f"{fields.get('codec')!r}, expected='aac'"
        )

print(f"taeh3_cross_rank_audio_encode_required={cross_rank_encode_enabled}")
print(f"taeh3_cross_rank_audio_encode_marker_count={len(cross_rank_encode_lines)}")
print(f"taeh3_cross_rank_audio_encode_ranks={sorted(cross_rank_encode_ranks)!r}")
print(f"taeh3_cross_rank_audio_encode_output_ranks={cross_rank_encode_output_ranks!r}")
print(f"taeh3_cross_rank_audio_encode_worker_ranks={cross_rank_encode_worker_ranks!r}")
if cross_rank_encode_enabled:
    if not cross_rank_enabled:
        errors.append("taeh3_cross_rank_audio_encode_requires_cross_rank_decode")
    if sorted(cross_rank_encode_ranks) != list(range(expected_sp)):
        errors.append(
            f"taeh3_cross_rank_audio_encode_ranks={sorted(cross_rank_encode_ranks)!r}, "
            f"expected={list(range(expected_sp))!r}"
        )
    if cross_rank_encode_output_ranks != [0]:
        errors.append(
            f"taeh3_cross_rank_audio_encode_output_ranks="
            f"{cross_rank_encode_output_ranks!r}, expected=[0]"
        )
    if cross_rank_encode_worker_ranks != [1]:
        errors.append(
            f"taeh3_cross_rank_audio_encode_worker_ranks="
            f"{cross_rank_encode_worker_ranks!r}, expected=[1]"
        )
elif cross_rank_encode_lines:
    errors.append(
        f"unrequested_taeh3_cross_rank_audio_encode_marker_count="
        f"{len(cross_rank_encode_lines)}"
    )

if not enabled:
    if all_markers:
        errors.append(f"unrequested_taeh3_marker_count={len(all_markers)}")
else:
    if known_count != len(all_markers):
        errors.append(f"unknown_status_marker_count={len(all_markers) - known_count}")
    if len(loaded) != 1:
        errors.append(f"loaded_marker_count={len(loaded)}, expected=1")
    else:
        line, fields = loaded[0]
        check_exact_fields(
            "loaded",
            fields,
            {
                "status": "loaded",
                "revision": expected_revision,
                "sha256": expected_sha256,
                "dtype": expected_torch_dtype,
                "chunk_size": "5",
                "device": "cuda:0",
                "quality": "lossy",
            },
        )
        worker = worker_re.search(line)
        if worker is None or worker.group(1) != "0":
            errors.append(f"loaded_worker_rank={None if worker is None else worker.group(1)!r}, expected='0'")

    active_ranks = []
    output_ranks = []
    for index, (line, fields) in enumerate(active):
        check_exact_fields(
            f"active[{index}]",
            fields,
            {
                "status": "active",
                "quality": "lossy",
                "full_video_vae_loaded": "false",
                "output_rank": fields.get("output_rank", ""),
                "dtype": expected_dtype,
                "chunk_size": "5",
            },
        )
        if fields.get("output_rank") not in {"True", "False"}:
            errors.append(f"active[{index}]: invalid_output_rank={fields.get('output_rank')!r}")
        worker = worker_re.search(line)
        if worker is None:
            errors.append(f"active[{index}]: missing_worker_rank")
            continue
        rank = int(worker.group(1))
        active_ranks.append(rank)
        if fields.get("output_rank") == "True":
            output_ranks.append(rank)
    if sorted(active_ranks) != list(range(expected_sp)):
        errors.append(f"active_ranks={sorted(active_ranks)!r}, expected={list(range(expected_sp))!r}")
    if output_ranks != [0]:
        errors.append(f"output_ranks={output_ranks!r}, expected=[0]")

    if require_complete and len(request_logs) != expected_requests:
        errors.append(f"request_log_count={len(request_logs)}, expected={expected_requests}")
    if len(decoded) != len(request_logs):
        errors.append(f"server_decoded_count={len(decoded)}, request_log_count={len(request_logs)}")

    for request_log in request_logs:
        request_markers = records(request_log, marker)
        request_text = request_log.read_text(encoding="utf-8", errors="replace")
        if overlap_enabled:
            expected_profile_count = profiler_enabled
            for profile_key in (
                "MiniMaxH3Pipeline.video_vae.decode_latent_to_chunked_cpu_mp4",
                "MiniMaxH3Pipeline.audio_vae.decode_latent",
            ):
                profile_prefix = f"[DiffusionPipelineProfiler] {profile_key} took "
                profile_count = request_text.count(profile_prefix)
                if profile_count != expected_profile_count:
                    errors.append(
                        f"{request_log.name}: {profile_key} profile_count={profile_count}, "
                        f"expected={expected_profile_count}"
                    )
        request_decoded = [
            (line, fields)
            for line, fields in request_markers
            if fields.get("status") == "decoded"
        ]
        request_completions = records(request_log, completion_prefix)
        if len(request_decoded) != 1:
            errors.append(f"{request_log.name}: decoded_count={len(request_decoded)}, expected=1")
        else:
            line, fields = request_decoded[0]
            check_exact_fields(
                f"{request_log.name}:decoded",
                fields,
                {
                    "status": "decoded",
                    "chunks": "22",
                    "frames": "362",
                    "height": "704",
                    "width": "1280",
                    "dtype": expected_torch_dtype,
                },
            )
            worker = worker_re.search(line)
            if worker is None or worker.group(1) != "0":
                errors.append(
                    f"{request_log.name}: decoded_worker_rank="
                    f"{None if worker is None else worker.group(1)!r}, expected='0'"
                )
        matching_completions = []
        for line, fields in request_completions:
            if fields.get("route") == expected_route:
                matching_completions.append((line, fields))
        if len(matching_completions) != 1:
            errors.append(
                f"{request_log.name}: completion_count={len(matching_completions)}, expected=1"
            )
        else:
            _, fields = matching_completions[0]
            if fields.get("frames") != "362" or fields.get("slots") != "2":
                errors.append(
                    f"{request_log.name}: completion frames={fields.get('frames')!r} "
                    f"slots={fields.get('slots')!r}, expected 362/2"
                )
            raw_mp4 = fields.get("mp4", "")
            try:
                mp4_mib = float(raw_mp4.removesuffix("MiB"))
            except ValueError:
                mp4_mib = 0.0
            if mp4_mib <= 0.0:
                errors.append(f"{request_log.name}: invalid_mp4_size={raw_mp4!r}")
            if cross_rank_encode_enabled:
                if fields.get("audio_preencoded") != "True":
                    errors.append(
                        f"{request_log.name}: audio_preencoded="
                        f"{fields.get('audio_preencoded')!r}, expected='True'"
                    )
                raw_audio_packets = fields.get("audio_packets", "")
                try:
                    audio_packet_kib = float(raw_audio_packets.removesuffix("KiB"))
                except ValueError:
                    audio_packet_kib = 0.0
                if audio_packet_kib <= 0.0:
                    errors.append(
                        f"{request_log.name}: invalid_audio_packet_size="
                        f"{raw_audio_packets!r}"
                    )
            elif fields.get("audio_preencoded") not in {None, "False"}:
                errors.append(
                    f"{request_log.name}: unrequested_audio_preencoded="
                    f"{fields.get('audio_preencoded')!r}"
                )

if errors:
    print("validation_status=failed")
    for error in errors:
        print(f"error={error}")
    raise SystemExit(1)
print("validation_status=ok")
TAEH3_LOG_VALIDATOR_PY
  then
    echo "MiniMax H3 TAEH3 all-rank/request validation failed; see $report_path" >&2
    return 1
  fi
}

validate_qkv_single_phase_server_log() {
  local server_log=$1
  local case_dir=$2
  local expected_sp=$3
  local require_complete_request_set=$4
  local report_path="$case_dir/qkv-single-phase-runtime-validation.txt"

  if ! "$PYTHON" - \
      "$server_log" \
      "$case_dir" \
      "$QKV_SINGLE_PHASE" \
      "$expected_sp" \
      "$require_complete_request_set" \
      "$WARMUPS" \
      "$REPEATS" \
      "$QKV_SINGLE_PHASE_EXPECTED_CALLS_PER_WORKER_PER_REQUEST" \
      "$PERSISTENT_RDMA" \
      >"$report_path" <<'QKV_SINGLE_PHASE_LOG_VALIDATOR_PY'
from collections import Counter
import os
import re
import sys
from pathlib import Path

(
    server_log_raw,
    case_dir_raw,
    enabled_raw,
    expected_sp_raw,
    require_complete_raw,
    warmups_raw,
    repeats_raw,
    expected_calls_raw,
    persistent_rdma_raw,
) = sys.argv[1:]

server_log = Path(server_log_raw)
case_dir = Path(case_dir_raw)
enabled = int(enabled_raw)
expected_sp = int(expected_sp_raw)
require_complete = int(require_complete_raw)
expected_requests = int(warmups_raw) + int(repeats_raw)
expected_calls = int(expected_calls_raw)
persistent_rdma = int(persistent_rdma_raw)
expected_local_rows = int(os.environ.get("EXPECTED_LOCAL_ROWS", "11936"))
marker = "FlashInfer PCIe Ulysses standard-layout Q/K/V single phase active:"
worker_re = re.compile(r"DiffusionWorker_SP([0-9]+)\s+pid=[0-9]+")
detail_re = re.compile(
    r"rank=([0-9]+) group=([^\s]+) "
    rf"shape=\(1, {expected_local_rows}, 56, 128\) "
    r"dtype=torch\.float8_e4m3fn "
    r"protocol_phases=1 writes_per_remote_peer=3 recv_depth=3 "
    r"producer_direct=\(True, True, True\) transport=rdma"
)
errors: list[str] = []


def records(path: Path) -> tuple[list[tuple[int, str]], list[int]]:
    parsed: list[tuple[int, str]] = []
    malformed: list[int] = []
    for line_number, line in enumerate(
        path.read_text(encoding="utf-8", errors="replace").splitlines(), 1
    ):
        marker_offset = line.find(marker)
        if marker_offset < 0:
            continue
        worker_matches = worker_re.findall(line[:marker_offset])
        detail = detail_re.fullmatch(line[marker_offset + len(marker) :].strip())
        if not worker_matches or detail is None:
            malformed.append(line_number)
            continue
        worker_rank = int(worker_matches[-1])
        marker_rank = int(detail.group(1))
        if worker_rank != marker_rank:
            malformed.append(line_number)
            continue
        parsed.append((marker_rank, detail.group(2)))
    return parsed, malformed


server_records, server_malformed = records(server_log)
request_logs = sorted(case_dir.glob("warmup-*-server.log")) + sorted(
    case_dir.glob("measured-*-server.log")
)
request_records: list[tuple[int, str]] = []
expected_ranks = list(range(expected_sp))

print(f"required={enabled}")
print(f"expected_sp={expected_sp}")
print(f"require_complete_request_set={require_complete}")
print(f"expected_request_count={expected_requests}")
print(f"observed_request_log_count={len(request_logs)}")
print(f"server_activation_marker_count={len(server_records)}")
print(
    "marker_contract="
    + (
        "one_per_worker_per_process"
        if persistent_rdma
        else "one_per_worker_per_request"
    )
)
print(f"expected_calls_per_worker_per_request={expected_calls}")
print("runtime_call_count_evidence=not_exposed_activation_marker_only")

if not enabled:
    if server_records or server_malformed:
        errors.append(
            "unrequested_single_phase_marker_count="
            f"{len(server_records) + len(server_malformed)}"
        )
else:
    if server_malformed:
        errors.append(f"malformed_server_marker_lines={server_malformed!r}")
    if require_complete and len(request_logs) != expected_requests:
        errors.append(
            f"request_log_count={len(request_logs)}, expected={expected_requests}"
        )

    for request_log in request_logs:
        current, malformed = records(request_log)
        request_records.extend(current)
        ranks = [rank for rank, _group in current]
        groups = {group for _rank, group in current}
        print(
            f"{request_log.name}_activation_marker_count={len(current)};"
            f"ranks={','.join(str(rank) for rank in sorted(ranks))}"
        )
        if malformed:
            errors.append(f"{request_log.name}: malformed_marker_lines={malformed!r}")
        if persistent_rdma:
            rank_counts = Counter(ranks)
            if any(rank not in expected_ranks for rank in ranks) or any(
                count != 1 for count in rank_counts.values()
            ):
                errors.append(
                    f"{request_log.name}: persistent marker ranks must be unique workers; "
                    f"ranks={sorted(ranks)!r}, expected_subset={expected_ranks!r}"
                )
        elif len(current) != expected_sp or sorted(ranks) != expected_ranks:
            errors.append(
                f"{request_log.name}: expected exactly one activation marker per worker; "
                f"ranks={sorted(ranks)!r}, expected={expected_ranks!r}"
            )
        if len(groups) > 1 or (not persistent_rdma and len(groups) != 1):
            errors.append(
                f"{request_log.name}: activation markers do not share one group: "
                f"{sorted(groups)!r}"
            )

    if Counter(server_records) != Counter(request_records):
        errors.append(
            "server/request activation markers differ: "
            f"server={dict(Counter(server_records))!r}, "
            f"requests={dict(Counter(request_records))!r}"
        )
    server_counts = Counter(rank for rank, _group in server_records)
    expected_per_rank = 1 if persistent_rdma else len(request_logs)
    if server_counts != Counter({rank: expected_per_rank for rank in expected_ranks}):
        errors.append(
            "server activation marker counts violate the selected lifecycle: "
            f"counts={dict(server_counts)!r}, expected_per_rank={expected_per_rank}"
        )
    server_groups = {group for _rank, group in server_records}
    if server_records and len(server_groups) != 1:
        errors.append(
            f"server activation markers do not share one group: {sorted(server_groups)!r}"
        )

if errors:
    print("validation_status=failed")
    for error in errors:
        print(f"error={error}")
    raise SystemExit(1)
print("validation_status=ok")
QKV_SINGLE_PHASE_LOG_VALIDATOR_PY
  then
    echo "FlashInfer QKV single-phase lifecycle validation failed; see $report_path" >&2
    return 1
  fi
}

validate_server_log() {
  local server_log=$1
  local case_dir=$2
  local require_flashinfer_rdma=$3
  local require_qk_direct=${4:-0}
  local require_release_after_denoise=${5:-0}
  local require_o_direct=${6:-0}
  local require_complete_request_set=${7:-0}
  local expected_sp=${8:-8}
  local require_qkv_e4m3=${9:-0}
  local fatal_matches="$case_dir/fatal-server-log-matches.txt"
  local rdma_validation="$case_dir/flashinfer-rdma-validation.txt"

  if grep -Ein \
      'CUDA out of memory|torch\.OutOfMemoryError|Traceback \(most recent call last\)|Worker.*(exception|failed)' \
      "$server_log" >"$fatal_matches"; then
    echo "Fatal worker evidence found in $server_log:" >&2
    cat "$fatal_matches" >&2
    return 1
  fi
  rm -f -- "$fatal_matches"

  if ! validate_taeh3_server_log \
      "$server_log" "$case_dir" "$expected_sp" "$require_complete_request_set"; then
    return 1
  fi
  if ! validate_qkv_single_phase_server_log \
      "$server_log" "$case_dir" "$expected_sp" "$require_complete_request_set"; then
    return 1
  fi

  local vae_exact_validation="$case_dir/vae-exact-ops-sm120-validation.txt"
  if ! "$PYTHON" - \
      "$server_log" \
      "$case_dir" \
      "$VAE_EXACT_OPS_SM120" \
      "$expected_sp" \
      "$require_complete_request_set" \
      "$WARMUPS" \
      "$REPEATS" \
      "$VAE_TEMPORAL_PRE_GATHER_PRUNE" \
      "$VAE_TEMPORAL_CHUNK_PARALLEL" \
      "$VAE_DECODER_TILE_SIZE" >"$vae_exact_validation" <<'PY'
import sys
from pathlib import Path

(
    server_log_raw,
    case_dir_raw,
    enabled_raw,
    expected_sp_raw,
    require_complete_raw,
    warmups_raw,
    repeats_raw,
    temporal_prune_raw,
    temporal_parallel_raw,
    decoder_tile_size_raw,
) = sys.argv[1:]

server_log = Path(server_log_raw)
case_dir = Path(case_dir_raw)
enabled = int(enabled_raw)
expected_sp = int(expected_sp_raw)
require_complete = int(require_complete_raw)
expected_requests = int(warmups_raw) + int(repeats_raw)
temporal_prune = int(temporal_prune_raw)
temporal_parallel = int(temporal_parallel_raw)
decoder_tile_size = int(decoder_tile_size_raw)

install_prefix = "MiniMax H3 VAE exact operators installed: "
complete_prefix = "MiniMax H3 VAE exact operators complete: "
quality_contract = (
    "bitwise_micro_validated_all_rank_dispatch_counters_"
    "full_sp8_raw_equivalence_pending"
    if enabled
    else "disabled"
)
errors: list[str] = []


def records(path: Path, prefix: str) -> list[dict[str, str]]:
    parsed = []
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if prefix not in line:
            continue
        payload = line.split(prefix, 1)[1]
        parsed.append(
            {
                key: value.rstrip(",")
                for token in payload.split()
                if "=" in token
                for key, value in [token.split("=", 1)]
            }
        )
    return parsed


def integer(record: dict[str, str], name: str, context: str) -> int:
    try:
        return int(record[name])
    except (KeyError, ValueError):
        errors.append(f"{context}: invalid_or_missing_{name}={record.get(name)!r}")
        return -1


installs = records(server_log, install_prefix)
request_logs = sorted(case_dir.glob("warmup-*-server.log")) + sorted(
    case_dir.glob("measured-*-server.log")
)
completion_count = sum(len(records(path, complete_prefix)) for path in request_logs)

print(f"required={enabled}")
print(f"expected_sp={expected_sp}")
print(f"install_marker_count={len(installs)}")
print(f"request_log_count={len(request_logs)}")
print(f"completion_marker_count={completion_count}")
print(f"quality_contract={quality_contract}")

if not enabled:
    if installs or completion_count:
        errors.append("unrequested_exact_ops")
else:
    install_ranks = []
    for index, record in enumerate(installs):
        context = f"install[{index}]"
        rank = integer(record, "rank", context)
        device = record.get("device", "")
        blocks = integer(record, "blocks", context)
        install_ranks.append(rank)
        if device != f"cuda:{rank}":
            errors.append(f"{context}: device={device!r}, expected='cuda:{rank}'")
        if blocks != 36:
            errors.append(f"{context}: blocks={blocks}, expected=36")
        if record.get("linear_dtype") != "float16":
            errors.append(f"{context}: linear_dtype={record.get('linear_dtype')!r}")
        if record.get("counters") != "enabled":
            errors.append(f"{context}: counters={record.get('counters')!r}")
    if sorted(install_ranks) != list(range(expected_sp)):
        errors.append(
            f"install_ranks={sorted(install_ranks)}, expected={list(range(expected_sp))}"
        )

    if require_complete and len(request_logs) != expected_requests:
        errors.append(
            f"request_log_count={len(request_logs)}, expected={expected_requests}"
        )

    expected_route = (
        "temporal_window_pp"
        if temporal_parallel
        else "spatial_pp_pruned" if temporal_prune else "spatial_pp_chunked"
    )
    for request_log in request_logs:
        request_records = records(request_log, complete_prefix)
        ranks = []
        for index, record in enumerate(request_records):
            context = f"{request_log.name}[{index}]"
            rank = integer(record, "rank", context)
            sp_rank = integer(record, "sp_rank", context)
            ranks.append(rank)
            latent_tokens = integer(record, "latent_tokens", context)
            temporal_windows = integer(record, "temporal_windows", context)
            tiles = integer(record, "tiles", context)
            local_tiles = integer(record, "local_tiles", context)
            owned_windows = integer(record, "owned_windows", context)
            blocks = integer(record, "blocks", context)
            expected_block_calls = integer(record, "expected_block_calls", context)
            if record.get("route") != expected_route:
                errors.append(
                    f"{context}: route={record.get('route')!r}, expected={expected_route!r}"
                )
            if rank != sp_rank:
                errors.append(f"{context}: rank={rank}, sp_rank={sp_rank}")
            if latent_tokens != 107 or temporal_windows != 21:
                errors.append(
                    f"{context}: geometry={latent_tokens}t/{temporal_windows}w, expected=107t/21w"
                )
            if decoder_tile_size == 0 and tiles != 28:
                errors.append(f"{context}: tiles={tiles}, expected=28")
            if blocks != 36:
                errors.append(f"{context}: blocks={blocks}, expected=36")

            if expected_route == "temporal_window_pp":
                calculated_owned_windows = len(range(rank, temporal_windows, expected_sp))
                calculated_local_tiles = tiles
            else:
                calculated_owned_windows = temporal_windows
                calculated_local_tiles = (
                    len(range(rank, tiles, expected_sp)) if tiles >= expected_sp else tiles
                )
            calculated_calls = calculated_owned_windows * calculated_local_tiles * blocks
            if owned_windows != calculated_owned_windows:
                errors.append(
                    f"{context}: owned_windows={owned_windows}, expected={calculated_owned_windows}"
                )
            if local_tiles != calculated_local_tiles:
                errors.append(
                    f"{context}: local_tiles={local_tiles}, expected={calculated_local_tiles}"
                )
            if expected_block_calls != calculated_calls:
                errors.append(
                    f"{context}: expected_block_calls={expected_block_calls}, calculated={calculated_calls}"
                )

            expected_counters = {
                "transformer_fast": calculated_calls,
                "transformer_fallback": 0,
                "qk_norm_rope_fast": calculated_calls,
                "qk_norm_rope_fallback": 0,
                "swiglu_fast": calculated_calls,
                "swiglu_fallback": 0,
                "scaled_residual_fast": 2 * calculated_calls,
                "scaled_residual_fallback": 0,
            }
            for name, expected in expected_counters.items():
                observed = integer(record, name, context)
                if observed != expected:
                    errors.append(f"{context}: {name}={observed}, expected={expected}")
            if record.get("status") != "ok":
                errors.append(f"{context}: status={record.get('status')!r}")

        if sorted(ranks) != list(range(expected_sp)):
            errors.append(
                f"{request_log.name}: ranks={sorted(ranks)}, expected={list(range(expected_sp))}"
            )

if errors:
    print("validation_status=failed")
    for error in errors:
        print(f"error={error}")
    raise SystemExit(1)
print("validation_status=ok")
PY
  then
    echo "SM120 VAE exact-op all-rank dispatch/counter validation failed; see $vae_exact_validation" >&2
    return 1
  fi

  local mlp_fp8_validation="$case_dir/mlp-fp8-runtime-validation.txt"
  if ! "$PYTHON" - \
      "$server_log" \
      "$SELECTIVE_FP8_CONTRACT" \
      "$FP8_SCOPE" \
      "$expected_sp" \
      "$MLP_FP8_CONFIG_SHA256" \
      "$MLP_FP8_CONTRACT_SHA256" >"$mlp_fp8_validation" <<'PY'
import re
import sys
from pathlib import Path

(
    server_log_raw,
    required_raw,
    scope,
    expected_sp_raw,
    config_sha256,
    contract_sha256,
) = sys.argv[1:]
required = int(required_raw)
expected_sp = int(expected_sp_raw)
profiles = {
    "mlp": {
        "marker": "MINIMAX_H3_MLP_FP8_AUDIT_V1",
        "dit_quant_mode": (
            "mlp-fp8-e4m3fn-w-per-tensor-a-per-token-cutlass-sm120-v1"
        ),
        "target_modules": "100",
        "fc1": "50",
        "fc2": "50",
    },
    "mlp-out": {
        "marker": "MINIMAX_H3_MLP_OUT_FP8_AUDIT_V1",
        "dit_quant_mode": (
            "mlp-out-fp8-e4m3fn-w-per-tensor-a-per-token-cutlass-sm120-v1"
        ),
        "target_modules": "150",
        "fc1": "50",
        "fc2": "50",
        "out_proj": "50",
        "qkv_proj_bf16": "50",
        "to_gate_compress_bf16": "50",
        "sequence_parallel_size": "8",
        "ulysses_degree": "8",
        "ring_degree": "1",
        "allgather_degree": "1",
    },
    "mlp-out-qkv": {
        "marker": "MINIMAX_H3_MLP_OUT_QKV_FP8_AUDIT_V1",
        "dit_quant_mode": (
            "mlp-out-qkv-fp8-e4m3fn-w-per-tensor-a-per-token-cutlass-sm120-v1"
        ),
        "target_modules": "200",
        "fc1": "50",
        "fc2": "50",
        "out_proj": "50",
        "qkv_proj": "50",
        "qkv_proj_output_dtype": "bfloat16",
        "to_gate_compress_bf16": "50",
        "sequence_parallel_size": "8",
        "ulysses_degree": "8",
        "ring_degree": "1",
        "allgather_degree": "1",
    },
    "all-main": {
        "marker": "MINIMAX_H3_ALL_MAIN_FP8_AUDIT_V1",
        "dit_quant_mode": (
            "all-main-fp8-e4m3fn-w-per-tensor-a-per-token-cutlass-sm120-v1"
        ),
        "target_modules": "250",
        "fc1": "50",
        "fc2": "50",
        "out_proj": "50",
        "qkv_proj": "50",
        "qkv_proj_output_dtype": "bfloat16",
        "to_gate_compress": "50",
        "to_gate_compress_output_dtype": "bfloat16",
        "sequence_parallel_size": "8",
        "ulysses_degree": "8",
        "ring_degree": "1",
        "allgather_degree": "1",
    },
}
all_markers = tuple(profile["marker"] for profile in profiles.values())
marker = profiles.get(scope, {}).get("marker", "")
lines = [
    line
    for line in Path(server_log_raw)
    .read_text(encoding="utf-8", errors="replace")
    .splitlines()
    if any(candidate in line for candidate in all_markers)
]
print(f"required={required}")
print(f"marker_count={len(lines)}")
errors: list[str] = []
if not required:
    if lines:
        errors.append("unrequested_selective_fp8_audit_marker")
else:
    if scope not in profiles:
        errors.append(f"unsupported_formal_fp8_scope={scope!r}")
        profile = profiles["mlp"]
    else:
        profile = profiles[scope]
    wrong_markers = [line for line in lines if profile["marker"] not in line]
    if wrong_markers:
        errors.append(f"wrong_scope_audit_markers={len(wrong_markers)}")
    expected = {
        "world_size": str(expected_sp),
        "scope": scope,
        **{name: value for name, value in profile.items() if name != "marker"},
        "quant_method": "Fp8PerTensorOnlineLinearMethod",
        "linear_kernel": "CutlassFP8ScaledMMLinearKernel",
        "weight_dtype": "float8_e4m3fn",
        "weight_quant": "static_per_tensor_symmetric",
        "activation_quant": "dynamic_per_token_symmetric",
        "input_dtype": "bfloat16",
        "output_dtype": "bfloat16",
        "source_weight_dtype": "bfloat16",
        "weight_scale_dtype": "float32",
        "tp_size": "1",
        "gpu_architecture": "sm120",
        "unexpected_fp8_modules": "0",
        "fallback_count": "0",
        "config_sha256": config_sha256,
        "contract_sha256": contract_sha256,
        "status": "ok",
    }
    expected_keys = {"rank", *expected}
    ranks = []
    for index, line in enumerate(lines):
        context = f"marker[{index}]"
        suffix = line.split(profile["marker"], 1)[1].strip()
        fields: dict[str, str] = {}
        for token in suffix.split():
            if "=" not in token:
                errors.append(f"{context}: malformed_token={token!r}")
                continue
            key, value = token.split("=", 1)
            if key in fields:
                errors.append(f"{context}: duplicate_field={key!r}")
            fields[key] = value.rstrip(",")
        if set(fields) != expected_keys:
            errors.append(
                f"{context}: fields={sorted(fields)!r}, expected={sorted(expected_keys)!r}"
            )
        try:
            rank = int(fields.get("rank", ""))
        except ValueError:
            rank = -1
        ranks.append(rank)
        worker = re.search(r"\(DiffusionWorker_SP(\d+) pid=\d+\)", line)
        if worker is None or int(worker.group(1)) != rank:
            errors.append(
                f"{context}: worker_rank={None if worker is None else worker.group(1)!r}, rank={rank}"
            )
        for name, value in expected.items():
            if fields.get(name) != value:
                errors.append(
                    f"{context}: {name}={fields.get(name)!r}, expected={value!r}"
                )
    if sorted(ranks) != list(range(expected_sp)):
        errors.append(
            f"marker_ranks={sorted(ranks)!r}, expected={list(range(expected_sp))!r}"
        )

if errors:
    print("validation_status=failed")
    for error in errors:
        print(f"error={error}")
    raise SystemExit(1)
print("validation_status=ok")
PY
  then
    echo "MiniMax H3 selective-FP8 all-rank runtime validation failed; see $mlp_fp8_validation" >&2
    return 1
  fi

  if [[ "$FASTH3_VSA_MODE" == 1 ]]; then
    local vsa_validation="$case_dir/vsa-validation.txt"
    local routing_pattern="FASTVIDEO_VSA H3 routing:.*topk=${FASTH3_VSA_TOPK}.*compute_backend=${FASTH3_VSA_PROVIDER}"
    {
      echo "required_framework=vllm-omni"
      echo "required_provider=$FASTH3_VSA_PROVIDER"
      echo "required_topk=$FASTH3_VSA_TOPK"
      echo "required_a2a_backend=$([[ "$require_flashinfer_rdma" == 1 ]] && echo flashinfer-pcie-${FLASHINFER_ULYSSES_ROUTE} || echo nccl)"
      grep -E "$routing_pattern" "$server_log" || true
    } >"$vsa_validation"
    if grep -Eq 'FASTVIDEO_VSA falling back to SDPA|VSA-H3 kernel failed' "$server_log"; then
      echo "validation_status=failed_fallback" >>"$vsa_validation"
      echo "FastH3 VSA fell back or failed; see $vsa_validation" >&2
      return 1
    fi
    if ! grep -Eq "$routing_pattern" "$server_log"; then
      echo "validation_status=failed_missing_route" >>"$vsa_validation"
      echo "FastH3 VSA provider/top-k ownership marker is missing; see $vsa_validation" >&2
      return 1
    fi
    local expected_vsa_kernel=vsa_sm120_blk64_cute_dsl
    if [[ "${VLLM_OMNI_H3_VSA_SAGE:-bf16}" == pr4691 || "${VLLM_OMNI_H3_VSA_SAGE:-bf16}" == pr4951 ]]; then
      expected_vsa_kernel="vsa_sm120_blk64_sage_${VLLM_OMNI_H3_VSA_SAGE}"
      if grep -q 'FASTVIDEO_VSA H3 compute kernel: FlashInfer vsa_sm120_blk64_cute_dsl' "$server_log"; then
        echo "validation_status=failed_unrequested_bf16_fine_kernel" >>"$vsa_validation"
        return 1
      fi
    fi
    echo "required_fine_attention_kernel=$expected_vsa_kernel" >>"$vsa_validation"
    if [[ "$FASTH3_VSA_PROVIDER" == flashinfer ]] && \
      ! grep -q "FASTVIDEO_VSA H3 compute kernel: FlashInfer $expected_vsa_kernel" "$server_log"; then
      echo "validation_status=failed_missing_flashinfer_sm120_kernel" >>"$vsa_validation"
      echo "FlashInfer SM120 CuTeDSL ownership marker is missing; see $vsa_validation" >&2
      return 1
    fi
    local gate_overlap_marker='MINIMAX_H3_VSA_GATE_COMPUTE_OVERLAP_ACTIVE_V1'
    local gate_overlap_marker_count
    gate_overlap_marker_count="$(grep -Fc "$gate_overlap_marker" "$server_log" || true)"
    echo "vsa_gate_compute_overlap_required=$VSA_GATE_COMPUTE_OVERLAP" >>"$vsa_validation"
    echo "vsa_gate_compute_overlap_marker_count=$gate_overlap_marker_count" >>"$vsa_validation"
    if [[ "$VSA_GATE_COMPUTE_OVERLAP" == 1 ]]; then
      if [[ "$gate_overlap_marker_count" != "$expected_sp" ]]; then
        echo "validation_status=failed_gate_compute_overlap_marker_count_${gate_overlap_marker_count}" \
          >>"$vsa_validation"
        echo "H3 VSA gate-compute overlap must emit one stable activation marker per worker; see $vsa_validation" >&2
        return 1
      fi
      local gate_overlap_worker_rank gate_overlap_worker_count
      for ((gate_overlap_worker_rank=0; gate_overlap_worker_rank<expected_sp; gate_overlap_worker_rank++)); do
        gate_overlap_worker_count="$({ grep -F "$gate_overlap_marker" "$server_log" || true; } | \
          grep -Ec "\\(DiffusionWorker_SP${gate_overlap_worker_rank} pid=[0-9]+\\)" || true)"
        echo "vsa_gate_compute_overlap_worker_marker_count=rank=${gate_overlap_worker_rank},count=${gate_overlap_worker_count}" \
          >>"$vsa_validation"
        if [[ "$gate_overlap_worker_count" != 1 ]]; then
          echo "validation_status=failed_gate_compute_overlap_worker_${gate_overlap_worker_rank}_marker_count_${gate_overlap_worker_count}" \
            >>"$vsa_validation"
          echo "Each H3 VSA gate-compute-overlap worker must emit exactly one activation marker; see $vsa_validation" >&2
          return 1
        fi
      done
    elif [[ "$gate_overlap_marker_count" != 0 ]]; then
      echo "validation_status=failed_unrequested_gate_compute_overlap" >>"$vsa_validation"
      echo "H3 VSA gate-compute overlap ran while disabled; see $vsa_validation" >&2
      return 1
    fi
    local deferred_producer_marker='FASTVIDEO_VSA H3 deferred gate producer active:'
    local deferred_consumer_marker='MiniMax H3 VSA deferred-gate SP active:'
    local deferred_fallback_pattern='deferred (MiniMax-H3|H3 VSA).*(unsupported|requires|absent|stale|unexpected|must|failed|fallback|fell back)|incomplete deferred H3 VSA|unexpected deferred H3 VSA|H3 VSA backend did not (acknowledge deferred gate ownership|publish compact)|H3 VSA deferred state identity changed'
    local deferred_producer_count deferred_consumer_count deferred_fallback_count
    local expected_deferred_count
    deferred_producer_count="$(grep -Fc "$deferred_producer_marker" "$server_log" || true)"
    deferred_consumer_count="$(grep -Fc "$deferred_consumer_marker" "$server_log" || true)"
    deferred_fallback_count="$(grep -Eic "$deferred_fallback_pattern" "$server_log" || true)"
    expected_deferred_count="$expected_sp"
    echo "deferred_gate_required=$VSA_DEFERRED_GATE_SP" >>"$vsa_validation"
    echo "deferred_gate_producer_marker_count=$deferred_producer_count" >>"$vsa_validation"
    echo "deferred_gate_consumer_marker_count=$deferred_consumer_count" >>"$vsa_validation"
    echo "deferred_gate_fallback_marker_count=$deferred_fallback_count" >>"$vsa_validation"
    if [[ "$VSA_DEFERRED_GATE_SP" == 1 ]]; then
      if [[ "$deferred_producer_count" != "$expected_deferred_count" || \
            "$deferred_consumer_count" != "$expected_deferred_count" || \
            "$deferred_fallback_count" != 0 ]]; then
        echo "validation_status=failed_deferred_gate_route" >>"$vsa_validation"
        echo "Deferred H3 VSA producer/consumer ownership or fallback evidence is invalid; see $vsa_validation" >&2
        return 1
      fi
      local deferred_worker_rank producer_worker_count consumer_worker_count
      for ((deferred_worker_rank=0; deferred_worker_rank<expected_sp; deferred_worker_rank++)); do
        producer_worker_count="$({ grep -F "$deferred_producer_marker" "$server_log" || true; } | \
          grep -Ec "\\(DiffusionWorker_SP${deferred_worker_rank} pid=[0-9]+\\)" || true)"
        consumer_worker_count="$({ grep -F "$deferred_consumer_marker" "$server_log" || true; } | \
          grep -E "\\(DiffusionWorker_SP${deferred_worker_rank} pid=[0-9]+\\)" | \
          grep -Fc "rank=${deferred_worker_rank} " || true)"
        echo "deferred_gate_producer_worker_marker_count=rank=${deferred_worker_rank},count=${producer_worker_count}" \
          >>"$vsa_validation"
        echo "deferred_gate_consumer_worker_marker_count=rank=${deferred_worker_rank},count=${consumer_worker_count}" \
          >>"$vsa_validation"
        if [[ "$producer_worker_count" != 1 || "$consumer_worker_count" != 1 ]]; then
          echo "validation_status=failed_deferred_gate_worker_${deferred_worker_rank}_marker_count_producer_${producer_worker_count}_consumer_${consumer_worker_count}" \
            >>"$vsa_validation"
          echo "Each H3 VSA deferred-gate worker must own exactly one producer and consumer marker; see $vsa_validation" >&2
          return 1
        fi
      done
    elif [[ "$deferred_producer_count" != 0 || "$deferred_consumer_count" != 0 || \
            "$deferred_fallback_count" != 0 ]]; then
      echo "validation_status=failed_unrequested_deferred_gate" >>"$vsa_validation"
      echo "Deferred H3 VSA gate communication ran or failed while disabled; see $vsa_validation" >&2
      return 1
    fi
    local o_bundle_producer_marker='FASTVIDEO_VSA H3 reverse-O bundle producer active:'
    local o_bundle_consumer_marker='MiniMax H3 VSA reverse-O bundle SP active:'
    local o_bundle_producer_pattern="FASTVIDEO_VSA H3 reverse-O bundle producer active: fine=\\(1, ${QKV_E4M3_SEQUENCE_ROW_COUNT}, 7, 128\\), compact_coarse=\\(1, ${VSA_O_BUNDLE_COMPACT_COARSE_ROWS}, 7, 128\\), bundle=\\(1, ${VSA_O_BUNDLE_PRODUCER_ROWS}, 7, 128\\), kmax=${VSA_O_BUNDLE_KMAX}, destination=registered_reverse_o"
    local o_bundle_consumer_suffix="local_gate=\\(1, ${QKV_E4M3_LOCAL_ROW_COUNT}, 56, 128\\) reversed_bundle=\\(1, ${VSA_O_BUNDLE_CONSUMER_ROWS}, 56, 128\\) kmax=${VSA_O_BUNDLE_KMAX} elided_gate_operand_bytes=${VSA_ELIDED_GATE_OPERAND_BYTES} elided_gate_remote_wire_bytes=${VSA_ELIDED_GATE_REMOTE_WIRE_BYTES} piggyback_tail_operand_bytes=${VSA_PIGGYBACK_TAIL_OPERAND_BYTES} piggyback_tail_remote_wire_bytes=${VSA_PIGGYBACK_TAIL_REMOTE_WIRE_BYTES}"
    local o_bundle_failure_pattern='(MiniMax-H3|H3 VSA) reverse-O bundl(e|ing).*(requires|absent|stale|untrusted|mismatch|unsupported|disappeared|wrong|failed|fallback|fell back|lost|did not)|MiniMax-H3 VSA backend did not retain its registered reverse-O landing|FlashInfer PCIe Ulysses O producer-direct exchange fell back:'
    if [[ "${VLLM_OMNI_H3_EXPERIMENT_OVERLAP:-0}" == 1 ]]; then
      # The chunked route emits its own exact contract after all four exchanges
      # and local gate/projection have been scheduled. Never demand or fabricate
      # the old whole-bundle markers for this route.
      if grep -Eq "$o_bundle_producer_marker|$o_bundle_consumer_marker" "$server_log"; then
        echo "validation_status=failed_overlap_whole_bundle_route" >>"$vsa_validation"
        return 1
      fi
      o_bundle_producer_marker='H3_OVERLAP_BUNDLE'
      o_bundle_consumer_marker='H3_OVERLAP_BUNDLE'
      o_bundle_consumer_suffix='fine_rows=95936 local_rows=11992 coarse_rows=1648 chunks=4 tail=270 gate=bf16 projector=active'
      o_bundle_producer_pattern="$o_bundle_producer_marker rank=[0-7] $o_bundle_consumer_suffix"
      echo "vsa_o_bundle_layout=four_chunks_with_replicated_coarse_tail" >>"$vsa_validation"
    fi
    local o_bundle_producer_count o_bundle_consumer_count
    local o_bundle_exact_producer_count o_bundle_exact_consumer_count
    local o_bundle_failure_count o_bundle_full_gate_count
    local o_bundle_compact_producer_count o_bundle_compact_consumer_count
    o_bundle_producer_count="$(grep -Fc "$o_bundle_producer_marker" "$server_log" || true)"
    o_bundle_consumer_count="$(grep -Fc "$o_bundle_consumer_marker" "$server_log" || true)"
    o_bundle_exact_producer_count="$(grep -Ec "$o_bundle_producer_pattern" "$server_log" || true)"
    o_bundle_exact_consumer_count="$(grep -Ec "$o_bundle_consumer_marker rank=[0-7] $o_bundle_consumer_suffix" "$server_log" || true)"
    o_bundle_failure_count="$(grep -Eic "$o_bundle_failure_pattern" "$server_log" || true)"
    o_bundle_full_gate_count="$(grep -Fc 'FlashInfer PCIe Ulysses VSA gate exchange active:' "$server_log" || true)"
    o_bundle_compact_producer_count="$deferred_producer_count"
    o_bundle_compact_consumer_count="$deferred_consumer_count"
    echo "vsa_o_bundle_required=$VSA_O_BUNDLE" >>"$vsa_validation"
    echo "vsa_o_bundle_required_capacity_bytes=$FLASHINFER_O_BUNDLE_REQUIRED_BYTES" >>"$vsa_validation"
    echo "vsa_o_bundle_configured_capacity_bytes=$FLASHINFER_MAX_BYTES" >>"$vsa_validation"
    echo "vsa_o_bundle_producer_marker_count=$o_bundle_producer_count" >>"$vsa_validation"
    echo "vsa_o_bundle_exact_producer_marker_count=$o_bundle_exact_producer_count" >>"$vsa_validation"
    echo "vsa_o_bundle_consumer_marker_count=$o_bundle_consumer_count" >>"$vsa_validation"
    echo "vsa_o_bundle_exact_consumer_marker_count=$o_bundle_exact_consumer_count" >>"$vsa_validation"
    echo "vsa_o_bundle_failure_marker_count=$o_bundle_failure_count" >>"$vsa_validation"
    echo "vsa_o_bundle_forbidden_full_gate_marker_count=$o_bundle_full_gate_count" >>"$vsa_validation"
    echo "vsa_o_bundle_forbidden_compact_coarse_producer_marker_count=$o_bundle_compact_producer_count" >>"$vsa_validation"
    echo "vsa_o_bundle_forbidden_compact_coarse_consumer_marker_count=$o_bundle_compact_consumer_count" >>"$vsa_validation"
    if [[ "$VSA_O_BUNDLE" == 1 ]]; then
      if [[ "$o_bundle_producer_count" != "$expected_sp" || \
            "$o_bundle_consumer_count" != "$expected_sp" || \
            "$o_bundle_exact_producer_count" != "$expected_sp" || \
            "$o_bundle_exact_consumer_count" != "$expected_sp" || \
            "$o_bundle_failure_count" != 0 || "$o_bundle_full_gate_count" != 0 || \
            "$o_bundle_compact_producer_count" != 0 || \
            "$o_bundle_compact_consumer_count" != 0 ]]; then
        echo "validation_status=failed_vsa_o_bundle_route" >>"$vsa_validation"
        echo "H3 VSA reverse-O bundle ownership, shape, or forbidden-collective evidence is invalid; see $vsa_validation" >&2
        return 1
      fi
      local o_bundle_worker_rank o_bundle_producer_worker_count o_bundle_consumer_worker_count
      for ((o_bundle_worker_rank=0; o_bundle_worker_rank<expected_sp; o_bundle_worker_rank++)); do
        o_bundle_producer_worker_count="$({ grep -E "$o_bundle_producer_pattern" "$server_log" || true; } | \
          grep -Ec "\\(DiffusionWorker_SP${o_bundle_worker_rank} pid=[0-9]+\\)" || true)"
        o_bundle_consumer_worker_count="$({ grep -E "$o_bundle_consumer_marker rank=${o_bundle_worker_rank} $o_bundle_consumer_suffix" "$server_log" || true; } | \
          grep -Ec "\\(DiffusionWorker_SP${o_bundle_worker_rank} pid=[0-9]+\\)" || true)"
        echo "vsa_o_bundle_producer_worker_marker_count=rank=${o_bundle_worker_rank},count=${o_bundle_producer_worker_count}" \
          >>"$vsa_validation"
        echo "vsa_o_bundle_consumer_worker_marker_count=rank=${o_bundle_worker_rank},count=${o_bundle_consumer_worker_count}" \
          >>"$vsa_validation"
        if [[ "$o_bundle_producer_worker_count" != 1 || \
              "$o_bundle_consumer_worker_count" != 1 ]]; then
          echo "validation_status=failed_vsa_o_bundle_worker_${o_bundle_worker_rank}_marker_count_producer_${o_bundle_producer_worker_count}_consumer_${o_bundle_consumer_worker_count}" \
            >>"$vsa_validation"
          echo "Each H3 VSA reverse-O bundle worker must own exactly one producer and consumer marker; see $vsa_validation" >&2
          return 1
        fi
      done
    elif [[ "$o_bundle_producer_count" != 0 || "$o_bundle_consumer_count" != 0 || \
            "$o_bundle_failure_count" != 0 ]]; then
      echo "validation_status=failed_unrequested_vsa_o_bundle" >>"$vsa_validation"
      echo "H3 VSA reverse-O bundling ran or failed while disabled; see $vsa_validation" >&2
      return 1
    fi
    local direct_q2k_marker='FASTVIDEO_VSA H3 metadata: direct ordered q2k enabled by VLLM_OMNI_FASTVIDEO_VSA_DIRECT_Q2K=1'
    local legacy_q2k_marker='FASTVIDEO_VSA H3 metadata: legacy bool-map conversion active'
    local direct_q2k_count legacy_q2k_count expected_q2k_count
    direct_q2k_count="$(grep -Fc "$direct_q2k_marker" "$server_log" || true)"
    legacy_q2k_count="$(grep -Fc "$legacy_q2k_marker" "$server_log" || true)"
    expected_q2k_count=0
    [[ "$FASTH3_VSA_PROVIDER" == flashinfer ]] && expected_q2k_count=8
    echo "direct_q2k_marker_count=$direct_q2k_count" >>"$vsa_validation"
    echo "legacy_q2k_marker_count=$legacy_q2k_count" >>"$vsa_validation"
    if [[ "$VSA_DIRECT_Q2K" == 1 ]]; then
      if [[ "$direct_q2k_count" != "$expected_q2k_count" || "$legacy_q2k_count" != 0 ]]; then
        echo "validation_status=failed_direct_q2k_route" >>"$vsa_validation"
        echo "Direct ordered q2k ownership/fallback evidence is invalid; see $vsa_validation" >&2
        return 1
      fi
    elif [[ "$direct_q2k_count" != 0 || "$legacy_q2k_count" != "$expected_q2k_count" ]]; then
      echo "validation_status=failed_legacy_q2k_route" >>"$vsa_validation"
      echo "Legacy q2k ownership/direct-route evidence is invalid; see $vsa_validation" >&2
      return 1
    fi
    if [[ "$VSA_FUSED_TILE_PACK" == 1 ]]; then
      local tile_pack_marker='FASTVIDEO_VSA H3 tile pack: fused Triton compact->tile64 enabled'
      local tile_pack_count
      tile_pack_count="$(grep -c "$tile_pack_marker" "$server_log" || true)"
      if [[ "$tile_pack_count" != 8 ]]; then
        echo "validation_status=failed_tile_pack_marker_count_${tile_pack_count}" >>"$vsa_validation"
        echo "Fused H3 VSA tile-pack ownership markers must appear once per worker; see $vsa_validation" >&2
        return 1
      fi
      if grep -q \
        'VLLM_OMNI_FASTVIDEO_VSA_FUSED_TILE_PACK=1 requested.*using the reference tile pack' \
        "$server_log"; then
        echo "validation_status=failed_tile_pack_fallback" >>"$vsa_validation"
        echo "Fused H3 VSA tile pack fell back to the reference route; see $vsa_validation" >&2
        return 1
      fi
      echo "tile_pack_marker_count=$tile_pack_count" >>"$vsa_validation"
    elif grep -q 'FASTVIDEO_VSA H3 tile pack: fused Triton compact->tile64 enabled' "$server_log"; then
      echo "validation_status=failed_unrequested_tile_pack" >>"$vsa_validation"
      echo "Fused H3 VSA tile pack ran while disabled; see $vsa_validation" >&2
      return 1
    fi
    local gate_untile_marker='FASTVIDEO_VSA H3 gate+untile: fused BF16 coarse-gate add and tile64->aligned enabled'
    local gate_untile_fallback_marker='VLLM_OMNI_FASTVIDEO_VSA_FUSED_GATE_UNTILE=1 requested but the H3 tensor shape/platform is unsupported'
    local gate_untile_marker_count gate_untile_fallback_count
    gate_untile_marker_count="$(grep -Fc "$gate_untile_marker" "$server_log" || true)"
    gate_untile_fallback_count="$(grep -Fc "$gate_untile_fallback_marker" "$server_log" || true)"
    echo "gate_untile_marker_count=$gate_untile_marker_count" >>"$vsa_validation"
    echo "gate_untile_fallback_marker_count=$gate_untile_fallback_count" >>"$vsa_validation"
    if [[ "$VSA_FUSED_GATE_UNTILE" == 1 ]]; then
      if [[ "$gate_untile_marker_count" != 8 || "$gate_untile_fallback_count" != 0 ]]; then
        echo "validation_status=failed_gate_untile_route" >>"$vsa_validation"
        echo "Fused H3 VSA gate/untile ownership or fallback evidence is invalid; see $vsa_validation" >&2
        return 1
      fi
      local gate_worker_rank gate_worker_marker_count
      for gate_worker_rank in {0..7}; do
        gate_worker_marker_count="$({ grep -F "$gate_untile_marker" "$server_log" || true; } | \
          grep -Ec "\\(DiffusionWorker_SP${gate_worker_rank} pid=[0-9]+\\)" || true)"
        echo "gate_untile_worker_marker_count=rank=${gate_worker_rank},count=${gate_worker_marker_count}" \
          >>"$vsa_validation"
        if [[ "$gate_worker_marker_count" != 1 ]]; then
          echo "validation_status=failed_gate_untile_worker_${gate_worker_rank}_marker_count_${gate_worker_marker_count}" \
            >>"$vsa_validation"
          echo "Each H3 VSA gate/untile worker must own exactly one marker; see $vsa_validation" >&2
          return 1
        fi
      done
    elif [[ "$gate_untile_marker_count" != 0 || "$gate_untile_fallback_count" != 0 ]]; then
      echo "validation_status=failed_unrequested_gate_untile" >>"$vsa_validation"
      echo "Fused H3 VSA gate/untile ran or fell back while disabled; see $vsa_validation" >&2
      return 1
    fi

    local untile_marker='FASTVIDEO_VSA H3 output untile: fused Triton tile64->aligned enabled'
    local untile_fallback_marker='FASTVIDEO_VSA H3 output untile fallback:'
    local untile_marker_count untile_fallback_count expected_untile_count
    untile_marker_count="$(grep -Fc "$untile_marker" "$server_log" || true)"
    untile_fallback_count="$(grep -Fc "$untile_fallback_marker" "$server_log" || true)"
    if [[ "$VSA_FUSED_UNTILE" == 1 ]]; then
      expected_untile_count=8
      [[ "$VSA_FUSED_GATE_UNTILE" == 1 ]] && expected_untile_count=0
      echo "untile_marker_count=$untile_marker_count" >>"$vsa_validation"
      echo "untile_fallback_marker_count=$untile_fallback_count" >>"$vsa_validation"
      if [[ "$untile_marker_count" != "$expected_untile_count" ]]; then
        echo "validation_status=failed_untile_marker_count_${untile_marker_count}" >>"$vsa_validation"
        echo "Fused H3 VSA output-untile marker count is invalid; see $vsa_validation" >&2
        return 1
      fi
      if [[ "$untile_fallback_count" != 0 ]]; then
        echo "validation_status=failed_untile_fallback" >>"$vsa_validation"
        echo "Fused H3 VSA output untile fell back to the reference route; see $vsa_validation" >&2
        return 1
      fi
      local worker_rank worker_marker_count
      if [[ "$expected_untile_count" == 8 ]]; then
        for worker_rank in {0..7}; do
          worker_marker_count="$({ grep -F "$untile_marker" "$server_log" || true; } | \
            grep -Ec "\\(DiffusionWorker_SP${worker_rank} pid=[0-9]+\\)" || true)"
          echo "untile_worker_marker_count=rank=${worker_rank},count=${worker_marker_count}" \
            >>"$vsa_validation"
          if [[ "$worker_marker_count" != 1 ]]; then
            echo "validation_status=failed_untile_worker_${worker_rank}_marker_count_${worker_marker_count}" \
              >>"$vsa_validation"
            echo "Each H3 VSA output-untile worker must own exactly one marker; see $vsa_validation" >&2
            return 1
          fi
        done
      fi
    elif [[ "$untile_marker_count" != 0 || "$untile_fallback_count" != 0 ]]; then
      echo "validation_status=failed_unrequested_untile" >>"$vsa_validation"
      echo "Fused H3 VSA output untile ran or fell back while disabled; see $vsa_validation" >&2
      return 1
    fi
    echo "validation_status=ok" >>"$vsa_validation"
  fi

  if [[ "$CHUNKED_CPU_MP4_OUTPUT" == 1 ]]; then
    local chunked_output_validation="$case_dir/chunked-cpu-mp4-validation.txt"
    local chunked_route='finalized_chunk_gpu_u8_pinned_d2h_pyav_libx264'
    {
      echo "required_route=$chunked_route"
      echo "required_frames=362"
      echo "required_slots=$CHUNKED_CPU_MP4_SLOTS"
      grep "MiniMax H3 output complete: route=$chunked_route" "$server_log" || true
    } >"$chunked_output_validation"
    if ! grep -Eq \
      "MiniMax H3 output complete: route=${chunked_route} frames=362 .*slots=${CHUNKED_CPU_MP4_SLOTS} " \
      "$server_log"; then
      echo "validation_status=failed_missing_completion_marker" >>"$chunked_output_validation"
      echo "Chunked CPU MP4 completion marker is missing or malformed; see $chunked_output_validation" >&2
      return 1
    fi
    if grep -Eq \
      'Video response encoding route selected: selected_path=(legacy_fallback|direct_planar)' \
      "$server_log"; then
      echo "validation_status=failed_api_reencode" >>"$chunked_output_validation"
      echo "Chunked CPU MP4 output was unexpectedly re-encoded by the API; see $chunked_output_validation" >&2
      return 1
    fi
    if [[ "$VAE_TEMPORAL_PRE_GATHER_PRUNE" == 1 ]]; then
      local prune_marker='MiniMax H3 VAE temporal pre-gather prune complete: route=canonical_28_to_22 owner=sp_rank0 calls=21 decoded_frames_per_window=28 gathered_frames_per_window=22 output_frames=362 reduction=21.43%'
      local prune_marker_prefix='MiniMax H3 VAE temporal pre-gather prune complete:'
      local expected_request_count=$((WARMUPS + REPEATS))
      local observed_request_count=0
      local prune_marker_count prune_prefix_count request_log request_marker_count request_prefix_count
      prune_marker_count="$(grep -Fc "$prune_marker" "$server_log" || true)"
      prune_prefix_count="$(grep -Fc "$prune_marker_prefix" "$server_log" || true)"
      {
        echo "temporal_prune_expected_request_count=$expected_request_count"
        echo "temporal_prune_server_marker_count=$prune_marker_count"
        echo "temporal_prune_server_prefix_count=$prune_prefix_count"
      } >>"$chunked_output_validation"
      if [[ "$prune_marker_count" != "$prune_prefix_count" ]]; then
        echo "validation_status=failed_malformed_temporal_prune_marker" >>"$chunked_output_validation"
        echo "MiniMax H3 VAE temporal prune markers must preserve the exact route and owner contract; see $chunked_output_validation" >&2
        return 1
      fi
      for request_log in \
        "$case_dir"/warmup-*-server.log \
        "$case_dir"/measured-*-server.log; do
        [[ -f "$request_log" ]] || continue
        observed_request_count=$((observed_request_count + 1))
        request_marker_count="$(grep -Fc "$prune_marker" "$request_log" || true)"
        request_prefix_count="$(grep -Fc "$prune_marker_prefix" "$request_log" || true)"
        printf 'temporal_prune_request_log=%s,marker_count=%s,prefix_count=%s\n' \
          "$(basename "$request_log")" "$request_marker_count" "$request_prefix_count" \
          >>"$chunked_output_validation"
        if [[ "$request_marker_count" != 1 || "$request_prefix_count" != 1 ]]; then
          echo "validation_status=failed_temporal_prune_request_marker_count" \
            >>"$chunked_output_validation"
          echo "Each MiniMax H3 request log must contain exactly one temporal prune completion marker; see $chunked_output_validation" >&2
          return 1
        fi
      done
      echo "temporal_prune_observed_request_count=$observed_request_count" \
        >>"$chunked_output_validation"
      if [[ "$prune_marker_count" != "$observed_request_count" ]]; then
        echo "validation_status=failed_temporal_prune_server_request_count_mismatch" \
          >>"$chunked_output_validation"
        echo "MiniMax H3 temporal prune server markers must match completed request logs; see $chunked_output_validation" >&2
        return 1
      fi
      if [[ "$require_complete_request_set" == 1 && \
            ( "$observed_request_count" != "$expected_request_count" || \
              "$prune_marker_count" != "$expected_request_count" ) ]]; then
        echo "validation_status=failed_temporal_prune_incomplete_request_set" \
          >>"$chunked_output_validation"
        echo "MiniMax H3 temporal prune final validation requires one marker for every warmup and measured request; see $chunked_output_validation" >&2
        return 1
      fi
    elif grep -Fq 'MiniMax H3 VAE temporal pre-gather prune complete:' "$server_log"; then
      echo "validation_status=failed_unrequested_temporal_prune" >>"$chunked_output_validation"
      echo "MiniMax H3 VAE temporal pre-gather prune ran while disabled; see $chunked_output_validation" >&2
      return 1
    fi
    if [[ "$VAE_TEMPORAL_CHUNK_PARALLEL" == 1 ]]; then
      local temporal_parallel_validation="$case_dir/temporal-chunk-parallel-validation.txt"
      local temporal_parallel_marker='MiniMax H3 VAE temporal chunk parallel complete: route=canonical_107t_21w_round_robin_gather owner=sp_rank0 rounds=3 windows=21 real=21 placeholders=3 gathers=3 segment_bytes=118947840 input_bytes=2854748160 output_bytes=2854748160 output_frames=362 quality=eager_bit_exact_candidate_requires_gpu_multiseed_ab'
      local temporal_parallel_prefix='MiniMax H3 VAE temporal chunk parallel complete:'
      local temporal_expected_request_count=$((WARMUPS + REPEATS))
      local temporal_observed_request_count=0
      local temporal_marker_count temporal_prefix_count temporal_request_log
      local temporal_request_marker_count temporal_request_prefix_count
      temporal_marker_count="$(grep -Fc "$temporal_parallel_marker" "$server_log" || true)"
      temporal_prefix_count="$(grep -Fc "$temporal_parallel_prefix" "$server_log" || true)"
      {
        echo "required_route=canonical_107t_21w_round_robin_gather"
        echo "required_owner=sp_rank0"
        echo "required_rounds=3"
        echo "required_windows=21"
        echo "required_real_segments=21"
        echo "required_placeholder_segments=3"
        echo "required_segment_bytes=118947840"
        echo "required_input_bytes=2854748160"
        echo "required_output_bytes=2854748160"
        echo "quality_contract=eager_bit_exact_candidate_requires_gpu_multiseed_ab"
        echo "performance_contract=same_sequential_tile_compute_collective_reduction_benchmark_required"
        echo "expected_request_count=$temporal_expected_request_count"
        echo "server_marker_count=$temporal_marker_count"
        echo "server_prefix_count=$temporal_prefix_count"
      } >"$temporal_parallel_validation"
      if [[ "$temporal_marker_count" != "$temporal_prefix_count" ]]; then
        echo "validation_status=failed_malformed_marker" >>"$temporal_parallel_validation"
        echo "MiniMax H3 temporal chunk markers must preserve the exact accounting contract; see $temporal_parallel_validation" >&2
        return 1
      fi
      for temporal_request_log in \
        "$case_dir"/warmup-*-server.log \
        "$case_dir"/measured-*-server.log; do
        [[ -f "$temporal_request_log" ]] || continue
        temporal_observed_request_count=$((temporal_observed_request_count + 1))
        temporal_request_marker_count="$(grep -Fc "$temporal_parallel_marker" "$temporal_request_log" || true)"
        temporal_request_prefix_count="$(grep -Fc "$temporal_parallel_prefix" "$temporal_request_log" || true)"
        printf 'request_log=%s,marker_count=%s,prefix_count=%s\n' \
          "$(basename "$temporal_request_log")" \
          "$temporal_request_marker_count" \
          "$temporal_request_prefix_count" \
          >>"$temporal_parallel_validation"
        if [[ "$temporal_request_marker_count" != 1 || \
              "$temporal_request_prefix_count" != 1 ]]; then
          echo "validation_status=failed_request_marker_count" >>"$temporal_parallel_validation"
          echo "Each MiniMax H3 request must emit exactly one temporal chunk marker; see $temporal_parallel_validation" >&2
          return 1
        fi
      done
      echo "observed_request_count=$temporal_observed_request_count" \
        >>"$temporal_parallel_validation"
      if [[ "$temporal_marker_count" != "$temporal_observed_request_count" ]]; then
        echo "validation_status=failed_server_request_count_mismatch" \
          >>"$temporal_parallel_validation"
        echo "MiniMax H3 temporal chunk server markers must match request logs; see $temporal_parallel_validation" >&2
        return 1
      fi
      if [[ "$require_complete_request_set" == 1 && \
            ( "$temporal_observed_request_count" != "$temporal_expected_request_count" || \
              "$temporal_marker_count" != "$temporal_expected_request_count" ) ]]; then
        echo "validation_status=failed_incomplete_request_set" \
          >>"$temporal_parallel_validation"
        echo "MiniMax H3 temporal chunk final validation requires every request marker; see $temporal_parallel_validation" >&2
        return 1
      fi
      echo "validation_status=ok" >>"$temporal_parallel_validation"
    elif grep -Fq 'MiniMax H3 VAE temporal chunk parallel complete:' "$server_log"; then
      echo "validation_status=failed_unrequested_temporal_chunk_parallel" \
        >>"$chunked_output_validation"
      echo "MiniMax H3 temporal chunk parallel ran while disabled; see $chunked_output_validation" >&2
      return 1
    fi
    echo "validation_status=ok" >>"$chunked_output_validation"
  fi

  if [[ "$require_flashinfer_rdma" == 1 ]]; then
    local require_full_vsa_gate="$FASTH3_VSA_MODE"
    if [[ "$VSA_DEFERRED_GATE_SP" == 1 || "$VSA_O_BUNDLE" == 1 ]]; then
      require_full_vsa_gate=0
    fi
    if ! SERVER_LOG="$server_log" VALIDATION_REPORT="$rdma_validation" \
      EXPECTED_CAPACITY="$FLASHINFER_MAX_BYTES" EXPECTED_TRANSPORT="$FLASHINFER_ULYSSES_ROUTE" \
      REQUIRE_QK_DIRECT="$require_qk_direct" \
      REQUIRE_QKV_E4M3="$require_qkv_e4m3" \
      EXPECTED_QKV_PAYLOAD_SHA256="$QKV_E4M3_EXPECTED_PAYLOAD_SHA256" \
      REQUIRE_O_DIRECT="$require_o_direct" \
      REQUIRE_VSA_GATE="$require_full_vsa_gate" \
      REQUIRE_VSA_DEFERRED_GATE="$VSA_DEFERRED_GATE_SP" \
      REQUIRE_VSA_O_BUNDLE="$VSA_O_BUNDLE" \
      REQUIRE_RELEASE_AFTER_DENOISE="$require_release_after_denoise" \
      EXPECTED_LOCAL_ROWS="$QKV_E4M3_LOCAL_ROW_COUNT" \
      EXPECTED_SEQUENCE_ROWS="$QKV_E4M3_SEQUENCE_ROW_COUNT" \
      EXPECTED_COMPACT_ROWS="$QKV_E4M3_COMPACT_ROW_COUNT" \
      EXPECTED_PADDED_ROWS="$QKV_E4M3_PADDED_ROW_COUNT" \
      EXPECTED_COARSE_ROWS="$VSA_O_BUNDLE_COMPACT_COARSE_ROWS" \
      EXPECTED_O_BUNDLE_KMAX="$VSA_O_BUNDLE_KMAX" \
      EXPECTED_O_BUNDLE_PRODUCER_ROWS="$VSA_O_BUNDLE_PRODUCER_ROWS" \
      EXPECTED_O_BUNDLE_CONSUMER_ROWS="$VSA_O_BUNDLE_CONSUMER_ROWS" \
      EXPECTED_ELIDED_GATE_OPERAND_BYTES="$VSA_ELIDED_GATE_OPERAND_BYTES" \
      EXPECTED_ELIDED_GATE_REMOTE_WIRE_BYTES="$VSA_ELIDED_GATE_REMOTE_WIRE_BYTES" \
      EXPECTED_PIGGYBACK_TAIL_OPERAND_BYTES="$VSA_PIGGYBACK_TAIL_OPERAND_BYTES" \
      EXPECTED_PIGGYBACK_TAIL_REMOTE_WIRE_BYTES="$VSA_PIGGYBACK_TAIL_REMOTE_WIRE_BYTES" \
      "$PYTHON" - <<'PY'
import os
from pathlib import Path
import re

server_log = Path(os.environ["SERVER_LOG"])
report_path = Path(os.environ["VALIDATION_REPORT"])
expected_capacity = int(os.environ["EXPECTED_CAPACITY"])
expected_transport = os.environ["EXPECTED_TRANSPORT"]
require_qk_direct = os.environ["REQUIRE_QK_DIRECT"] == "1"
require_qkv_e4m3 = os.environ["REQUIRE_QKV_E4M3"] == "1"
expected_qkv_payload_sha256 = os.environ["EXPECTED_QKV_PAYLOAD_SHA256"]
require_o_direct = os.environ["REQUIRE_O_DIRECT"] == "1"
require_vsa_gate = os.environ["REQUIRE_VSA_GATE"] == "1"
require_vsa_deferred_gate = os.environ["REQUIRE_VSA_DEFERRED_GATE"] == "1"
require_vsa_o_bundle = os.environ["REQUIRE_VSA_O_BUNDLE"] == "1"
require_release_after_denoise = os.environ["REQUIRE_RELEASE_AFTER_DENOISE"] == "1"
expected_local_rows = int(os.environ.get("EXPECTED_LOCAL_ROWS", "11936"))
expected_sequence_rows = int(os.environ.get("EXPECTED_SEQUENCE_ROWS", "95488"))
expected_compact_rows = int(os.environ.get("EXPECTED_COMPACT_ROWS", "95487"))
expected_padded_rows = int(os.environ.get("EXPECTED_PADDED_ROWS", "105024"))
expected_coarse_rows = int(os.environ.get("EXPECTED_COARSE_ROWS", "1641"))
expected_o_bundle_kmax = int(os.environ.get("EXPECTED_O_BUNDLE_KMAX", "275"))
expected_o_bundle_producer_rows = int(
    os.environ.get("EXPECTED_O_BUNDLE_PRODUCER_ROWS", "97688")
)
expected_o_bundle_consumer_rows = int(
    os.environ.get("EXPECTED_O_BUNDLE_CONSUMER_ROWS", "12211")
)
expected_elided_gate_operand_bytes = int(
    os.environ.get("EXPECTED_ELIDED_GATE_OPERAND_BYTES", "171114496")
)
expected_elided_gate_remote_wire_bytes = int(
    os.environ.get("EXPECTED_ELIDED_GATE_REMOTE_WIRE_BYTES", "149725184")
)
expected_piggyback_tail_operand_bytes = int(
    os.environ.get("EXPECTED_PIGGYBACK_TAIL_OPERAND_BYTES", "3942400")
)
expected_piggyback_tail_remote_wire_bytes = int(
    os.environ.get("EXPECTED_PIGGYBACK_TAIL_REMOTE_WIRE_BYTES", "3449600")
)
text = server_log.read_text(encoding="utf-8", errors="replace")
lines = text.splitlines()

worker_re = re.compile(r"DiffusionWorker_SP([0-9]+)\s+pid=[0-9]+")
armed_marker = "FlashInfer PCIe Ulysses armed:"
armed_detail_re = re.compile(
    r"group=([^\s]+).*?world=([0-9]+).*?device=cuda:([0-9]+).*?"
    r"transport=([A-Za-z0-9_-]+).*?capacity=([0-9]+)"
)
qk_marker = "FlashInfer PCIe Ulysses Q/K producer-direct exchange active:"
qk_detail_re = re.compile(
    r"rank=([0-9]+)\s+group=([^\s]+).*?"
    rf"shape=\(1,\s*{expected_local_rows},\s*56,\s*128\).*?"
    r"dtype=torch\.bfloat16"
)
qkv_e4m3_marker = "FlashInfer PCIe Ulysses Q/K/V producer-direct exchange active:"
qkv_e4m3_detail_re = re.compile(
    r"rank=([0-9]+)\s+group=([^\s]+).*?"
    rf"shape=\(1,\s*{expected_local_rows},\s*56,\s*128\).*?"
    r"dtype=torch\.float8_e4m3fn"
)
qkv_e4m3_install_marker = "MiniMax H3 E4M3 QKV transport scales installed: "
qkv_e4m3_install_detail_re = re.compile(
    r"blocks=50\s+provider=([^\s]+)\s+abi=([^\s]+)\s+"
    r"payload_sha256=([0-9a-f]{64})\s+"
    r"scale_min=([^\s]+)\s+scale_max=([^\s]+)"
)
qkv_e4m3_receive_marker = (
    "FASTVIDEO_VSA H3 FP8 QKV transport receive path: fused "
    "E4M3->BF16 dequant + tile64 pack enabled "
)
qkv_e4m3_receive_detail_re = re.compile(
    rf"compact_rows={expected_compact_rows},\s*padded_rows={expected_padded_rows}"
)
o_direct_marker = "FlashInfer PCIe Ulysses O producer-direct exchange active:"
expected_o_direct_rows = (
    expected_o_bundle_producer_rows
    if require_vsa_o_bundle
    else expected_sequence_rows
)
o_direct_detail_re = re.compile(
    r"rank=([0-9]+)\s+group=([^\s]+).*?"
    rf"shape=\(1,\s*{expected_o_direct_rows},\s*7,\s*128\).*?"
    r"dtype=torch\.bfloat16"
)
o_direct_fallback_marker = (
    "FlashInfer PCIe Ulysses O producer-direct exchange fell back:"
)
# Pre-exchange builds emitted this as soon as Q/K landing buffers were
# acquired. Count it for historical-log diagnostics, but never accept it as
# evidence that either collective completed.
legacy_qk_marker = "FlashInfer PCIe Ulysses Q/K producer-direct landing active:"
gate_marker = "FlashInfer PCIe Ulysses VSA gate exchange active:"
gate_detail_re = re.compile(
    r"rank=([0-9]+)\s+group=([^\s]+).*?"
    rf"shape=\(1,\s*{expected_local_rows},\s*56,\s*128\).*?"
    r"dtype=torch\.bfloat16"
)
deferred_gate_marker = "MiniMax H3 VSA deferred-gate SP active:"
deferred_gate_detail_re = re.compile(
    r"rank=([0-9]+)\s+"
    rf"local_gate=\(1,\s*{expected_local_rows},\s*56,\s*128\)\s+"
    rf"local_coarse=\(1,\s*{expected_coarse_rows},\s*7,\s*128\)\s+"
    rf"gathered_coarse=\(1,\s*{expected_coarse_rows},\s*56,\s*128\)\s+"
    rf"elided_gate_operand_bytes={expected_elided_gate_operand_bytes}\s+"
    rf"elided_gate_remote_wire_bytes={expected_elided_gate_remote_wire_bytes}"
)
deferred_gate_producer_marker = "FASTVIDEO_VSA H3 deferred gate producer active:"
o_bundle_producer_marker = "FASTVIDEO_VSA H3 reverse-O bundle producer active:"
o_bundle_producer_detail_re = re.compile(
    rf"fine=\(1,\s*{expected_sequence_rows},\s*7,\s*128\),\s+"
    rf"compact_coarse=\(1,\s*{expected_coarse_rows},\s*7,\s*128\),\s+"
    rf"bundle=\(1,\s*{expected_o_bundle_producer_rows},\s*7,\s*128\),\s+"
    rf"kmax={expected_o_bundle_kmax},\s+destination=registered_reverse_o"
)
o_bundle_consumer_marker = "MiniMax H3 VSA reverse-O bundle SP active:"
o_bundle_consumer_detail_re = re.compile(
    r"rank=([0-9]+)\s+"
    rf"local_gate=\(1,\s*{expected_local_rows},\s*56,\s*128\)\s+"
    rf"reversed_bundle=\(1,\s*{expected_o_bundle_consumer_rows},\s*56,\s*128\)\s+"
    rf"kmax={expected_o_bundle_kmax}\s+"
    rf"elided_gate_operand_bytes={expected_elided_gate_operand_bytes}\s+"
    rf"elided_gate_remote_wire_bytes={expected_elided_gate_remote_wire_bytes}\s+"
    rf"piggyback_tail_operand_bytes={expected_piggyback_tail_operand_bytes}\s+"
    rf"piggyback_tail_remote_wire_bytes={expected_piggyback_tail_remote_wire_bytes}"
)
release_marker = "FlashInfer PCIe Ulysses released after denoise; next request will re-arm"
reclaim_marker = "FlashInfer PCIe Ulysses re-arm reclaimed post-VAE allocator cache:"
reclaim_detail_re = re.compile(
    r"rank=([0-9]+)\s+group=([^\s]+)\s+device=cuda:([0-9]+)"
)
adapter_failure_re = re.compile(
    r"required FlashInfer all-RDMA(?: Ulysses)?|"
    r"FlashInfer PCIe Ulysses unavailable; using NCCL|"
    r"FlashInfer PCIe Ulysses.*(?:using NCCL|declined)|"
    r"FlashInfer PCIe Ulysses (?:world-size mismatch|process-group identity changed)|"
    r"FlashInfer.*operand.*exceed(?:s|ed|ing).*capacity|"
    r"PCIe backend initialization failed|"
    r"PCIe Ulysses communicator entered BROKEN state|"
    r"(?:the )?PCIe Ulysses backend fell back to the all-P2P route|"
    r"failed to close .*FlashInfer.*Ulysses|"
    r"MiniMax-H3 VSA backend did not retain its registered reverse-O landing|"
    r"MiniMax-H3 VSA reverse-O bundle lost producer-direct identity|"
    r"staging fallback is forbidden|"
    r"called on a (?:BROKEN|CLOSING|CLOSED) UlyssesCommunicator|"
    r"observed transport=['\"]?p2p|"
    r"transport=p2p|"
    r"flashinfer-pcie (?:requires|JIT dependencies are missing)|"
    r"UlyssesCommunicator lacks required method|"
    r"E4M3 QKV.*(?:missing|mismatch|unsupported|wrong dtype|fallback|fell back)|"
    r"QKV.*sidecars bind different|"
    r"QKV scale.*(?:does not match|require)|"
    r"QKV transport.*(?:requires|unsupported|wrong dtype|fallback|fell back)|"
    r"QKV transport scales have already been installed",
    re.IGNORECASE,
)


def last_worker_rank_before(line: str, marker_offset: int) -> int | None:
    matches = worker_re.findall(line[:marker_offset])
    return int(matches[-1]) if matches else None


armed = set()
armed_markers = []
malformed = []
qk_exchanges = set()
qk_exchange_markers = []
qkv_e4m3_exchanges = set()
qkv_e4m3_exchange_markers = []
qkv_e4m3_install_markers = []
qkv_e4m3_receive_ranks = []
legacy_qk_landing_marker_count = 0
o_direct_exchanges = set()
o_direct_exchange_markers = []
o_direct_fallbacks = []
gate_exchanges = set()
gate_exchange_markers = []
deferred_gate_ranks = []
deferred_gate_producer_ranks = []
o_bundle_producer_ranks = []
o_bundle_consumer_ranks = []
release_ranks = []
reclaim_markers = []
for line_number, line in enumerate(lines, 1):
    for marker, pattern in (
        ('H3_OVERLAP_EXCHANGE ', r'rank=(\d+) group=(\S+) chunks=4 rows=2998 tail=270 remote_bytes=163975168 direct=1 completed=1'),
        ('H3_OVERLAP_BUNDLE ', r'rank=(\d+) fine_rows=95936 local_rows=11992 coarse_rows=1648 chunks=4 tail=270 gate=bf16 projector=active'),
    ):
        offset = line.find(marker)
        if offset < 0:
            continue
        detail = re.search(pattern,line[offset:])
        worker_rank = last_worker_rank_before(line,offset)
        if os.getenv('VLLM_OMNI_H3_EXPERIMENT_OVERLAP','0') != '1' or detail is None or worker_rank != int(detail[1]):
            malformed.append((line_number,'h3-overlap',line))
        elif marker == 'H3_OVERLAP_EXCHANGE ':
            pair = (int(detail[1]),detail[2])
            o_direct_exchanges.add(pair)
            o_direct_exchange_markers.append(pair)
        else:
            o_bundle_producer_ranks.append(int(detail[1]))
            o_bundle_consumer_ranks.append(int(detail[1]))

    marker_offset = line.find(armed_marker)
    if marker_offset >= 0:
        rank = last_worker_rank_before(line, marker_offset)
        detail = armed_detail_re.search(line[marker_offset:])
        if rank is None or detail is None:
            malformed.append((line_number, "armed", line))
        else:
            group, world, device, transport, capacity = detail.groups()
            armed_tuple = (rank, group, int(world), int(device), transport, int(capacity))
            armed.add(armed_tuple)
            armed_markers.append(armed_tuple)

    marker_offset = line.find(qk_marker)
    if marker_offset >= 0:
        worker_rank = last_worker_rank_before(line, marker_offset)
        detail = qk_detail_re.search(line[marker_offset:])
        if worker_rank is None or detail is None:
            malformed.append((line_number, "qk-direct", line))
        else:
            marker_rank, group = int(detail.group(1)), detail.group(2)
            if worker_rank != marker_rank:
                malformed.append((line_number, "qk-direct-rank-mismatch", line))
            else:
                pair = (marker_rank, group)
                qk_exchanges.add(pair)
                qk_exchange_markers.append(pair)

    marker_offset = line.find(qkv_e4m3_marker)
    if marker_offset >= 0:
        worker_rank = last_worker_rank_before(line, marker_offset)
        detail = qkv_e4m3_detail_re.search(line[marker_offset:])
        if worker_rank is None or detail is None:
            malformed.append((line_number, "qkv-e4m3-direct", line))
        else:
            marker_rank, group = int(detail.group(1)), detail.group(2)
            if worker_rank != marker_rank:
                malformed.append((line_number, "qkv-e4m3-direct-rank-mismatch", line))
            else:
                pair = (marker_rank, group)
                qkv_e4m3_exchanges.add(pair)
                qkv_e4m3_exchange_markers.append(pair)

    marker_offset = line.find(qkv_e4m3_install_marker)
    if marker_offset >= 0:
        worker_rank = last_worker_rank_before(line, marker_offset)
        detail = qkv_e4m3_install_detail_re.search(line[marker_offset:])
        if worker_rank is None or detail is None:
            malformed.append((line_number, "qkv-e4m3-sidecar-install", line))
        else:
            provider, abi, payload_sha256, scale_min, scale_max = detail.groups()
            try:
                scale_min_value = float(scale_min)
                scale_max_value = float(scale_max)
            except ValueError:
                malformed.append((line_number, "qkv-e4m3-sidecar-scale", line))
            else:
                qkv_e4m3_install_markers.append(
                    (
                        worker_rank,
                        provider,
                        abi,
                        payload_sha256,
                        scale_min_value,
                        scale_max_value,
                    )
                )

    marker_offset = line.find(qkv_e4m3_receive_marker)
    if marker_offset >= 0:
        worker_rank = last_worker_rank_before(line, marker_offset)
        detail = qkv_e4m3_receive_detail_re.search(line[marker_offset:])
        if worker_rank is None or detail is None:
            malformed.append((line_number, "qkv-e4m3-receive", line))
        else:
            qkv_e4m3_receive_ranks.append(worker_rank)

    if legacy_qk_marker in line:
        legacy_qk_landing_marker_count += 1

    marker_offset = line.find(o_direct_marker)
    if marker_offset >= 0:
        worker_rank = last_worker_rank_before(line, marker_offset)
        detail = o_direct_detail_re.search(line[marker_offset:])
        if worker_rank is None or detail is None:
            malformed.append((line_number, "o-direct", line))
        else:
            marker_rank, group = int(detail.group(1)), detail.group(2)
            if worker_rank != marker_rank:
                malformed.append((line_number, "o-direct-rank-mismatch", line))
            else:
                pair = (marker_rank, group)
                o_direct_exchanges.add(pair)
                o_direct_exchange_markers.append(pair)

    if o_direct_fallback_marker in line:
        o_direct_fallbacks.append((line_number, line))

    marker_offset = line.find(gate_marker)
    if marker_offset >= 0:
        worker_rank = last_worker_rank_before(line, marker_offset)
        detail = gate_detail_re.search(line[marker_offset:])
        if worker_rank is None or detail is None:
            malformed.append((line_number, "vsa-gate", line))
        else:
            marker_rank, group = int(detail.group(1)), detail.group(2)
            if worker_rank != marker_rank:
                malformed.append((line_number, "vsa-gate-rank-mismatch", line))
            else:
                pair = (marker_rank, group)
                gate_exchanges.add(pair)
                gate_exchange_markers.append(pair)

    marker_offset = line.find(deferred_gate_marker)
    if marker_offset >= 0:
        worker_rank = last_worker_rank_before(line, marker_offset)
        detail = deferred_gate_detail_re.search(line[marker_offset:])
        if worker_rank is None or detail is None:
            malformed.append((line_number, "vsa-deferred-gate", line))
        else:
            marker_rank = int(detail.group(1))
            if worker_rank != marker_rank:
                malformed.append(
                    (line_number, "vsa-deferred-gate-rank-mismatch", line)
                )
            else:
                deferred_gate_ranks.append(marker_rank)

    marker_offset = line.find(deferred_gate_producer_marker)
    if marker_offset >= 0:
        worker_rank = last_worker_rank_before(line, marker_offset)
        if worker_rank is None:
            malformed.append((line_number, "vsa-deferred-gate-producer", line))
        else:
            deferred_gate_producer_ranks.append(worker_rank)

    marker_offset = line.find(o_bundle_producer_marker)
    if marker_offset >= 0:
        worker_rank = last_worker_rank_before(line, marker_offset)
        detail = o_bundle_producer_detail_re.search(line[marker_offset:])
        if worker_rank is None or detail is None:
            malformed.append((line_number, "vsa-o-bundle-producer", line))
        else:
            o_bundle_producer_ranks.append(worker_rank)

    marker_offset = line.find(o_bundle_consumer_marker)
    if marker_offset >= 0:
        worker_rank = last_worker_rank_before(line, marker_offset)
        detail = o_bundle_consumer_detail_re.search(line[marker_offset:])
        if worker_rank is None or detail is None:
            malformed.append((line_number, "vsa-o-bundle-consumer", line))
        else:
            marker_rank = int(detail.group(1))
            if worker_rank != marker_rank:
                malformed.append(
                    (line_number, "vsa-o-bundle-consumer-rank-mismatch", line)
                )
            else:
                o_bundle_consumer_ranks.append(marker_rank)

    marker_offset = line.find(release_marker)
    if marker_offset >= 0:
        worker_rank = last_worker_rank_before(line, marker_offset)
        if worker_rank is None:
            malformed.append((line_number, "post-denoise-release", line))
        else:
            release_ranks.append(worker_rank)

    marker_offset = line.find(reclaim_marker)
    if marker_offset >= 0:
        worker_rank = last_worker_rank_before(line, marker_offset)
        detail = reclaim_detail_re.search(line[marker_offset:])
        if worker_rank is None or detail is None:
            malformed.append((line_number, "re-arm-reclaim", line))
        else:
            marker_rank, group, device = int(detail.group(1)), detail.group(2), int(detail.group(3))
            if worker_rank != marker_rank or marker_rank != device:
                malformed.append((line_number, "re-arm-reclaim-rank-mismatch", line))
            else:
                reclaim_markers.append((marker_rank, group))

armed_groups = {item[1] for item in armed}
armed_rank_groups = {(item[0], item[1]) for item in armed}
expected_armed_without_group = {
    (rank, 8, rank, expected_transport, expected_capacity)
    for rank in range(8)
}
armed_without_group = {
    (rank, world, device, transport, capacity)
    for rank, _group, world, device, transport, capacity in armed
}
adapter_failures = [
    (line_number, line)
    for line_number, line in enumerate(lines, 1)
    if adapter_failure_re.search(line)
]

problems = []
if armed_without_group != expected_armed_without_group:
    problems.append(
        "armed rank/device tuples differ: "
        f"missing={sorted(expected_armed_without_group - armed_without_group)!r}, "
        f"unexpected={sorted(armed_without_group - expected_armed_without_group)!r}"
    )
if len(armed_groups) != 1:
    problems.append(f"armed markers do not share exactly one group: {sorted(armed_groups)!r}")
if malformed:
    problems.append(f"malformed adapter markers at lines={[item[0] for item in malformed]!r}")
if adapter_failures:
    problems.append(
        f"adapter-specific failure evidence at lines={[item[0] for item in adapter_failures]!r}"
    )
qk_ranks = {item[0] for item in qk_exchanges}
qk_groups = {item[1] for item in qk_exchanges}
qk_marker_counts = {
    rank: sum(marker_rank == rank for marker_rank, _group in qk_exchange_markers)
    for rank in range(8)
}
qkv_e4m3_ranks = {item[0] for item in qkv_e4m3_exchanges}
qkv_e4m3_groups = {item[1] for item in qkv_e4m3_exchanges}
qkv_e4m3_marker_counts = {
    rank: sum(marker_rank == rank for marker_rank, _group in qkv_e4m3_exchange_markers)
    for rank in range(8)
}
qkv_e4m3_install_marker_counts = {
    rank: sum(item[0] == rank for item in qkv_e4m3_install_markers)
    for rank in range(8)
}
qkv_e4m3_receive_marker_counts = {
    rank: qkv_e4m3_receive_ranks.count(rank) for rank in range(8)
}
expected_once_per_rank = {rank: 1 for rank in range(8)}
if require_qk_direct and not require_qkv_e4m3 and qk_exchanges != armed_rank_groups:
    problems.append(
        "Q/K producer-direct exchange rank/group tuples differ: "
        f"missing={sorted(armed_rank_groups - qk_exchanges)!r}, "
        f"unexpected={sorted(qk_exchanges - armed_rank_groups)!r}"
    )
if require_qk_direct and not require_qkv_e4m3:
    expected_qk_count = 8 if not require_release_after_denoise else None
    if expected_qk_count is not None and len(qk_exchange_markers) != expected_qk_count:
        problems.append(
            "Q/K producer-direct exchange must emit exactly one marker per rank; "
            f"observed={len(qk_exchange_markers)}"
        )
    if require_release_after_denoise and (
        len(qk_exchange_markers) < 8
        or len(qk_exchange_markers) % 8 != 0
        or len(set(qk_marker_counts.values())) != 1
    ):
        problems.append(
            "Q/K producer-direct re-arm markers must be balanced across eight ranks; "
            f"counts={qk_marker_counts!r}"
        )
elif qk_exchange_markers:
    problems.append(
        "BF16 Q/K producer-direct markers appeared while that route was disabled; "
        f"counts={qk_marker_counts!r}"
    )
if require_qkv_e4m3:
    if not require_qk_direct:
        problems.append("E4M3 Q/K/V producer-direct requires the Q/K-direct route contract")
    if qkv_e4m3_exchanges != armed_rank_groups:
        problems.append(
            "E4M3 Q/K/V producer-direct rank/group tuples differ: "
            f"missing={sorted(armed_rank_groups - qkv_e4m3_exchanges)!r}, "
            f"unexpected={sorted(qkv_e4m3_exchanges - armed_rank_groups)!r}"
        )
    if require_release_after_denoise:
        if (
            len(qkv_e4m3_exchange_markers) < 8
            or len(qkv_e4m3_exchange_markers) % 8 != 0
            or len(set(qkv_e4m3_marker_counts.values())) != 1
        ):
            problems.append(
                "E4M3 Q/K/V producer-direct re-arm markers must be balanced across eight ranks; "
                f"counts={qkv_e4m3_marker_counts!r}"
            )
    elif qkv_e4m3_marker_counts != expected_once_per_rank:
        problems.append(
            "persistent E4M3 Q/K/V producer-direct must emit exactly one marker per rank; "
            f"counts={qkv_e4m3_marker_counts!r}"
        )
    if qkv_e4m3_install_marker_counts != expected_once_per_rank:
        problems.append(
            "E4M3 QKV sidecar install must emit exactly one marker per rank; "
            f"counts={qkv_e4m3_install_marker_counts!r}"
        )
    for rank, provider, abi, payload_sha256, scale_min, scale_max in qkv_e4m3_install_markers:
        if provider != "flashinfer-pr4944-cutedsl-sm120":
            problems.append(f"rank {rank} installed unexpected E4M3 QKV provider {provider!r}")
        if abi != "minimax-h3-vsa-qkv-e4m3-bf16-o-v1":
            problems.append(f"rank {rank} installed unexpected E4M3 QKV ABI {abi!r}")
        if payload_sha256 != expected_qkv_payload_sha256:
            problems.append(
                f"rank {rank} installed E4M3 QKV payload {payload_sha256!r}, "
                f"expected {expected_qkv_payload_sha256!r}"
            )
        if not (0.0 < scale_min <= scale_max < float("inf")):
            problems.append(
                f"rank {rank} installed invalid E4M3 QKV scale range "
                f"[{scale_min!r}, {scale_max!r}]"
            )
    if qkv_e4m3_receive_marker_counts != expected_once_per_rank:
        problems.append(
            "E4M3 QKV fused receive/dequant must emit exactly one marker per rank; "
            f"counts={qkv_e4m3_receive_marker_counts!r}"
        )
else:
    if qkv_e4m3_exchange_markers:
        problems.append(
            "E4M3 Q/K/V producer-direct markers appeared while disabled; "
            f"counts={qkv_e4m3_marker_counts!r}"
        )
    if qkv_e4m3_install_markers:
        problems.append(
            "E4M3 QKV sidecar-install markers appeared while disabled; "
            f"counts={qkv_e4m3_install_marker_counts!r}"
        )
    if qkv_e4m3_receive_ranks:
        problems.append(
            "E4M3 QKV fused receive/dequant markers appeared while disabled; "
            f"counts={qkv_e4m3_receive_marker_counts!r}"
        )
o_direct_marker_counts = {
    rank: sum(marker_rank == rank for marker_rank, _group in o_direct_exchange_markers)
    for rank in range(8)
}
if require_o_direct and o_direct_exchanges != armed_rank_groups:
    problems.append(
        "O producer-direct rank/group tuples differ from armed communicator: "
        f"missing={sorted(armed_rank_groups - o_direct_exchanges)!r}, "
        f"unexpected={sorted(o_direct_exchanges - armed_rank_groups)!r}"
    )
if require_o_direct and require_release_after_denoise and (
    len(o_direct_exchange_markers) < 8
    or len(o_direct_exchange_markers) % 8 != 0
    or len(set(o_direct_marker_counts.values())) != 1
):
    problems.append(
        "O producer-direct re-arm markers must be balanced across eight ranks; "
        f"counts={o_direct_marker_counts!r}"
    )
if require_o_direct and not require_release_after_denoise and (
    len(o_direct_exchange_markers) != 8
    or o_direct_marker_counts != {rank: 1 for rank in range(8)}
):
    problems.append(
        "persistent O producer-direct must emit exactly one marker per rank; "
        f"counts={o_direct_marker_counts!r}"
    )
if not require_o_direct and o_direct_exchange_markers:
    problems.append("O producer-direct active markers appeared while disabled")
if o_direct_fallbacks:
    problems.append(
        "O producer-direct emitted fallback evidence at "
        f"lines={[item[0] for item in o_direct_fallbacks]!r}"
    )
if require_vsa_gate and gate_exchanges != armed_rank_groups:
    problems.append(
        "VSA gate exchange rank/group tuples differ: "
        f"missing={sorted(armed_rank_groups - gate_exchanges)!r}, "
        f"unexpected={sorted(gate_exchanges - armed_rank_groups)!r}"
    )
if require_vsa_gate and len(gate_exchange_markers) != 8:
    problems.append(
        "VSA gate exchange must emit exactly one marker per rank; "
        f"observed={len(gate_exchange_markers)}"
    )
if not require_vsa_gate and gate_exchange_markers:
    problems.append(
        "VSA full gate exchange active markers appeared while disabled; "
        f"observed={len(gate_exchange_markers)}"
    )
deferred_gate_marker_counts = {
    rank: deferred_gate_ranks.count(rank) for rank in range(8)
}
deferred_gate_producer_marker_counts = {
    rank: deferred_gate_producer_ranks.count(rank) for rank in range(8)
}
expected_deferred_gate_marker_counts = {rank: 1 for rank in range(8)}
if require_vsa_deferred_gate:
    if deferred_gate_marker_counts != expected_deferred_gate_marker_counts:
        problems.append(
            "deferred VSA gate consumer must emit exactly one marker per rank; "
            f"observed={deferred_gate_marker_counts!r}"
        )
    if require_vsa_gate:
        problems.append("deferred VSA gate cannot require the full gate exchange")
elif deferred_gate_ranks:
    problems.append(
        "deferred VSA gate consumer active markers appeared while disabled; "
        f"counts={deferred_gate_marker_counts!r}"
    )
o_bundle_producer_marker_counts = {
    rank: o_bundle_producer_ranks.count(rank) for rank in range(8)
}
o_bundle_consumer_marker_counts = {
    rank: o_bundle_consumer_ranks.count(rank) for rank in range(8)
}
expected_o_bundle_marker_counts = {rank: 1 for rank in range(8)}
if require_vsa_o_bundle:
    if o_bundle_producer_marker_counts != expected_o_bundle_marker_counts:
        problems.append(
            "reverse-O VSA bundle producer must emit exactly one marker per rank; "
            f"observed={o_bundle_producer_marker_counts!r}"
        )
    if o_bundle_consumer_marker_counts != expected_o_bundle_marker_counts:
        problems.append(
            "reverse-O VSA bundle consumer must emit exactly one marker per rank; "
            f"observed={o_bundle_consumer_marker_counts!r}"
        )
    if require_vsa_gate:
        problems.append("reverse-O VSA bundle cannot require the full gate exchange")
    if require_vsa_deferred_gate:
        problems.append("reverse-O VSA bundle cannot require deferred compact-coarse all-gather")
    if not require_o_direct:
        problems.append("reverse-O VSA bundle requires O producer-direct exchange")
    if gate_exchange_markers:
        problems.append("reverse-O VSA bundle emitted forbidden full gate exchange markers")
    if deferred_gate_ranks or deferred_gate_producer_ranks:
        problems.append(
            "reverse-O VSA bundle emitted forbidden compact-coarse collective markers; "
            f"producer={deferred_gate_producer_marker_counts!r}, "
            f"consumer={deferred_gate_marker_counts!r}"
        )
elif o_bundle_producer_ranks or o_bundle_consumer_ranks:
    problems.append(
        "reverse-O VSA bundle active markers appeared while disabled; "
        f"producer={o_bundle_producer_marker_counts!r}, "
        f"consumer={o_bundle_consumer_marker_counts!r}"
    )
release_marker_counts = {rank: release_ranks.count(rank) for rank in range(8)}
reclaim_marker_counts = {
    rank: sum(marker_rank == rank for marker_rank, _group in reclaim_markers)
    for rank in range(8)
}
armed_marker_counts = {
    rank: sum(marker_rank == rank for marker_rank, *_rest in armed_markers)
    for rank in range(8)
}
if require_o_direct and o_direct_marker_counts != armed_marker_counts:
    problems.append(
        "O producer-direct count must match communicator arm count per rank; "
        f"o_direct={o_direct_marker_counts!r}, armed={armed_marker_counts!r}"
    )
if require_qkv_e4m3 and qkv_e4m3_marker_counts != armed_marker_counts:
    problems.append(
        "E4M3 Q/K/V producer-direct count must match communicator arm count per rank; "
        f"qkv_e4m3={qkv_e4m3_marker_counts!r}, armed={armed_marker_counts!r}"
    )
if (
    require_o_direct
    and require_release_after_denoise
    and o_direct_marker_counts != release_marker_counts
):
    problems.append(
        "O producer-direct count must match release count per rank; "
        f"o_direct={o_direct_marker_counts!r}, release={release_marker_counts!r}"
    )
if require_release_after_denoise:
    if (
        len(armed_markers) < 8
        or len(armed_markers) % 8 != 0
        or len(set(armed_marker_counts.values())) != 1
    ):
        problems.append(
            "communicator arm markers must be balanced across eight ranks in release mode; "
            f"counts={armed_marker_counts!r}"
        )
    if (
        len(release_ranks) < 8
        or len(release_ranks) % 8 != 0
        or len(set(release_marker_counts.values())) != 1
    ):
        problems.append(
            "post-denoise release markers must be balanced across eight ranks; "
            f"counts={release_marker_counts!r}"
        )
    if armed_marker_counts != release_marker_counts:
        problems.append(
            "each release-mode request must have exactly one communicator arm and release per rank; "
            f"armed={armed_marker_counts!r}, release={release_marker_counts!r}"
        )
    if require_qkv_e4m3 and release_marker_counts != qkv_e4m3_marker_counts:
        problems.append(
            "post-denoise release count must match E4M3 Q/K/V lazy re-arm count per rank; "
            f"release={release_marker_counts!r}, qkv_e4m3={qkv_e4m3_marker_counts!r}"
        )
    if require_qk_direct and not require_qkv_e4m3 and release_marker_counts != qk_marker_counts:
        problems.append(
            "post-denoise release count must match Q/K lazy re-arm count per rank; "
            f"release={release_marker_counts!r}, qk={qk_marker_counts!r}"
        )
    expected_reclaim_counts = {
        rank: max(armed_marker_counts[rank] - 1, 0)
        for rank in range(8)
    }
    if reclaim_marker_counts != expected_reclaim_counts:
        problems.append(
            "post-VAE allocator reclaim count must match each communicator re-arm after the first arm; "
            f"observed={reclaim_marker_counts!r}, expected={expected_reclaim_counts!r}"
        )
    unexpected_reclaim_groups = {
        pair for pair in reclaim_markers if pair not in armed_rank_groups
    }
    if unexpected_reclaim_groups:
        problems.append(
            "post-VAE allocator reclaim rank/group tuples differ from armed communicator: "
            f"unexpected={sorted(unexpected_reclaim_groups)!r}"
        )
else:
    expected_persistent_arm_counts = {rank: 1 for rank in range(8)}
    if armed_marker_counts != expected_persistent_arm_counts:
        problems.append(
            "persistent communicator must arm exactly once per rank for the full server lifetime; "
            f"observed={armed_marker_counts!r}, expected={expected_persistent_arm_counts!r}"
        )
    if release_ranks:
        problems.append(
            "persistent communicator emitted unexpected post-denoise release markers; "
            f"counts={release_marker_counts!r}"
        )
    if reclaim_markers:
        problems.append(
            "persistent communicator emitted unexpected re-arm reclaim markers; "
            f"counts={reclaim_marker_counts!r}"
        )

report = [
    "required_backend=flashinfer-pcie",
    f"required_transport={expected_transport}",
    f"required_capacity={expected_capacity}",
    f"armed_unique_rank_count={len({item[0] for item in armed})}",
    f"armed_unique_device_count={len({item[3] for item in armed})}",
    f"armed_unique_groups={','.join(sorted(armed_groups))}",
    f"armed_unique_tuple_count={len(armed)}",
    f"armed_marker_count={len(armed_markers)}",
]
for item in sorted(armed):
    report.append(
        "armed_tuple="
        f"rank={item[0]},group={item[1]},world={item[2]},device=cuda:{item[3]},"
        f"transport={item[4]},capacity={item[5]}"
    )
for rank in range(8):
    report.append(f"armed_rank_count=rank={rank},count={armed_marker_counts[rank]}")
report.append(f"qk_producer_direct_required={int(require_qk_direct)}")
report.append(f"qk_producer_direct_unique_ranks={','.join(map(str, sorted(qk_ranks)))}")
report.append(f"qk_producer_direct_groups={','.join(sorted(qk_groups))}")
report.append(f"qk_exchange_marker_count={len(qk_exchange_markers)}")
report.append(f"qk_exchange_unique_tuple_count={len(qk_exchanges)}")
for rank, group in sorted(qk_exchanges):
    report.append(f"qk_exchange_tuple=rank={rank},group={group}")
for rank in range(8):
    report.append(f"qk_exchange_rank_count=rank={rank},count={qk_marker_counts[rank]}")
report.append(f"legacy_qk_landing_marker_count={legacy_qk_landing_marker_count}")
report.append(f"qkv_e4m3_required={int(require_qkv_e4m3)}")
report.append(
    f"qkv_e4m3_exchange_unique_ranks={','.join(map(str, sorted(qkv_e4m3_ranks)))}"
)
report.append(f"qkv_e4m3_exchange_groups={','.join(sorted(qkv_e4m3_groups))}")
report.append(f"qkv_e4m3_exchange_marker_count={len(qkv_e4m3_exchange_markers)}")
report.append(f"qkv_e4m3_exchange_unique_tuple_count={len(qkv_e4m3_exchanges)}")
for rank, group in sorted(qkv_e4m3_exchanges):
    report.append(f"qkv_e4m3_exchange_tuple=rank={rank},group={group}")
for rank in range(8):
    report.append(
        f"qkv_e4m3_exchange_rank_count=rank={rank},"
        f"count={qkv_e4m3_marker_counts[rank]}"
    )
report.append(f"qkv_e4m3_sidecar_install_marker_count={len(qkv_e4m3_install_markers)}")
for rank, provider, abi, payload_sha256, scale_min, scale_max in qkv_e4m3_install_markers:
    report.append(
        "qkv_e4m3_sidecar_install="
        f"rank={rank},provider={provider},abi={abi},payload_sha256={payload_sha256},"
        f"scale_min={scale_min},scale_max={scale_max}"
    )
for rank in range(8):
    report.append(
        f"qkv_e4m3_sidecar_install_rank_count=rank={rank},"
        f"count={qkv_e4m3_install_marker_counts[rank]}"
    )
report.append(f"qkv_e4m3_receive_marker_count={len(qkv_e4m3_receive_ranks)}")
for rank in range(8):
    report.append(
        f"qkv_e4m3_receive_rank_count=rank={rank},"
        f"count={qkv_e4m3_receive_marker_counts[rank]}"
    )
report.append(f"o_producer_direct_required={int(require_o_direct)}")
report.append(
    f"o_producer_direct_active_marker_count={len(o_direct_exchange_markers)}"
)
report.append(
    f"o_producer_direct_active_unique_tuple_count={len(o_direct_exchanges)}"
)
for rank, group in sorted(o_direct_exchanges):
    report.append(f"o_producer_direct_active_tuple=rank={rank},group={group}")
for rank in range(8):
    report.append(
        f"o_producer_direct_active_rank_count=rank={rank},"
        f"count={o_direct_marker_counts[rank]}"
    )
report.append(
    f"o_producer_direct_fallback_marker_count={len(o_direct_fallbacks)}"
)
for line_number, line in o_direct_fallbacks:
    report.append(f"o_producer_direct_fallback={line_number}:{line}")
report.append(f"vsa_gate_required={int(require_vsa_gate)}")
report.append(f"vsa_gate_exchange_marker_count={len(gate_exchange_markers)}")
report.append(f"vsa_gate_exchange_unique_tuple_count={len(gate_exchanges)}")
for rank, group in sorted(gate_exchanges):
    report.append(f"vsa_gate_exchange_tuple=rank={rank},group={group}")
report.append(f"vsa_deferred_gate_required={int(require_vsa_deferred_gate)}")
report.append(
    f"vsa_deferred_gate_producer_marker_count={len(deferred_gate_producer_ranks)}"
)
report.append(f"vsa_deferred_gate_consumer_marker_count={len(deferred_gate_ranks)}")
for rank in range(8):
    report.append(
        f"vsa_deferred_gate_producer_rank_count=rank={rank},"
        f"count={deferred_gate_producer_marker_counts[rank]}"
    )
    report.append(
        f"vsa_deferred_gate_consumer_rank_count=rank={rank},"
        f"count={deferred_gate_marker_counts[rank]}"
    )
report.append(f"vsa_o_bundle_required={int(require_vsa_o_bundle)}")
report.append(f"vsa_o_bundle_producer_marker_count={len(o_bundle_producer_ranks)}")
report.append(f"vsa_o_bundle_consumer_marker_count={len(o_bundle_consumer_ranks)}")
report.append(f"vsa_o_bundle_forbidden_full_gate_marker_count={len(gate_exchange_markers)}")
report.append(
    "vsa_o_bundle_forbidden_compact_coarse_producer_marker_count="
    f"{len(deferred_gate_producer_ranks)}"
)
report.append(
    "vsa_o_bundle_forbidden_compact_coarse_consumer_marker_count="
    f"{len(deferred_gate_ranks)}"
)
for rank in range(8):
    report.append(
        f"vsa_o_bundle_producer_rank_count=rank={rank},"
        f"count={o_bundle_producer_marker_counts[rank]}"
    )
    report.append(
        f"vsa_o_bundle_consumer_rank_count=rank={rank},"
        f"count={o_bundle_consumer_marker_counts[rank]}"
    )
report.append(f"post_denoise_release_required={int(require_release_after_denoise)}")
report.append(
    "communicator_lifecycle_mode="
    + ("release-after-denoise" if require_release_after_denoise else "persistent")
)
report.append(f"post_denoise_release_marker_count={len(release_ranks)}")
for rank in range(8):
    report.append(f"post_denoise_release_rank_count=rank={rank},count={release_marker_counts[rank]}")
report.append(f"post_vae_rearm_reclaim_marker_count={len(reclaim_markers)}")
for rank in range(8):
    report.append(f"post_vae_rearm_reclaim_rank_count=rank={rank},count={reclaim_marker_counts[rank]}")
for line_number, kind, line in malformed:
    report.append(f"malformed_marker={line_number}:{kind}:{line}")
for line_number, line in adapter_failures:
    report.append(f"adapter_failure={line_number}:{line}")
for problem in problems:
    report.append(f"validation_error={problem}")
report.append(f"validation_status={'failed' if problems else 'ok'}")
report_path.write_text("\n".join(report) + "\n", encoding="utf-8")

if problems:
    raise SystemExit("; ".join(problems))
PY
    then
      echo "FlashInfer PCIe ${FLASHINFER_ULYSSES_ROUTE} validation failed; see $rdma_validation" >&2
      cat "$rdma_validation" >&2 || true
      return 1
    fi
  fi
}

prepare_qkv_transport_formal_runtime_identity() {
  [[ "$QKV_E4M3_TRANSPORT" == 1 ]] || return 0
  local case_dir=$1
  local adapter_source_output metadata_root manifest_default
  local manifest_digest_output manifest_digest_log
  local -a adapter_source_lines=()
  local -a manifest_digest_lines=()
  [[ -n "$FASTH3_ADALN_BINDING_JSON" ]] || die \
    "Formal QKV transport requires a prevalidated adapter-bound AdaLN sidecar"

  adapter_source_output="$(
    ADALN_BINDING_JSON="$FASTH3_ADALN_BINDING_JSON" "$PYTHON" - <<'PY'
import json
import os

from vllm_omni.diffusion.models.minimax_h3.adaln_cache import (
    MiniMaxH3AdalnCacheBinding,
)

binding = MiniMaxH3AdalnCacheBinding.from_dict(
    json.loads(os.environ["ADALN_BINDING_JSON"])
)
adapter = binding.fasth3_adapter
if adapter is None:
    raise SystemExit("QKV runtime identity requires a FastH3 adapter identity")
header = json.loads(adapter.header_identity)
if not isinstance(header, dict):
    raise SystemExit("FastH3 adapter header identity must be a JSON object")
revision = header.get("base_revision")
if not isinstance(revision, str) or len(revision) != 40:
    raise SystemExit("FastH3 adapter header base_revision is not a canonical git revision")
try:
    int(revision, 16)
except ValueError as exc:
    raise SystemExit("FastH3 adapter header base_revision is not hexadecimal") from exc
print(f"MINIMAX_H3_QKV_SOURCE_MODEL_REVISION={revision.lower()}")
PY
  )" || die "Failed to establish the QKV source-model revision from the adapter"
  mapfile -t adapter_source_lines < <(
    printf '%s\n' "$adapter_source_output" | sed -n \
      's/^MINIMAX_H3_QKV_SOURCE_MODEL_REVISION=\([0-9a-f]\{40\}\)$/\1/p'
  )
  (( ${#adapter_source_lines[@]} == 1 )) || die \
    "FastH3 adapter validation emitted no unique source-model revision"
  QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION="${adapter_source_lines[0]}"
  [[ "$QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION" == \
        "$QKV_E4M3_SOURCE_MODEL_REVISION" ]] || die \
    "FastH3 adapter base revision differs from the pinned QKV source-model revision"

  metadata_root="$(dirname -- "$MODEL")/.cache/huggingface/download/$(basename -- "$MODEL")"
  QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION="$(
    RUNTIME_ROOT="$MODEL" RUNTIME_METADATA_ROOT="$metadata_root" "$PYTHON" - <<'PY'
from pathlib import Path
import os

runtime_root = Path(os.environ["RUNTIME_ROOT"]).resolve()
metadata_root = Path(os.environ["RUNTIME_METADATA_ROOT"]).resolve()
relative_paths = [Path("model_index.json")]
for directory_name in ("processor", "tokenizer", "text_encoder", "transformer"):
    directory = runtime_root / directory_name
    if not directory.is_dir():
        raise SystemExit(f"runtime checkpoint is missing {directory_name}/")
    relative_paths.extend(
        path.relative_to(runtime_root)
        for path in directory.rglob("*")
        if path.is_file() and ".cache" not in path.relative_to(runtime_root).parts
    )

revisions = set()
for relative_path in relative_paths:
    metadata_path = metadata_root / f"{relative_path.as_posix()}.metadata"
    if not metadata_path.is_file():
        raise SystemExit(f"runtime checkpoint is missing Hugging Face revision metadata: {metadata_path}")
    lines = metadata_path.read_text(encoding="utf-8").splitlines()
    if not lines:
        raise SystemExit(f"empty Hugging Face revision metadata: {metadata_path}")
    revision = lines[0].strip().lower()
    if len(revision) != 40:
        raise SystemExit(f"invalid runtime checkpoint revision in {metadata_path}")
    try:
        int(revision, 16)
    except ValueError as exc:
        raise SystemExit(f"non-hex runtime checkpoint revision in {metadata_path}") from exc
    revisions.add(revision)
if len(revisions) != 1:
    raise SystemExit(f"runtime checkpoint files have mixed revisions: {sorted(revisions)}")
print(revisions.pop())
PY
  )" || die "Failed to establish one formal QKV runtime checkpoint revision"

  manifest_default="$WORKSPACE_DIR/cache/minimax-h3-fl2va-${QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION:0:12}-qkv-input-conditioning-v1.manifest.json"
  QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH="${VLLM_OMNI_MINIMAX_H3_QKV_RUNTIME_CHECKPOINT_MANIFEST_PATH:-$manifest_default}"
  [[ "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH" == /* ]] || die \
    "VLLM_OMNI_MINIMAX_H3_QKV_RUNTIME_CHECKPOINT_MANIFEST_PATH must be absolute"
  [[ -f "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH" ]] || die \
    "Formal QKV transport requires the calibration runtime manifest: $QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH"
  manifest_digest_log="$case_dir/qkv-runtime-checkpoint-manifest-digest.log"
  manifest_digest_output="$(
    QKV_RUNTIME_MANIFEST_PATH="$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH" \
      "$PYTHON" - <<'PY'
import os
from vllm_omni.diffusion.models.minimax_h3.qkv_transport_scales import (
    read_minimax_h3_runtime_checkpoint_manifest,
)

digest = read_minimax_h3_runtime_checkpoint_manifest(
    os.environ["QKV_RUNTIME_MANIFEST_PATH"]
)
print(f"MINIMAX_H3_QKV_RUNTIME_MANIFEST_SHA256={digest}")
PY
  )" || die "Formal QKV runtime checkpoint manifest failed strict validation"
  printf '%s\n' "$manifest_digest_output" >"$manifest_digest_log"
  mapfile -t manifest_digest_lines < <(
    printf '%s\n' "$manifest_digest_output" | sed -n \
      's/^MINIMAX_H3_QKV_RUNTIME_MANIFEST_SHA256=\([0-9a-f]\{64\}\)$/\1/p'
  )
  (( ${#manifest_digest_lines[@]} == 1 )) || die \
    "Formal QKV runtime manifest emitted no unique canonical digest; inspect $manifest_digest_log"
  QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256="${manifest_digest_lines[0]}"
}

prepare_qkv_transport_observer_contract() {
  [[ "$QKV_TRANSPORT_OBSERVER_MODE" != disabled ]] || return 0
  local case_dir=$1
  local metadata_root manifest_build_log manifest_default manifest_file_sha
  local manifest_digest_output manifest_digest_log
  local -a manifest_digest_lines=()
  local inherited_fields inherited_source_revision inherited_runtime_revision
  local inherited_manifest_sha inherited_campaign_uuid inherited_contract_sha
  local inherited_expected_observations contract_sha

  QKV_TRANSPORT_OBSERVER_EXECUTION_UUID="$(
    "$PYTHON" -c 'import uuid; print(uuid.uuid4())'
  )" || die "Failed to generate the QKV observer execution UUID"
  [[ "$QKV_TRANSPORT_OBSERVER_EXECUTION_UUID" =~ ^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$ ]] || die \
    "QKV observer execution UUID is not canonical UUIDv4"

  metadata_root="$(dirname -- "$MODEL")/.cache/huggingface/download/$(basename -- "$MODEL")"
  QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION="$(
    RUNTIME_ROOT="$MODEL" RUNTIME_METADATA_ROOT="$metadata_root" "$PYTHON" - <<'PY'
from pathlib import Path
import os

runtime_root = Path(os.environ["RUNTIME_ROOT"]).resolve()
metadata_root = Path(os.environ["RUNTIME_METADATA_ROOT"]).resolve()
relative_paths = [Path("model_index.json")]
for directory_name in ("processor", "tokenizer", "text_encoder", "transformer"):
    directory = runtime_root / directory_name
    if not directory.is_dir():
        raise SystemExit(f"runtime checkpoint is missing {directory_name}/")
    relative_paths.extend(
        path.relative_to(runtime_root)
        for path in directory.rglob("*")
        if path.is_file() and ".cache" not in path.relative_to(runtime_root).parts
    )

revisions = set()
for relative_path in relative_paths:
    metadata_path = metadata_root / f"{relative_path.as_posix()}.metadata"
    if not metadata_path.is_file():
        raise SystemExit(f"runtime checkpoint is missing Hugging Face revision metadata: {metadata_path}")
    lines = metadata_path.read_text(encoding="utf-8").splitlines()
    if not lines:
        raise SystemExit(f"empty Hugging Face revision metadata: {metadata_path}")
    revision = lines[0].strip().lower()
    if len(revision) != 40:
        raise SystemExit(f"invalid runtime checkpoint revision in {metadata_path}")
    try:
        int(revision, 16)
    except ValueError as exc:
        raise SystemExit(f"non-hex runtime checkpoint revision in {metadata_path}") from exc
    revisions.add(revision)
if len(revisions) != 1:
    raise SystemExit(f"runtime checkpoint files have mixed revisions: {sorted(revisions)}")
print(revisions.pop())
PY
  )" || die "Failed to establish one runtime checkpoint revision"
  QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION="$QKV_E4M3_SOURCE_MODEL_REVISION"

  manifest_default="$WORKSPACE_DIR/cache/minimax-h3-fl2va-${QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION:0:12}-qkv-input-conditioning-v1.manifest.json"
  QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH="${VLLM_OMNI_MINIMAX_H3_QKV_RUNTIME_CHECKPOINT_MANIFEST_PATH:-$manifest_default}"
  [[ "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH" == /* ]] || die \
    "VLLM_OMNI_MINIMAX_H3_QKV_RUNTIME_CHECKPOINT_MANIFEST_PATH must be absolute"
  manifest_build_log="$case_dir/qkv-runtime-checkpoint-manifest-builder.log"
  if [[ ! -e "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH" ]]; then
    [[ "$QKV_TRANSPORT_OBSERVER_MODE" == calibration ]] || die \
      "QKV validation requires the calibration campaign runtime manifest: $QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH"
    mkdir -p "$(dirname -- "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH")"
    "$PYTHON" "$QKV_TRANSPORT_SCALE_BUILDER" manifest \
      --runtime-root "$MODEL" \
      --output "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH" \
      >"$manifest_build_log" 2>&1 || {
        cat "$manifest_build_log" >&2 || true
        die "Failed to build the QKV input-conditioning runtime checkpoint manifest"
      }
  else
    [[ -f "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH" ]] || die \
      "QKV runtime checkpoint manifest path is not a regular file"
    printf 'Reusing immutable runtime checkpoint manifest: %s\n' \
      "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH" >"$manifest_build_log"
  fi
  manifest_digest_log="$case_dir/qkv-runtime-checkpoint-manifest-digest.log"
  manifest_digest_output="$(
    QKV_RUNTIME_MANIFEST_PATH="$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH" \
      "$PYTHON" - <<'PY'
import os
from vllm_omni.diffusion.models.minimax_h3.qkv_transport_scales import (
    read_minimax_h3_runtime_checkpoint_manifest,
)

digest = read_minimax_h3_runtime_checkpoint_manifest(
    os.environ["QKV_RUNTIME_MANIFEST_PATH"]
)
print(f"MINIMAX_H3_QKV_RUNTIME_MANIFEST_SHA256={digest}")
PY
  )" || die "QKV runtime checkpoint manifest failed strict validation"
  printf '%s\n' "$manifest_digest_output" >"$manifest_digest_log"
  mapfile -t manifest_digest_lines < <(
    printf '%s\n' "$manifest_digest_output" | sed -n \
      's/^MINIMAX_H3_QKV_RUNTIME_MANIFEST_SHA256=\([0-9a-f]\{64\}\)$/\1/p'
  )
  (( ${#manifest_digest_lines[@]} == 1 )) || die \
    "QKV runtime checkpoint manifest validation emitted no unique canonical digest; inspect $manifest_digest_log"
  QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256="${manifest_digest_lines[0]}"
  [[ "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256" =~ ^[0-9a-f]{64}$ ]] || die \
    "QKV runtime checkpoint manifest digest is not canonical SHA256"
  manifest_file_sha="$(sha256sum "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH")"
  manifest_file_sha="${manifest_file_sha%% *}"

  if [[ "$QKV_TRANSPORT_OBSERVER_MODE" == validation ]]; then
    inherited_fields="$(
      QKV_VALIDATION_PROVENANCE_JSON="$QKV_TRANSPORT_OBSERVER_VALIDATION_PROVENANCE_JSON" \
        "$PYTHON" - <<'PY'
import json
import os

value = json.loads(os.environ["QKV_VALIDATION_PROVENANCE_JSON"])
keys = (
    "source_model_revision",
    "runtime_checkpoint_revision",
    "runtime_checkpoint_manifest_sha256",
    "campaign_uuid",
    "run_contract_sha256",
    "expected_observation_count",
)
if set(value) != set(keys):
    raise SystemExit("validation draft provenance fields are not exact")
print("\t".join(str(value[key]) for key in keys))
PY
    )" || die "Failed to parse validation draft provenance"
    IFS=$'\t' read -r inherited_source_revision inherited_runtime_revision \
      inherited_manifest_sha inherited_campaign_uuid inherited_contract_sha \
      inherited_expected_observations <<<"$inherited_fields"
    [[ "$inherited_source_revision" == "$QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION" ]] || die \
      "QKV validation source-model revision differs from calibration"
    [[ "$inherited_runtime_revision" == "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION" ]] || die \
      "QKV validation runtime-checkpoint revision differs from calibration"
    [[ "$inherited_manifest_sha" == "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256" ]] || die \
      "QKV validation runtime-checkpoint manifest differs from calibration"
    [[ "$inherited_expected_observations" == "$QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT" ]] || die \
      "QKV validation observation count differs from calibration"
    QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID="$inherited_campaign_uuid"
    QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256="$inherited_contract_sha"
  else
    QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID="$(
      "$PYTHON" -c 'import uuid; print(uuid.uuid4())'
    )" || die "Failed to generate the QKV calibration campaign UUID"
  fi
  [[ "$QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID" =~ ^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$ ]] || die \
    "QKV calibration campaign UUID is not canonical UUIDv4"

  QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_PATH="$case_dir/qkv-transport-observer-run-contract.json"
  contract_sha="$(
    QKV_CONTRACT_PATH="$QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_PATH" \
    QKV_CAMPAIGN_UUID="$QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID" \
    QKV_SOURCE_MODEL_REVISION="$QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION" \
    QKV_RUNTIME_CHECKPOINT_REVISION="$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION" \
    QKV_RUNTIME_MANIFEST_SHA256="$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256" \
    QKV_RUNTIME_MANIFEST_FILE_SHA256="$manifest_file_sha" \
    QKV_EXPECTED_OBSERVATIONS="$QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT" \
    QKV_ADALN_BINDING_JSON="$FASTH3_ADALN_BINDING_JSON" \
    QKV_ADALN_SIDECAR_PATH="$ADALN_CACHE" \
    QKV_FASTH3_ADAPTER_SHA256="$FASTH3_EXPECTED_SHA256" \
    QKV_FASTH3_ADAPTER_SIZE="$FASTH3_EXPECTED_SIZE" \
    QKV_RUNNER_SNAPSHOT="$RUNNER_SCRIPT_SNAPSHOT" \
    QKV_VLLM_SOURCE="$VLLM_SOURCE" \
    QKV_FLASHINFER_SOURCE="$FLASHINFER_VSA_ROOT" \
    QKV_FASTVIDEO_KERNEL_SOURCE="$FASTVIDEO_KERNEL_PYTHON" \
    QKV_GPU_ORDER="$GPU_ORDER" \
    QKV_DIT_QUANT_MODE="$MLP_FP8_DIT_QUANT_MODE" \
    QKV_FP8_SCOPE="$FP8_SCOPE" \
    QKV_FP8_CONFIG_SHA256="$MLP_FP8_CONFIG_SHA256" \
    QKV_FP8_CONTRACT_SHA256="$MLP_FP8_CONTRACT_SHA256" \
    QKV_FP8_CONTRACT_JSON="$MLP_FP8_CONTRACT_JSON" \
    QKV_PROMPT_SHA256="$QKV_E4M3_PROMPT_SHA256" \
    QKV_PREFIX_TILE_COUNT="$QKV_E4M3_PREFIX_TILE_COUNT" \
    QKV_COMPACT_ROW_COUNT="$QKV_E4M3_COMPACT_ROW_COUNT" \
    QKV_PADDED_ROW_COUNT="$QKV_E4M3_PADDED_ROW_COUNT" \
      "$PYTHON" - <<'PY'
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def selected_source_hashes(root: Path, relative_paths: tuple[str, ...]) -> dict[str, str]:
    result = {}
    for relative in relative_paths:
        path = root / relative
        if not path.is_file():
            raise SystemExit(f"QKV run-contract source is missing: {path}")
        result[relative] = sha256(path)
    return result


vllm_root = Path(os.environ["QKV_VLLM_SOURCE"]).resolve()
flashinfer_root = Path(os.environ["QKV_FLASHINFER_SOURCE"]).resolve()
fastvideo_kernel_root = Path(os.environ["QKV_FASTVIDEO_KERNEL_SOURCE"]).resolve()
adaln_path = Path(os.environ["QKV_ADALN_SIDECAR_PATH"]).resolve()
runner_path = Path(os.environ["QKV_RUNNER_SNAPSHOT"]).resolve()

vllm_sources = selected_source_hashes(
    vllm_root,
    (
        "tools/minimax_h3/build_qkv_transport_scales.py",
        "vllm_omni/diffusion/attention/backends/fastvideo_vsa.py",
        "vllm_omni/diffusion/attention/ops/minimax_h3_vsa_layout.py",
        "vllm_omni/diffusion/distributed/flashinfer_ulysses.py",
        "vllm_omni/diffusion/models/minimax_h3/minimax_h3_transformer.py",
        "vllm_omni/diffusion/models/minimax_h3/fp8_contract.py",
        "vllm_omni/diffusion/models/minimax_h3/pipeline_minimax_h3.py",
        "vllm_omni/diffusion/models/minimax_h3/qkv_transport_calibration.py",
        "vllm_omni/diffusion/models/minimax_h3/qkv_transport_scales.py",
    ),
)
flashinfer_sources = selected_source_hashes(
    flashinfer_root,
    tuple(
        path.relative_to(flashinfer_root).as_posix()
        for path in sorted((flashinfer_root / "flashinfer/cute_dsl/sparse").glob("*.py"))
    ),
)
fastvideo_sources = selected_source_hashes(
    fastvideo_kernel_root,
    (
        "fastvideo_kernel/__init__.py",
        "fastvideo_kernel/ops.py",
        "fastvideo_kernel/vsa_utils.py",
        "fastvideo_kernel/triton_kernels/fused_compress_topk.py",
    ),
)


def git_head(root: Path) -> str:
    result = subprocess.run(
        ["git", "-C", str(root), "rev-parse", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    )
    commit = result.stdout.strip().lower()
    if len(commit) != 40:
        raise SystemExit(f"invalid git HEAD for {root}: {commit!r}")
    int(commit, 16)
    return commit

execution_profile = {
    "framework": "vllm-omni",
    "tensor_parallel_size": 1,
    "sequence_parallel_size": 8,
    "text_encoder_tensor_parallel_size": 8,
    "vae_patch_parallel_size": 8,
    "gpu_architecture": "sm120",
    "physical_gpu_order": os.environ["QKV_GPU_ORDER"],
    "max_num_seqs": 1,
    "request_count": 1,
    "warmup_count": 0,
    "repeat_count": 1,
    "enforce_eager": True,
    "dit_quant_mode": os.environ["QKV_DIT_QUANT_MODE"],
    "vsa_topk": 162,
    "vsa_tile_size": 64,
    "vsa_kernel_provider": "flashinfer-pr4944-cutedsl-sm120",
    "vsa_kernel_abi": "minimax-h3-vsa-qkv-e4m3-bf16-o-v1",
    "ulysses_route": "rdma",
    "qk_producer_direct": True,
    "o_producer_direct": True,
    "qkv_live_e4m3_transport": False,
    "qkv_compute_dtype": "bfloat16",
    "qkv_wire_dtype": "bfloat16",
    "reverse_o_dtype": "bfloat16",
    "q_boundary": "post_qknorm_rope_bf16",
    "k_boundary": "post_qknorm_rope_bf16",
    "v_boundary": "projection_bf16",
}
if os.environ["QKV_FP8_SCOPE"] == "mlp":
    fp8_contract = json.loads(os.environ["QKV_FP8_CONTRACT_JSON"])
    execution_profile.update(
        {
            "fp8_scope": "mlp",
            "fp8_config_sha256": os.environ["QKV_FP8_CONFIG_SHA256"],
            "fp8_contract_sha256": os.environ["QKV_FP8_CONTRACT_SHA256"],
            "fp8_contract": fp8_contract,
        }
    )
elif os.environ["QKV_FP8_SCOPE"] == "mlp-out":
    fp8_contract = json.loads(os.environ["QKV_FP8_CONTRACT_JSON"])
    execution_profile.update(
        {
            "fp8_scope": "mlp-out",
            "fp8_config_sha256": os.environ["QKV_FP8_CONFIG_SHA256"],
            "fp8_contract_sha256": os.environ["QKV_FP8_CONTRACT_SHA256"],
            "fp8_contract": fp8_contract,
        }
    )
elif os.environ["QKV_FP8_SCOPE"] == "mlp-out-qkv":
    fp8_contract = json.loads(os.environ["QKV_FP8_CONTRACT_JSON"])
    execution_profile.update(
        {
            "fp8_scope": "mlp-out-qkv",
            "fp8_config_sha256": os.environ["QKV_FP8_CONFIG_SHA256"],
            "fp8_contract_sha256": os.environ["QKV_FP8_CONTRACT_SHA256"],
            "fp8_contract": fp8_contract,
            "qkv_projection_compute_dtype": "float8_e4m3fn",
            "qkv_projection_output_dtype": "bfloat16",
        }
    )
elif os.environ["QKV_FP8_SCOPE"] == "all-main":
    fp8_contract = json.loads(os.environ["QKV_FP8_CONTRACT_JSON"])
    execution_profile.update(
        {
            "fp8_scope": "all-main",
            "fp8_config_sha256": os.environ["QKV_FP8_CONFIG_SHA256"],
            "fp8_contract_sha256": os.environ["QKV_FP8_CONTRACT_SHA256"],
            "fp8_contract": fp8_contract,
            "qkv_projection_compute_dtype": "float8_e4m3fn",
            "qkv_projection_output_dtype": "bfloat16",
            "to_gate_compress_compute_dtype": "float8_e4m3fn",
            "to_gate_compress_output_dtype": "bfloat16",
        }
    )
elif os.environ["QKV_FP8_SCOPE"] != "none":
    raise SystemExit(
        "formal QKV observer supports only BF16 or an exact selective-FP8 contract"
    )

contract = {
    "artifact_type": "minimax-h3-qkv-transport-observer-run-contract",
    "format_version": "1",
    "campaign_uuid": os.environ["QKV_CAMPAIGN_UUID"],
    "calibration_provenance": {
        "source_model_revision": os.environ["QKV_SOURCE_MODEL_REVISION"],
        "runtime_checkpoint_revision": os.environ["QKV_RUNTIME_CHECKPOINT_REVISION"],
        "runtime_checkpoint_manifest_scope": "qkv-input-conditioning-v1",
        "runtime_checkpoint_manifest_sha256": os.environ["QKV_RUNTIME_MANIFEST_SHA256"],
        "runtime_checkpoint_manifest_file_sha256": os.environ[
            "QKV_RUNTIME_MANIFEST_FILE_SHA256"
        ],
        "expected_observation_count": int(os.environ["QKV_EXPECTED_OBSERVATIONS"]),
    },
    "model": {
        "base_model": "MiniMaxAI/MiniMax-H3",
        "model_variant": "fl2va",
        "mode": "t2va",
        "fasth3_variant": "vsa-datafree",
        "fasth3_adapter": {
            "sha256": os.environ["QKV_FASTH3_ADAPTER_SHA256"],
            "size_bytes": int(os.environ["QKV_FASTH3_ADAPTER_SIZE"]),
        },
        "adaln_binding": json.loads(os.environ["QKV_ADALN_BINDING_JSON"]),
        "adaln_sidecar_sha256": sha256(adaln_path),
    },
    "sampling": {
        "base_schedule": [0.999, 0.749, 0.5, 0.25, 0.0],
        "denoiser_evaluations": 4,
        "flow_shift": 12.0,
        "audio_flow_shift": 3.0,
    },
    "media_profile": {
        "width": 1280,
        "height": 720,
        "fps": 24,
        "num_frames": 362,
        "requested_duration_seconds": 15.0,
        "seed": 1101,
        "prompt_sha256": os.environ["QKV_PROMPT_SHA256"],
        "effective_width": 1280,
        "effective_height": 704,
        "video_shape": [107, 22, 40],
        "video_tile_count": 1620,
        "prefix_tile_count": int(os.environ["QKV_PREFIX_TILE_COUNT"]),
        "compact_row_count": int(os.environ["QKV_COMPACT_ROW_COUNT"]),
        "padded_row_count": int(os.environ["QKV_PADDED_ROW_COUNT"]),
    },
    "execution_profile": execution_profile,
    "software": {
        "runner_sha256": sha256(runner_path),
        "vllm_source_git_head": git_head(vllm_root),
        "vllm_source_files": vllm_sources,
        "flashinfer_git_head": git_head(flashinfer_root),
        "flashinfer_source_files": flashinfer_sources,
        "fastvideo_kernel_source_files": fastvideo_sources,
    },
}
canonical = json.dumps(
    contract,
    allow_nan=False,
    ensure_ascii=True,
    separators=(",", ":"),
    sort_keys=True,
).encode("ascii")
contract_path = Path(os.environ["QKV_CONTRACT_PATH"])
temporary = contract_path.with_name(f".{contract_path.name}.tmp")
temporary.write_bytes(canonical)
os.replace(temporary, contract_path)
print(hashlib.sha256(canonical).hexdigest())
PY
  )" || die "Failed to build the canonical QKV observer run contract"
  [[ "$contract_sha" =~ ^[0-9a-f]{64}$ ]] || die \
    "QKV observer run-contract digest is not canonical SHA256"
  if [[ "$QKV_TRANSPORT_OBSERVER_MODE" == validation ]]; then
    [[ "$contract_sha" == "$QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256" ]] || die \
      "QKV validation canonical run contract differs from calibration"
  else
    QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256="$contract_sha"
  fi

  export VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID="$QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID"
  export VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256="$QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256"
  export VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT="$QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT"
  export VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION="$QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION"
  export VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION="$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION"
  export VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256="$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256"

  {
    echo "qkv_transport_observer_execution_uuid=$QKV_TRANSPORT_OBSERVER_EXECUTION_UUID"
    echo "qkv_transport_observer_campaign_uuid=$QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID"
    echo "qkv_transport_observer_run_contract_path=$QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_PATH"
    echo "qkv_transport_observer_run_contract_sha256=$QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256"
    echo "qkv_transport_observer_expected_observation_count=$QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT"
    echo "qkv_transport_observer_source_model_revision=$QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION"
    echo "qkv_transport_observer_runtime_checkpoint_revision=$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION"
    echo "qkv_transport_observer_runtime_checkpoint_manifest_path=$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH"
    echo "qkv_transport_observer_runtime_checkpoint_manifest_sha256=$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256"
    echo "qkv_transport_observer_runtime_checkpoint_manifest_file_sha256=$manifest_file_sha"
    echo "qkv_transport_observer_request_count=1"
    echo "qkv_transport_observer_max_inflight_requests=1"
  } >>"$RUN_ROOT/environment.txt"
  {
    echo "qkv_transport_observer_execution_uuid=$QKV_TRANSPORT_OBSERVER_EXECUTION_UUID"
    echo "qkv_transport_observer_campaign_uuid=$QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID"
    echo "qkv_transport_observer_run_contract_path=$QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_PATH"
    echo "qkv_transport_observer_run_contract_sha256=$QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256"
    echo "qkv_transport_observer_expected_observation_count=$QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT"
    echo "qkv_transport_observer_source_model_revision=$QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION"
    echo "qkv_transport_observer_runtime_checkpoint_revision=$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION"
    echo "qkv_transport_observer_runtime_checkpoint_manifest_path=$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH"
    echo "qkv_transport_observer_runtime_checkpoint_manifest_sha256=$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256"
  } >>"$RUN_ROOT/request.txt"
}

validate_qkv_transport_observer() {
  [[ "$QKV_TRANSPORT_OBSERVER_MODE" != disabled ]] || return 0
  local server_log=$1
  local case_dir=$2
  local report="$case_dir/qkv-transport-observer-validation.txt"
  local metadata="$case_dir/qkv-transport-observer-metadata.txt"
  local hashes="$case_dir/qkv-transport-observer-artifacts.sha256"
  local expected_updates=$QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT

  if ! QKV_OBSERVER_MODE="$QKV_TRANSPORT_OBSERVER_MODE" \
    QKV_OBSERVER_SNAPSHOT_DIR="$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR" \
    QKV_OBSERVER_SERVER_LOG="$server_log" \
    QKV_OBSERVER_METADATA_PATH="$metadata" \
    QKV_OBSERVER_HASHES_PATH="$hashes" \
    QKV_OBSERVER_EXPECTED_UPDATES="$expected_updates" \
    QKV_OBSERVER_CAMPAIGN_UUID="$QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID" \
    QKV_OBSERVER_RUN_CONTRACT_SHA256="$QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256" \
    QKV_OBSERVER_SOURCE_MODEL_REVISION="$QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION" \
    QKV_OBSERVER_RUNTIME_CHECKPOINT_REVISION="$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION" \
    QKV_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256="$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256" \
    QKV_OBSERVER_VALIDATION_SCALES_PATH="$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_PATH" \
    QKV_OBSERVER_VALIDATION_SCALES_SHA256="$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_SHA256" \
    "$PYTHON" - <<'PY' >"$report" 2>&1
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import re

import torch

from vllm_omni.diffusion.models.minimax_h3.qkv_transport_calibration import (
    QKV_TRANSPORT_OBSERVER_ACTIVE_MARKER,
    QKV_TRANSPORT_OBSERVER_SNAPSHOT_MARKER,
    audit_qkv_e4m3_scales,
    load_qkv_transport_calibration_snapshot,
    merge_qkv_transport_calibration_files,
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_write_text(path: Path, payload: str) -> None:
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(payload, encoding="utf-8")
    os.replace(temporary, path)


mode = os.environ["QKV_OBSERVER_MODE"]
if mode not in {"calibration", "validation"}:
    raise SystemExit(f"invalid observer mode: {mode!r}")
snapshot_dir = Path(os.environ["QKV_OBSERVER_SNAPSHOT_DIR"]).resolve()
server_log = Path(os.environ["QKV_OBSERVER_SERVER_LOG"])
metadata_path = Path(os.environ["QKV_OBSERVER_METADATA_PATH"])
hashes_path = Path(os.environ["QKV_OBSERVER_HASHES_PATH"])
expected_updates = int(os.environ["QKV_OBSERVER_EXPECTED_UPDATES"])
if expected_updates != 4:
    raise SystemExit(f"formal QKV observer contract requires exactly 4 observations, got {expected_updates}")
expected_provenance = {
    "source_model_revision": os.environ["QKV_OBSERVER_SOURCE_MODEL_REVISION"],
    "runtime_checkpoint_revision": os.environ[
        "QKV_OBSERVER_RUNTIME_CHECKPOINT_REVISION"
    ],
    "runtime_checkpoint_manifest_sha256": os.environ[
        "QKV_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256"
    ],
    "campaign_uuid": os.environ["QKV_OBSERVER_CAMPAIGN_UUID"],
    "run_contract_sha256": os.environ["QKV_OBSERVER_RUN_CONTRACT_SHA256"],
    "expected_observation_count": expected_updates,
}

expected_paths = tuple(
    snapshot_dir
    / f"minimax-h3-qkv-transport-{mode}-rank-{rank:05d}.safetensors"
    for rank in range(8)
)
expected_names = {path.name for path in expected_paths}
actual_entries = {path.name for path in snapshot_dir.iterdir()}
if actual_entries != expected_names:
    raise SystemExit(
        "QKV observer artifact set mismatch: "
        f"missing={sorted(expected_names - actual_entries)!r}, "
        f"unexpected={sorted(actual_entries - expected_names)!r}"
    )
if any(not path.is_file() for path in expected_paths):
    raise SystemExit("every expected QKV observer artifact must be a regular file")

snapshots = []
updates_by_rank: dict[int, int] = {}
artifact_hashes: dict[int, str] = {}
for rank, path in enumerate(expected_paths):
    snapshot = load_qkv_transport_calibration_snapshot(path)
    if snapshot.source_rank != rank or snapshot.observer_mode != mode:
        raise SystemExit(
            f"rank-v3 identity mismatch for {path.name}: "
            f"rank={snapshot.source_rank!r}, mode={snapshot.observer_mode!r}"
        )
    if snapshot.provenance is None or snapshot.provenance.to_dict() != expected_provenance:
        raise SystemExit(f"formal provenance mismatch for {path.name}")
    if snapshot.num_layers != 50:
        raise SystemExit(f"{path.name} has {snapshot.num_layers} layers, expected 50")
    expected_observation_count = torch.full_like(
        snapshot.observation_count, expected_updates
    )
    if not torch.equal(snapshot.observation_count, expected_observation_count):
        raise SystemExit(
            f"{path.name} observation_count must be exactly {expected_updates} "
            "for every layer/component"
        )
    updates = expected_updates
    if bool((snapshot.nonfinite_count != 0).any()):
        raise SystemExit(f"{path.name} contains non-finite observations")
    if not torch.equal(snapshot.finite_count, snapshot.numel):
        raise SystemExit(f"{path.name} finite_count does not equal numel")
    if bool((snapshot.absmax <= 0).any()):
        raise SystemExit(f"{path.name} contains an uncalibrated zero absmax")
    if mode == "calibration":
        if snapshot.saturation_count is not None or snapshot.validation_scales is not None:
            raise SystemExit(f"{path.name} unexpectedly contains validation tensors")
    else:
        if snapshot.saturation_count is None or snapshot.validation_scales is None:
            raise SystemExit(f"{path.name} is missing validation tensors")
        if bool((snapshot.saturation_count != 0).any()):
            raise SystemExit(f"{path.name} contains saturated E4M3 observations")
    snapshots.append(snapshot)
    updates_by_rank[rank] = updates
    artifact_hashes[rank] = sha256(path)

if len(set(updates_by_rank.values())) != 1:
    raise SystemExit(f"QKV observer ranks completed different forward counts: {updates_by_rank!r}")

merged = merge_qkv_transport_calibration_files(
    expected_paths,
    expected_source_ranks=range(8),
    expected_observer_mode=mode,
)
if merged.provenance is None or merged.provenance.to_dict() != expected_provenance:
    raise SystemExit("merged QKV observer provenance mismatch")
peak_utilization = "not_applicable"
if mode == "validation":
    draft_path = Path(os.environ["QKV_OBSERVER_VALIDATION_SCALES_PATH"])
    expected_draft_sha = os.environ["QKV_OBSERVER_VALIDATION_SCALES_SHA256"]
    actual_draft_sha = sha256(draft_path)
    if actual_draft_sha != expected_draft_sha:
        raise SystemExit(
            "QKV validation draft changed while the action was running: "
            f"expected={expected_draft_sha}, actual={actual_draft_sha}"
        )
    audit = audit_qkv_e4m3_scales(merged)
    if not audit.passed or not audit.coverage_complete:
        raise SystemExit("merged QKV validation audit did not pass")
    if bool((audit.nonfinite_count != 0).any()):
        raise SystemExit("merged QKV validation contains non-finite observations")
    if bool((audit.saturation_count != 0).any()):
        raise SystemExit("merged QKV validation contains saturated observations")
    peak_utilization = f"{float(audit.peak_utilization.max().item()):.9g}"

log_text = server_log.read_text(encoding="utf-8", errors="replace")
active_pattern = re.compile(
    re.escape(QKV_TRANSPORT_OBSERVER_ACTIVE_MARKER)
    + r" mode=(calibration|validation) rank=(\d+) layers=(\d+) snapshot=(\S+)"
)
snapshot_pattern = re.compile(
    re.escape(QKV_TRANSPORT_OBSERVER_SNAPSHOT_MARKER)
    + r" mode=(calibration|validation) rank=(\d+) path=(\S+)"
)
active_markers = active_pattern.findall(log_text)
snapshot_markers = snapshot_pattern.findall(log_text)
if len(active_markers) != 8:
    raise SystemExit(f"expected 8 QKV observer active markers, found {len(active_markers)}")
active_ranks: list[int] = []
for marker_mode, raw_rank, raw_layers, raw_path in active_markers:
    rank = int(raw_rank)
    active_ranks.append(rank)
    if marker_mode != mode or int(raw_layers) != 50 or rank not in range(8):
        raise SystemExit(f"invalid QKV observer active marker: {(marker_mode, raw_rank, raw_layers, raw_path)!r}")
    if Path(raw_path).resolve() != expected_paths[rank]:
        raise SystemExit(f"QKV observer active marker path mismatch for rank {rank}")
if sorted(active_ranks) != list(range(8)):
    raise SystemExit(f"QKV observer active marker rank set is invalid: {active_ranks!r}")

snapshot_marker_counts = {rank: 0 for rank in range(8)}
for marker_mode, raw_rank, raw_path in snapshot_markers:
    rank = int(raw_rank)
    if marker_mode != mode or rank not in range(8):
        raise SystemExit(f"invalid QKV observer snapshot marker: {(marker_mode, raw_rank, raw_path)!r}")
    if Path(raw_path).resolve() != expected_paths[rank]:
        raise SystemExit(f"QKV observer snapshot marker path mismatch for rank {rank}")
    snapshot_marker_counts[rank] += 1
if snapshot_marker_counts != updates_by_rank:
    raise SystemExit(
        "QKV observer snapshot marker counts do not match cumulative artifacts: "
        f"markers={snapshot_marker_counts!r}, observations={updates_by_rank!r}"
    )

hash_lines = [
    f"{artifact_hashes[rank]}  {expected_paths[rank].name}"
    for rank in range(8)
]
atomic_write_text(hashes_path, "\n".join(hash_lines) + "\n")
manifest_sha = sha256(hashes_path)
updates_per_rank = next(iter(updates_by_rank.values()))
metadata_lines = [
    "qkv_transport_observer_validation_status=ok",
    f"qkv_transport_observer_mode={mode}",
    "qkv_transport_observer_timing_rung=0",
    "qkv_transport_observer_live_e4m3_transport=0",
    "qkv_transport_observer_snapshot_format=provenance_bound_v3",
    "qkv_transport_observer_source_ranks=0,1,2,3,4,5,6,7",
    "qkv_transport_observer_layers=50",
    "qkv_transport_observer_components=q,k,v",
    f"qkv_transport_observer_active_marker_count={len(active_markers)}",
    f"qkv_transport_observer_snapshot_marker_count={len(snapshot_markers)}",
    f"qkv_transport_observer_completed_forwards_per_rank={updates_per_rank}",
    f"qkv_transport_observer_campaign_uuid={expected_provenance['campaign_uuid']}",
    f"qkv_transport_observer_run_contract_sha256={expected_provenance['run_contract_sha256']}",
    f"qkv_transport_observer_expected_observation_count={expected_updates}",
    f"qkv_transport_observer_source_model_revision={expected_provenance['source_model_revision']}",
    f"qkv_transport_observer_runtime_checkpoint_revision={expected_provenance['runtime_checkpoint_revision']}",
    "qkv_transport_observer_runtime_checkpoint_manifest_sha256="
    f"{expected_provenance['runtime_checkpoint_manifest_sha256']}",
    f"qkv_transport_observer_merged_peak_utilization={peak_utilization}",
    f"qkv_transport_observer_artifact_manifest={hashes_path}",
    f"qkv_transport_observer_artifact_manifest_sha256={manifest_sha}",
    "qkv_transport_observer_formal_sidecar_finalized=0",
    "qkv_transport_observer_formal_go=0",
]
for rank in range(8):
    metadata_lines.append(
        f"qkv_transport_observer_rank_{rank:05d}_sha256={artifact_hashes[rank]}"
    )
if mode == "validation":
    metadata_lines.extend(
        (
            f"qkv_transport_observer_validation_scales_path={draft_path}",
            f"qkv_transport_observer_validation_scales_sha256={actual_draft_sha}",
        )
    )
atomic_write_text(metadata_path, "\n".join(metadata_lines) + "\n")

print(f"observer_mode={mode}")
print("snapshot_format=provenance_bound_v3")
print("source_ranks=0,1,2,3,4,5,6,7")
print(f"completed_forwards_per_rank={updates_per_rank}")
print(f"active_marker_count={len(active_markers)}")
print(f"snapshot_marker_count={len(snapshot_markers)}")
print(f"artifact_manifest_sha256={manifest_sha}")
print(f"merged_peak_utilization={peak_utilization}")
print("validation_status=ok")
PY
  then
    echo "QKV transport observer validation failed; see $report" >&2
    cat "$report" >&2 || true
    return 1
  fi

  cat "$metadata" >>"$case_dir/config.txt"
  cat "$metadata" >>"$RUN_ROOT/environment.txt"
}

run_case() {
  local case_name=$1
  local tp=$2
  local sp=$3
  local use_lsa=$4
  local mode=$5
  local use_nvenc=${6:-0}
  local use_flashinfer_rdma=${7:-0}
  local use_qk_direct=${8:-0}
  local case_dir="$RUN_ROOT/$case_name"
  local server_log="$case_dir/server.log"
  local server_start_ns ready_ns cold_start_s cache_config=""
  local qkv_prevalidation_output=""
  local warmup_s="-" measured_s encoder_s dit_s decode_total_s video_vae_path_s audio_vae_s
  local pipeline_forward_s engine_exec_s stage_gen_s async_output_residual_wait_s postprocess_s
  local stage_unattributed_residual_s mp4_encode_s api_http_residual_s
  local denoise_updates avg_step_ms
  local media_s rtf peak_gpu_mib output_path github_url upload_status
  local qkv_single_phase_validation_sha=""
  local attention_config=""
  local fp8_config=""
  local -a extra_args=()
  local -a profiler_args=()
  local -a attention_args=(--diffusion-attention-backend CUDNN_ATTN)

  CURRENT_CASE="$case_name"
  SUMMARY_ROW_WRITTEN=0
  QKV_E4M3_BINDING_JSON=""
  QKV_E4M3_AUDIT_JSON=""

  if [[ "$FLASHINFER_O_PRODUCER_DIRECT" == 1 && "$use_flashinfer_rdma" != 1 ]]; then
    die "O producer-direct requires the flashinfer-pcie Ulysses backend"
  fi
  if [[ "$VSA_DEFERRED_GATE_SP" == 1 ]]; then
    [[ "$FASTH3_VSA_MODE" == 1 ]] || die \
      "Deferred H3 VSA gate communication requires FastH3 VSA"
    (( sp > 1 )) || die \
      "Deferred H3 VSA gate communication requires SP world size > 1"
    [[ "$ULYSSES_MODE" == strict ]] || die \
      "Deferred H3 VSA gate communication requires strict Ulysses mode"
    [[ "$VSA_FUSED_GATE_UNTILE" == 0 ]] || die \
      "Deferred H3 VSA gate communication conflicts with fused gate/untile"
    [[ "$QCHUNK_PIPELINE" == 0 ]] || die \
      "Deferred H3 VSA gate communication conflicts with qchunk"
  fi
  if [[ "$VSA_O_BUNDLE" == 1 ]]; then
    [[ "$FASTH3_VSA_MODE" == 1 ]] || die \
      "H3 VSA reverse-O bundling requires FastH3 VSA"
    (( sp > 1 )) || die \
      "H3 VSA reverse-O bundling requires SP world size > 1"
    [[ "$ULYSSES_MODE" == strict ]] || die \
      "H3 VSA reverse-O bundling requires strict Ulysses mode"
    [[ "$ULYSSES_RING_SIZE" == 1 ]] || die \
      "H3 VSA reverse-O bundling conflicts with Ring attention"
    [[ "$H3_JOINT_ATTENTION_ROWS" == 0 ]] || die \
      "H3 VSA reverse-O bundling conflicts with joint attention rows"
    [[ "$use_flashinfer_rdma" == 1 ]] || die \
      "H3 VSA reverse-O bundling requires FlashInfer PCIe/RDMA Ulysses"
    [[ "$use_qk_direct" == 1 && "$FLASHINFER_O_PRODUCER_DIRECT" == 1 ]] || die \
      "H3 VSA reverse-O bundling requires cumulative Q/K/O producer-direct landing"
    [[ "$VSA_DEFERRED_GATE_SP" == 0 && "$VSA_FUSED_GATE_UNTILE" == 0 ]] || die \
      "H3 VSA reverse-O bundling conflicts with another VSA gate route"
    [[ "$QCHUNK_PIPELINE" == 0 ]] || die \
      "H3 VSA reverse-O bundling conflicts with qchunk"
  fi
  if [[ "$VSA_GATE_COMPUTE_OVERLAP" == 1 ]]; then
    [[ "$tp" == 1 && "$sp" == 8 && "$mode" == adaln ]] || die \
      "H3 VSA gate-compute overlap requires resident AdaLN-cache TP1 x SP8 and forbids DLO/offload"
    [[ "$use_lsa" == 0 && "$use_flashinfer_rdma" == 1 && "$use_qk_direct" == 1 ]] || die \
      "H3 VSA gate-compute overlap requires FlashInfer all-RDMA Q/K/V producer-direct execution"
    [[ "$QKV_E4M3_TRANSPORT" == 1 && "$FLASHINFER_O_PRODUCER_DIRECT" == 1 && \
          "$VSA_O_BUNDLE" == 1 ]] || die \
      "H3 VSA gate-compute overlap requires E4M3 Q/K/V plus producer-direct reverse-O bundling"
    [[ "$ULYSSES_MODE" == strict && "$ULYSSES_RING_SIZE" == 1 && \
          "$H3_JOINT_ATTENTION_ROWS" == 0 ]] || die \
      "H3 VSA gate-compute overlap forbids Ring, advanced Ulysses, and joint attention rows"
    [[ "$QCHUNK_PIPELINE" == 0 && "$VSA_DEFERRED_GATE_SP" == 0 && \
          "$VSA_FUSED_GATE_UNTILE" == 0 ]] || die \
      "H3 VSA gate-compute overlap forbids qchunk and alternate gate routes"
  fi
  if [[ "$QKV_SINGLE_PHASE" == 1 ]]; then
    qkv_single_phase_action_matches "$case_name" || die \
      "QKV single-phase requires an explicit cumulative runner action"
    [[ "$tp" == 1 && "$sp" == 8 && "$mode" == adaln ]] || die \
      "QKV single-phase requires its exact resident-AdaLN TP1 x SP8 action"
    [[ "$use_lsa" == 0 && "$use_flashinfer_rdma" == 1 && \
          "$use_qk_direct" == 1 ]] || die \
      "QKV single-phase requires FlashInfer all-RDMA Q/K/V producer-direct execution"
    [[ "$QKV_E4M3_TRANSPORT" == 1 && "$FLASHINFER_O_PRODUCER_DIRECT" == 1 && \
          "$VSA_O_BUNDLE" == 1 && \
          "$FLASHINFER_RELEASE_AFTER_DENOISE" == "$((1 - PERSISTENT_RDMA))" ]] || die \
      "QKV single-phase requires E4M3 Q/K/V plus the selected producer-direct reverse-O lifetime"
    [[ "$QCHUNK_PIPELINE" == 0 && "$VSA_GATE_COMPUTE_OVERLAP" == 0 && \
          "$TAEH3_OUTPUT" == 1 && "$TAEH3_DTYPE" == fp16 && \
          "$use_nvenc" == 0 ]] || die \
      "QKV single-phase must preserve the exact FP16 best-stack scheduling/output contract"
  fi
  if [[ "$TAEH3_AUDIO_DECODE_OVERLAP" == 1 ]]; then
    [[ "$case_name" == "$TAEH3_AUDIO_OVERLAP_ACTION" && \
          "$tp" == 1 && "$sp" == 8 && "$mode" == adaln ]] || die \
      "TAEH3/audio overlap requires its exact resident-AdaLN TP1 x SP8 action"
    [[ "$PERSISTENT_RDMA" == 1 && "$QKV_SINGLE_PHASE" == 0 && \
          "$TAEH3_OUTPUT" == 1 && "$TAEH3_DTYPE" == fp16 && \
          "$use_nvenc" == 0 && "$CHUNKED_CPU_MP4_OUTPUT" == 1 ]] || die \
      "TAEH3/audio overlap must preserve the fastest persistent-RDMA FP16 output stack"
  fi
  if [[ "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 1 ]]; then
    [[ ( "$case_name" == "$TAEH3_CROSS_RANK_AUDIO_ACTION" || \
          "$case_name" == "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTION" || \
          "$case_name" == "$MLP_FP8_BF16_WIRE_E2E_ACTION" ) && \
          "$tp" == 1 && "$sp" == 8 && "$mode" == adaln ]] || die \
      "TAEH3 cross-rank audio requires its exact resident-AdaLN TP1 x SP8 action"
    [[ "$PERSISTENT_RDMA" == 1 && "$TAEH3_AUDIO_DECODE_OVERLAP" == 0 && \
          "$QKV_SINGLE_PHASE" == 0 && "$TAEH3_OUTPUT" == 1 && \
          "$TAEH3_DTYPE" == fp16 && "$use_nvenc" == 0 && \
          "$CHUNKED_CPU_MP4_OUTPUT" == 1 ]] || die \
      "TAEH3 cross-rank audio must preserve the fastest persistent-RDMA FP16 output stack"
  fi
  if [[ "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 1 ]]; then
    [[ "$case_name" == "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTION" && \
          "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 1 ]] || die \
      "TAEH3 cross-rank AAC requires its exact cross-rank decode action"
  fi

  # A prior SP8 run on this dual-NUMA host failed at NCCL symmetric-memory
  # rendezvous with ncclGetPeerDevicePointer. This is an observed limitation of
  # that software/topology combination, not a claim that the hardware can never
  # support it. Require a small current-code world-size-8 rendezvous+A2A smoke
  # before an SP8 H3 process may opt in.
  if [[ "$use_lsa" == 1 && "$sp" -gt 4 && "$ALLOW_SP8_LSA" != 1 ]]; then
    die "SP8 LSA requires VLLM_OMNI_ALLOW_SP8_LSA=1 after a current-code SP8 smoke passes"
  fi

  require_idle_gpus
  port_is_busy && die "Port $PORT is already serving; choose VLLM_OMNI_PORT"
  mkdir -p "$case_dir"
  run_gpu_health_gates "$case_dir"
  ACTIVE_CASE="$case_name"

  export CUDA_DEVICE_ORDER=PCI_BUS_ID
  export CUDA_VISIBLE_DEVICES="$GPU_ORDER"
  export VLLM_WORKER_MULTIPROC_METHOD=spawn
  export VLLM_OMNI_VIDEO_SYNC_TIMEOUT="$REQUEST_TIMEOUT"
  export PYTORCH_ALLOC_CONF="${PYTORCH_ALLOC_CONF:-expandable_segments:True}"
  export HF_HOME="${HF_HOME:-$WORKSPACE_DIR/hf-cache}"
  export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$WORKSPACE_DIR/xdg-cache}"
  export TORCHINDUCTOR_CACHE_DIR="${TORCHINDUCTOR_CACHE_DIR:-$WORKSPACE_DIR/torchinductor-cache}"
  export TRITON_CACHE_DIR="${TRITON_CACHE_DIR:-$WORKSPACE_DIR/triton-cache}"
  export NCCL_DEBUG="${NCCL_DEBUG:-INFO}"
  export NCCL_DEBUG_SUBSYS="${NCCL_DEBUG_SUBSYS:-INIT,GRAPH,TUNING}"
  export MINIMAX_H3_VAE_NVENC_PIPELINE="$use_nvenc"
  export VLLM_OMNI_MINIMAX_H3_GPU_UINT8_OUTPUT="$GPU_UINT8_OUTPUT"
  export VLLM_OMNI_MINIMAX_H3_CHUNKED_CPU_MP4_OUTPUT="$CHUNKED_CPU_MP4_OUTPUT"
  export VLLM_OMNI_MINIMAX_H3_CHUNKED_CPU_MP4_SLOTS="$CHUNKED_CPU_MP4_SLOTS"
  export VLLM_OMNI_MINIMAX_H3_TAEH3_AUDIO_DECODE_OVERLAP="$TAEH3_AUDIO_DECODE_OVERLAP"
  export VLLM_OMNI_MINIMAX_H3_TAEH3_CROSS_RANK_AUDIO_DECODE="$TAEH3_CROSS_RANK_AUDIO_DECODE"
  export VLLM_OMNI_MINIMAX_H3_TAEH3_CROSS_RANK_AUDIO_ENCODE="$TAEH3_CROSS_RANK_AUDIO_ENCODE"
  if [[ "$TAEH3_OUTPUT" == 1 ]]; then
    export VLLM_OMNI_MINIMAX_H3_VIDEO_DECODE_BACKEND="$TAEH3_VIDEO_DECODE_BACKEND"
    export VLLM_OMNI_MINIMAX_H3_TAEH3_CHECKPOINT="$TAEH3_CHECKPOINT"
    export VLLM_OMNI_MINIMAX_H3_TAEH3_DTYPE="$TAEH3_DTYPE"
    export VLLM_OMNI_MINIMAX_H3_TAEH3_CHUNK_SIZE="$TAEH3_CHUNK_SIZE"
  else
    unset VLLM_OMNI_MINIMAX_H3_VIDEO_DECODE_BACKEND
    unset VLLM_OMNI_MINIMAX_H3_TAEH3_CHECKPOINT
    unset VLLM_OMNI_MINIMAX_H3_TAEH3_DTYPE
    unset VLLM_OMNI_MINIMAX_H3_TAEH3_CHUNK_SIZE
  fi
  export VLLM_OMNI_FASTVIDEO_VSA_FUSED_TILE_PACK="$VSA_FUSED_TILE_PACK"
  export VLLM_OMNI_FASTVIDEO_VSA_FUSED_UNTILE="$VSA_FUSED_UNTILE"
  export VLLM_OMNI_FASTVIDEO_VSA_FUSED_GATE_UNTILE="$VSA_FUSED_GATE_UNTILE"
  export VLLM_OMNI_FASTVIDEO_VSA_DEFERRED_GATE_SP="$VSA_DEFERRED_GATE_SP"
  export VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE="$VSA_O_BUNDLE"
  export VLLM_OMNI_FASTVIDEO_VSA_GATE_COMPUTE_OVERLAP="$VSA_GATE_COMPUTE_OVERLAP"
  export VLLM_OMNI_FASTVIDEO_VSA_DIRECT_Q2K="$VSA_DIRECT_Q2K"
  export VLLM_OMNI_MINIMAX_H3_VAE_TEMPORAL_PRE_GATHER_PRUNE="$VAE_TEMPORAL_PRE_GATHER_PRUNE"
  export VLLM_OMNI_MINIMAX_H3_VAE_TEMPORAL_CHUNK_PARALLEL="$VAE_TEMPORAL_CHUNK_PARALLEL"
  export VLLM_OMNI_MINIMAX_H3_VAE_DECODER_TILE_SIZE="$VAE_DECODER_TILE_SIZE"
  export VLLM_OMNI_MINIMAX_H3_VAE_EXACT_OPS_SM120="$VAE_EXACT_OPS_SM120"
  export MINIMAX_H3_VAE_DECODER_STREAM_TEMPORAL_CAT="$VAE_STREAM_TEMPORAL_CAT"
  export VLLM_OMNI_MINIMAX_H3_QCHUNK_PIPELINE="$QCHUNK_PIPELINE"
  export VLLM_OMNI_FLASHINFER_ULYSSES_QCHUNK2_DIRECT=0
  export VLLM_OMNI_FLASHINFER_ULYSSES_QCHUNK2_QKV_FUSED=0
  export VLLM_OMNI_ULYSSES_A2A_BACKEND=symmetric
  export VLLM_OMNI_FLASHINFER_ULYSSES_QK_PRODUCER_DIRECT="$use_qk_direct"
  export VLLM_OMNI_FLASHINFER_ULYSSES_O_PRODUCER_DIRECT="$FLASHINFER_O_PRODUCER_DIRECT"
  export VLLM_OMNI_FLASHINFER_ULYSSES_QKV_E4M3_TRANSPORT="$QKV_E4M3_TRANSPORT"
  if [[ "$QKV_SINGLE_PHASE" == 1 ]]; then
    export VLLM_OMNI_FLASHINFER_ULYSSES_QKV_SINGLE_PHASE=1
  else
    unset VLLM_OMNI_FLASHINFER_ULYSSES_QKV_SINGLE_PHASE
  fi
  export VLLM_OMNI_FLASHINFER_ULYSSES_RELEASE_AFTER_DENOISE="$FLASHINFER_RELEASE_AFTER_DENOISE"
  if [[ "$QKV_TRANSPORT_OBSERVER_MODE" != disabled ]]; then
    export VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_MODE="$QKV_TRANSPORT_OBSERVER_MODE"
    export VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR="$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR"
    if [[ "$QKV_TRANSPORT_OBSERVER_MODE" == validation ]]; then
      export VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_SCALES_PATH="$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_PATH"
    else
      unset VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_SCALES_PATH
    fi
  else
    unset VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_MODE
    unset VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR
    unset VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_SCALES_PATH
    unset VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID
    unset VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256
    unset VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT
    unset VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION
    unset VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION
    unset VLLM_OMNI_MINIMAX_H3_QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256
  fi

  if [[ "$FASTH3_VSA_MODE" == 1 ]]; then
    # The FastVideo comparison lane is its original corrected Triton blk64
    # route on SM120.  The second lane selects FlashInfer explicitly through
    # the vLLM attention config; neither may inherit the SM100a extension flag.
    export FASTVIDEO_VSA_SM100A=0
    prepare_fasth3_vsa_runtime
    attention_config="$($PYTHON -c \
      'import json,sys; print(json.dumps({"default":{"backend":"FASTVIDEO_VSA","fastvideo_vsa_topk":int(sys.argv[1]),"fastvideo_vsa_h3_kernel_backend":sys.argv[2]},"per_role":{"minimax_h3.token_refiner":{"backend":"CUDNN_ATTN"}}},separators=(",",":"),sort_keys=True))' \
      "$FASTH3_VSA_TOPK" "$FASTH3_VSA_PROVIDER")"
    attention_args=(--diffusion-attention-config "$attention_config")
  fi

  if [[ "$FP8_SCOPE" != none ]]; then
    # Keep one-shot/cached linears in BF16 and introduce low precision in
    # descending benefit/risk order.  Fp8Config requires exact runtime
    # prefixes: ignoring a parent does not protect its children.
    if [[ "$FP8_SCOPE" == mlp || "$FP8_SCOPE" == mlp-out || \
          "$FP8_SCOPE" == mlp-out-qkv || "$FP8_SCOPE" == all-main ]]; then
      fp8_config="$MLP_FP8_CONFIG_JSON"
    else
      fp8_config="$($PYTHON -c '
import json
import sys

scope = sys.argv[1]
all_main = (
    "attn.qkv_proj",
    "attn.to_gate_compress",
    "attn.out_proj",
    "mlp.fc1",
    "mlp.fc2",
)
targets = {
    "mlp": {"mlp.fc1", "mlp.fc2"},
    "mlp-out": {"mlp.fc1", "mlp.fc2", "attn.out_proj"},
    "mlp-out-qkv": {
        "mlp.fc1", "mlp.fc2", "attn.out_proj", "attn.qkv_proj"
    },
    "all-main": set(all_main),
}[scope]
ignored = ["condition_proj"]
for block in range(2):
    ignored.extend(
        f"token_refiner.blocks.{block}.{suffix}"
        for suffix in ("attn.qkv_proj", "attn.out_proj", "mlp.fc1", "mlp.fc2")
    )
for block in range(50):
    ignored.extend(
        f"blocks.{block}.{suffix}" for suffix in all_main if suffix not in targets
    )
print(json.dumps(
    {"transformer": {"method": "fp8", "ignored_layers": ignored}},
    separators=(",", ":"),
    sort_keys=True,
))
' "$FP8_SCOPE")"
    fi
    "$PYTHON" -c 'import json,sys; json.loads(sys.argv[1])' "$fp8_config"
    extra_args+=(--diffusion-quantization-config "$fp8_config")
  fi

  if [[ "$QKV_TRANSPORT_OBSERVER_MODE" != disabled ]]; then
    # Observer reductions and rank-local snapshot publication are diagnostic
    # work. Keep them out of compile/CUDA-graph capture and never report this
    # action as a formal latency rung.
    extra_args+=(--enforce-eager --max-num-seqs 1)
  fi

  if [[ "$use_nvenc" == 1 ]]; then
    "$PYTHON" -c 'import PyNvVideoCodec' || die \
      "PyNvVideoCodec is required by the chunked GPU VAE -> NVENC case"
  fi
  if [[ "$CHUNKED_CPU_MP4_OUTPUT" == 1 ]]; then
    "$PYTHON" -c \
      'from vllm_omni.diffusion.models.minimax_h3.chunked_cpu_output import validate_chunked_cpu_mp4_runtime; validate_chunked_cpu_mp4_runtime()' \
      || die "PyAV/libx264 is required by the chunked CPU MP4 output case"
  fi
  if [[ "$TAEH3_OUTPUT" == 1 ]]; then
    "$PYTHON" -c \
      'import os; from vllm_omni.diffusion.models.minimax_h3.taeh3 import resolve_minimax_h3_video_decoder_config, taeh3_decoded_pixel_shape, validate_minimax_h3_taeh3_output_route; c=resolve_minimax_h3_video_decoder_config(); validate_minimax_h3_taeh3_output_route(c,nvenc_enabled=False,chunked_cpu_mp4_enabled=True); assert c.backend == "taeh3" and c.dtype == os.environ["VLLM_OMNI_MINIMAX_H3_TAEH3_DTYPE"] and c.chunk_size == 5; assert taeh3_decoded_pixel_shape((1,24,107,44,80)) == (1,3,362,704,1280)' \
      || die "Pinned TAEH3 chunked-output runtime contract failed"
  fi

  case "$mode" in
    resident) ;;
    layerwise)
      # This uses the DLO loader's bounded two-block buffers and mmap source,
      # but deliberately disables DLO weight AllGather. The only inter-GPU
      # communication left is the model's TP/SP/VAE communication.
      extra_args+=(--enable-distributed-layerwise-offload --dlo-no-use-allgather --dlo-resident-layers 0)
      ;;
    layerwise-tuned)
      extra_args+=(
        --enable-distributed-layerwise-offload
        --dlo-resident-layers "$DLO_TUNED_RESIDENT_LAYERS"
      )
      if [[ "$DLO_TUNED_USE_ALLGATHER" == 1 ]]; then
        extra_args+=(--dlo-use-allgather)
      else
        extra_args+=(--dlo-no-use-allgather)
      fi
      ;;
    adaln)
      build_adaln_cache
      if [[ "$FASTH3_MODE" == 1 ]]; then
        # Capture the function's sole stdout value here.  Assigning the global
        # from inside the helper was fragile when run_case itself is evaluated
        # in a shell context that introduces dynamic/local scope.
        FASTH3_ADALN_BINDING_JSON="$(
          prevalidate_fasth3_adaln_sidecar \
            | sed -n 's/^__FASTH3_ADALN_BINDING__//p'
        )"
        [[ -n "$FASTH3_ADALN_BINDING_JSON" ]] || die \
          "FastH3 AdaLN sidecar prevalidation returned an empty binding"
        "$PYTHON" -c 'import json,sys; json.loads(sys.argv[1])' \
          "$FASTH3_ADALN_BINDING_JSON"
        echo "Validated adapter-bound ${FASTH3_VARIANT} FastH3 AdaLN sidecar: $ADALN_CACHE"
        if [[ "$QKV_E4M3_TRANSPORT" == 1 ]]; then
          prepare_qkv_transport_formal_runtime_identity "$case_dir"
          qkv_prevalidation_output="$(prevalidate_fasth3_qkv_e4m3_sidecar)"
          QKV_E4M3_BINDING_JSON="$(
            sed -n 's/^__QKV_E4M3_BINDING__//p' <<<"$qkv_prevalidation_output"
          )"
          QKV_E4M3_AUDIT_JSON="$(
            sed -n 's/^__QKV_E4M3_AUDIT__//p' <<<"$qkv_prevalidation_output"
          )"
          [[ -n "$QKV_E4M3_BINDING_JSON" && -n "$QKV_E4M3_AUDIT_JSON" ]] || die \
            "QKV E4M3 sidecar prevalidation returned incomplete evidence"
          "$PYTHON" -c 'import json,sys; json.loads(sys.argv[1]); json.loads(sys.argv[2])' \
            "$QKV_E4M3_BINDING_JSON" "$QKV_E4M3_AUDIT_JSON"
          echo "Validated adapter-bound QKV E4M3 transport sidecar: $QKV_E4M3_SCALE_SIDECAR"
          cache_config="$($PYTHON -c \
            'import json,sys; print(json.dumps({"minimax_h3_adaln_cache_path":sys.argv[1],"minimax_h3_adaln_cache_binding":json.loads(sys.argv[2]),"minimax_h3_qkv_transport_scale_path":sys.argv[3],"minimax_h3_qkv_transport_scale_binding":json.loads(sys.argv[4]),"minimax_h3_qkv_transport_runtime_checkpoint_revision":sys.argv[5],"minimax_h3_qkv_transport_runtime_checkpoint_manifest_path":sys.argv[6]},separators=(",",":"),sort_keys=True))' \
            "$ADALN_CACHE" "$FASTH3_ADALN_BINDING_JSON" \
            "$QKV_E4M3_SCALE_SIDECAR" "$QKV_E4M3_BINDING_JSON" \
            "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION" \
            "$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH")"
        else
          cache_config="$($PYTHON -c \
            'import json,sys; print(json.dumps({"minimax_h3_adaln_cache_path":sys.argv[1],"minimax_h3_adaln_cache_binding":json.loads(sys.argv[2])},separators=(",",":"),sort_keys=True))' \
            "$ADALN_CACHE" "$FASTH3_ADALN_BINDING_JSON")"
        fi
      else
        cache_config="$($PYTHON -c \
          'import json,sys; print(json.dumps({"minimax_h3_adaln_cache_path":sys.argv[1]}))' \
          "$ADALN_CACHE")"
      fi
      extra_args+=(--cache-config "$cache_config")
      ;;
    *) die "Unknown case mode: $mode" ;;
  esac

  if [[ "$use_flashinfer_rdma" == 1 ]]; then
    [[ "$tp" == 1 && "$sp" == 8 && "$use_lsa" == 0 ]] || die \
      "FlashInfer all-RDMA action requires TP1 x SP8 and must not enable symmetric-memory LSA"
    prepare_flashinfer_ulysses_rdma
    extra_args+=(--ulysses-a2a-permute)
    [[ "$use_qk_direct" == 0 || "$use_qk_direct" == 1 ]] || die \
      "Q/K producer-direct flag must be 0 or 1"
  elif [[ "$use_lsa" == 1 ]]; then
    [[ "$use_qk_direct" == 0 ]] || die \
      "Q/K producer-direct requires FlashInfer all-RDMA"
    prepare_lsa_toolkit
    extra_args+=(--ulysses-a2a-permute)
  else
    extra_args+=(--no-ulysses-a2a-permute)
  fi

  if [[ "$FASTH3_MODE" == 1 ]]; then
    if [[ "$case_name" == tp2-sp4-fasth3-dense-smoke ]]; then
      [[ "$mode" == resident && "$tp" == 2 && "$sp" == 4 ]] || die \
        "The Dense FastH3 smoke requires resident TP2 x SP4"
      [[ "$use_lsa" == 0 && "$use_flashinfer_rdma" == 0 && "$use_qk_direct" == 0 ]] || die \
        "The Dense FastH3 smoke must use the ordinary communication path"
    elif [[ "$case_name" == tp1-sp8-fasth3-dense-adaln-rdma-qk-direct ]]; then
      [[ "$mode" == adaln && "$tp" == 1 && "$sp" == 8 ]] || die \
        "The formal Dense FastH3 action requires TP1 x SP8 with its AdaLN sidecar"
      [[ "$use_flashinfer_rdma" == 1 && "$use_qk_direct" == 1 ]] || die \
        "The formal Dense FastH3 action requires FlashInfer all-RDMA and Q/K direct landing"
    elif [[ "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-full-vae || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp32 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp16 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-full-vae || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-full-vae || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-taeh3-fp16 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-fp8 || \
            "$case_name" == "$MLP_FP8_BF16_WIRE_E2E_ACTION" || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-fp8 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-qkv-fp8 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-fp8 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-fp8 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp32 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16-qkv-single-phase || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-fp8 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-fp8 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-qkv-fp8 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-fp8 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-fp8 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-qkv-fp8 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-all-main-fp8 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-all-main-fp8 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16 || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-audio-overlap || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio-aac || \
            "$case_name" == vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-qkv-single-phase ]]; then
      [[ "$mode" == adaln && "$tp" == 1 && "$sp" == 8 ]] || die \
        "The cumulative FastH3 VSA action requires TP1 x SP8 with its AdaLN sidecar"
      [[ "$FASTH3_VSA_PROVIDER" == flashinfer ]] || die \
        "The cumulative FastH3 VSA action requires the FlashInfer PR #4944 provider"
      [[ "$use_lsa" == 0 && "$use_flashinfer_rdma" == 1 && "$use_qk_direct" == 1 ]] || die \
        "The cumulative FastH3 VSA action requires PR #4876 all-RDMA and Q/K direct landing"
      case "$case_name" in
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-full-vae)
          [[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 && \
                "$QUALITY_MOON_BF16_FACTORIAL" == 1 && \
                "$FP8_SCOPE" == none && "$QKV_E4M3_TRANSPORT" == 0 && \
                "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
                "$VSA_O_BUNDLE" == 1 && "$TAEH3_OUTPUT" == 0 && \
                "$use_nvenc" == 0 && "$CHUNKED_CPU_MP4_OUTPUT" == 1 && \
                "$CHUNKED_CPU_MP4_SLOTS" == 2 && "$PERSISTENT_RDMA" == 0 && \
                "$FLASHINFER_RELEASE_AFTER_DENOISE" == 1 ]] || die \
            "Moon Q0D0 requires exact BF16 compute/wire, O-bundle, and full-H3-VAE execution"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp32)
          [[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 && \
                "$QUALITY_MOON_BF16_FACTORIAL" == 1 && \
                "$FP8_SCOPE" == none && "$QKV_E4M3_TRANSPORT" == 0 && \
                "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
                "$VSA_O_BUNDLE" == 1 && "$TAEH3_OUTPUT" == 1 && \
                "$TAEH3_DTYPE" == fp32 && "$use_nvenc" == 0 && \
                "$CHUNKED_CPU_MP4_OUTPUT" == 1 && \
                "$CHUNKED_CPU_MP4_SLOTS" == 2 && "$PERSISTENT_RDMA" == 0 && \
                "$FLASHINFER_RELEASE_AFTER_DENOISE" == 1 ]] || die \
            "Moon Q0D1 requires exact BF16 compute/wire, O-bundle, and TAEH3-FP32 execution"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp16)
          [[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 && \
                "$QUALITY_MOON_BF16_FACTORIAL" == 1 && \
                "$FP8_SCOPE" == none && "$QKV_E4M3_TRANSPORT" == 0 && \
                "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
                "$VSA_O_BUNDLE" == 1 && "$TAEH3_OUTPUT" == 1 && \
                "$TAEH3_DTYPE" == fp16 && "$use_nvenc" == 0 && \
                "$CHUNKED_CPU_MP4_OUTPUT" == 1 && \
                "$CHUNKED_CPU_MP4_SLOTS" == 2 && "$PERSISTENT_RDMA" == 0 && \
                "$FLASHINFER_RELEASE_AFTER_DENOISE" == 1 ]] || die \
            "Moon Q0D2 requires exact BF16 compute/wire, O-bundle, and TAEH3-FP16 execution"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-full-vae)
          [[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 && \
                "$QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL" == 1 && \
                "$ALL_MAIN_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == all-main && \
                "$QKV_E4M3_TRANSPORT" == 1 && \
                "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
                "$VSA_O_BUNDLE" == 1 && "$TAEH3_OUTPUT" == 0 && \
                "$use_nvenc" == 0 && "$CHUNKED_CPU_MP4_OUTPUT" == 1 && \
                "$CHUNKED_CPU_MP4_SLOTS" == 2 && "$PERSISTENT_RDMA" == 0 && \
                "$FLASHINFER_RELEASE_AFTER_DENOISE" == 1 ]] || die \
            "Moon Q1D0 requires exact all-main/E4M3, O-bundle, and full-H3-VAE execution"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16)
          [[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 && \
                "$QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL" == 1 && \
                "$ALL_MAIN_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == all-main && \
                "$QKV_E4M3_TRANSPORT" == 1 && \
                "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
                "$VSA_O_BUNDLE" == 1 && "$TAEH3_OUTPUT" == 1 && \
                "$TAEH3_DTYPE" == fp16 && "$use_nvenc" == 0 && \
                "$CHUNKED_CPU_MP4_OUTPUT" == 1 && \
                "$CHUNKED_CPU_MP4_SLOTS" == 2 && "$PERSISTENT_RDMA" == 0 && \
                "$FLASHINFER_RELEASE_AFTER_DENOISE" == 1 ]] || die \
            "Moon Q1D1 requires exact all-main/E4M3, O-bundle, and TAEH3-FP16 execution"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-full-vae)
          [[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 && \
                "$QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL" == 1 && \
                "$ALL_MAIN_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == all-main && \
                "$QKV_E4M3_TRANSPORT" == 0 && \
                "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
                "$VSA_O_BUNDLE" == 1 && "$TAEH3_OUTPUT" == 0 && \
                "$use_nvenc" == 0 && "$CHUNKED_CPU_MP4_OUTPUT" == 1 && \
                "$CHUNKED_CPU_MP4_SLOTS" == 2 && "$PERSISTENT_RDMA" == 0 && \
                "$FLASHINFER_RELEASE_AFTER_DENOISE" == 1 ]] || die \
            "Moon FP8-compute diagnostic requires exact all-main FP8, BF16 QKV wire, O-bundle, and full-H3-VAE execution"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-taeh3-fp16)
          [[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 && \
                "$QUALITY_MOON_ALL_MAIN_FP8_FACTORIAL" == 1 && \
                "$ALL_MAIN_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == all-main && \
                "$QKV_E4M3_TRANSPORT" == 0 && \
                "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
                "$VSA_O_BUNDLE" == 1 && "$TAEH3_OUTPUT" == 1 && \
                "$TAEH3_DTYPE" == fp16 && "$use_nvenc" == 0 && \
                "$CHUNKED_CPU_MP4_OUTPUT" == 1 && \
                "$CHUNKED_CPU_MP4_SLOTS" == 2 && "$PERSISTENT_RDMA" == 0 && \
                "$FLASHINFER_RELEASE_AFTER_DENOISE" == 1 ]] || die \
            "Moon qmid_d1 requires exact all-main FP8, BF16 QKV wire, O-bundle, and TAEH3-FP16 execution"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct)
          [[ "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] || die \
            "The BF16 cumulative control must not inherit E4M3 transport or observer state"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-fp8)
          [[ "$MLP_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp && \
                "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] || die \
            "The MLP-FP8 cumulative action requires its exact MLP scope and BF16 QKV transport"
          ;;
        "$MLP_FP8_BF16_WIRE_E2E_ACTION")
          [[ "$MLP_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp && \
                "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
                "$VSA_O_BUNDLE" == 1 && "$TAEH3_OUTPUT" == 1 && \
                "$TAEH3_DTYPE" == fp16 && "$PERSISTENT_RDMA" == 1 && \
                "$FLASHINFER_RELEASE_AFTER_DENOISE" == 0 && \
                "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 1 && \
                "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 0 ]] || die \
            "The MLP-only E2E action requires FC1/FC2 FP8, BF16 QKV/O, O-bundle, TAEH3 FP16, persistent RDMA, and cross-rank audio decode"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-fp8)
          [[ "$MLP_OUT_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp-out && \
                "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] || die \
            "The MLP-OUT-FP8 cumulative action requires its exact scope and BF16 QKV transport"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-qkv-fp8)
          [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp-out-qkv && \
                "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] || die \
            "The MLP-OUT-QKV-FP8 cumulative action requires exactly 200 targets and BF16 QKV wire"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3)
          [[ "$QKV_E4M3_TRANSPORT" == 1 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] || die \
            "E4M3 QKV transport may run only under its explicit cumulative action"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-fp8)
          [[ "$MLP_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp && \
                "$QKV_E4M3_TRANSPORT" == 1 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] || die \
            "The cumulative MLP-FP8 + E4M3 QKV action requires its exact combined contract"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-fp8)
          [[ "$MLP_OUT_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp-out && \
                "$QKV_E4M3_TRANSPORT" == 1 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] || die \
            "The cumulative MLP-OUT-FP8 + E4M3 QKV action requires its exact combined contract"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8)
          [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp-out-qkv && \
                "$QKV_E4M3_TRANSPORT" == 1 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] || die \
            "The cumulative MLP-OUT-QKV-FP8 + E4M3 QKV action requires its exact combined contract"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp32)
          [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp-out-qkv && \
                "$QKV_E4M3_TRANSPORT" == 1 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
                "$VSA_O_BUNDLE" == 1 && "$TAEH3_OUTPUT" == 1 && \
                "$use_nvenc" == 0 && "$CHUNKED_CPU_MP4_OUTPUT" == 1 && \
                "$CHUNKED_CPU_MP4_SLOTS" == 2 && "$TAEH3_DTYPE" == fp32 ]] || die \
            "The cumulative TAEH3 FP32 action requires its exact compute, communication, and output contract"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16)
          [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp-out-qkv && \
                "$QKV_E4M3_TRANSPORT" == 1 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
                "$VSA_O_BUNDLE" == 1 && "$TAEH3_OUTPUT" == 1 && \
                "$use_nvenc" == 0 && "$CHUNKED_CPU_MP4_OUTPUT" == 1 && \
                "$CHUNKED_CPU_MP4_SLOTS" == 2 && "$TAEH3_DTYPE" == fp16 && \
                "$QKV_SINGLE_PHASE" == 0 ]] || die \
            "The cumulative TAEH3 FP16 action requires its exact compute, communication, and output contract"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16-qkv-single-phase)
          [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp-out-qkv && \
                "$QKV_E4M3_TRANSPORT" == 1 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
                "$VSA_O_BUNDLE" == 1 && "$TAEH3_OUTPUT" == 1 && \
                "$use_nvenc" == 0 && "$CHUNKED_CPU_MP4_OUTPUT" == 1 && \
                "$CHUNKED_CPU_MP4_SLOTS" == 2 && "$TAEH3_DTYPE" == fp16 && \
                "$QKV_SINGLE_PHASE" == 1 ]] || die \
            "The QKV single-phase action must exactly extend the cumulative TAEH3 FP16 best stack"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration)
          [[ "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == calibration ]] || die \
            "The QKV calibration action requires its BF16 calibration observer only"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-fp8)
          [[ "$MLP_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp && \
                "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == calibration ]] || die \
            "The MLP-FP8 QKV calibration action requires its exact FP8-bound BF16 observer"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-fp8)
          [[ "$MLP_OUT_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp-out && \
                "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == calibration ]] || die \
            "The MLP-OUT-FP8 QKV calibration action requires its exact FP8-bound BF16 observer"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-qkv-fp8)
          [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp-out-qkv && \
                "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == calibration ]] || die \
            "The MLP-OUT-QKV-FP8 calibration action requires its exact FP8-bound BF16-wire observer"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation)
          [[ "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == validation ]] || die \
            "The QKV validation action requires its BF16 validation observer only"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-fp8)
          [[ "$MLP_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp && \
                "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == validation ]] || die \
            "The MLP-FP8 QKV validation action requires its exact FP8-bound BF16 observer"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-fp8)
          [[ "$MLP_OUT_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp-out && \
                "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == validation ]] || die \
            "The MLP-OUT-FP8 QKV validation action requires its exact FP8-bound BF16 observer"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-qkv-fp8)
          [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == mlp-out-qkv && \
                "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == validation ]] || die \
            "The MLP-OUT-QKV-FP8 validation action requires its exact FP8-bound BF16-wire observer"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-all-main-fp8)
          [[ "$ALL_MAIN_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == all-main && \
                "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == calibration && \
                "$QKV_SINGLE_PHASE" == 0 && "$TAEH3_OUTPUT" == 0 ]] || die \
            "The ALL-MAIN-FP8 calibration action requires its exact 250-linear BF16-wire observer"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-all-main-fp8)
          [[ "$ALL_MAIN_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == all-main && \
                "$QKV_E4M3_TRANSPORT" == 0 && "$QKV_TRANSPORT_OBSERVER_MODE" == validation && \
                "$QKV_SINGLE_PHASE" == 0 && "$TAEH3_OUTPUT" == 0 ]] || die \
            "The ALL-MAIN-FP8 validation action requires its exact 250-linear BF16-wire observer"
          ;;
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16|\
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma|\
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-audio-overlap|\
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio|\
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio-aac|\
        vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-qkv-single-phase)
          [[ "$ALL_MAIN_FP8_CONTRACT" == 1 && "$FP8_SCOPE" == all-main && \
                "$QKV_E4M3_TRANSPORT" == 1 && "$QKV_TRANSPORT_OBSERVER_MODE" == disabled && \
                "$VSA_O_BUNDLE" == 1 && "$TAEH3_OUTPUT" == 1 && \
                "$use_nvenc" == 0 && "$CHUNKED_CPU_MP4_OUTPUT" == 1 && \
                "$CHUNKED_CPU_MP4_SLOTS" == 2 && "$TAEH3_DTYPE" == fp16 && \
                "$UPLOAD_VIDEOS" == 0 && \
                "$FLASHINFER_RELEASE_AFTER_DENOISE" == "$((1 - PERSISTENT_RDMA))" ]] || die \
            "The cumulative ALL-MAIN-FP8 action requires its exact calibrated E4M3, O-bundle, FP16-output contract"
          if [[ "$case_name" == "$QKV_SINGLE_PHASE_ALL_MAIN_PERSISTENT_ACTION" ]]; then
            [[ "$QKV_SINGLE_PHASE" == 1 && "$PERSISTENT_RDMA" == 1 ]] || die \
              "The cumulative QKV single-phase action requires persistent RDMA and its protocol opt-in"
          else
            [[ "$QKV_SINGLE_PHASE" == 0 ]] || die \
              "QKV single-phase must not leak into another ALL-MAIN-FP8 action"
          fi
          if [[ "$case_name" == "$TAEH3_AUDIO_OVERLAP_ACTION" ]]; then
            [[ "$TAEH3_AUDIO_DECODE_OVERLAP" == 1 && "$PERSISTENT_RDMA" == 1 ]] || die \
              "The cumulative TAEH3/audio overlap action lost its scheduling opt-in"
          else
            [[ "$TAEH3_AUDIO_DECODE_OVERLAP" == 0 ]] || die \
              "TAEH3/audio overlap must not leak into another cumulative action"
          fi
          if [[ "$case_name" == "$TAEH3_CROSS_RANK_AUDIO_ACTION" || \
                "$case_name" == "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTION" ]]; then
            [[ "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 1 && \
                  "$PERSISTENT_RDMA" == 1 && \
                  "$TAEH3_AUDIO_DECODE_OVERLAP" == 0 ]] || die \
              "The cumulative TAEH3 cross-rank audio action lost its rank-placement opt-in"
          else
            [[ "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 0 ]] || die \
              "TAEH3 cross-rank audio must not leak into another cumulative action"
          fi
          if [[ "$case_name" == "$TAEH3_CROSS_RANK_AUDIO_ENCODE_ACTION" ]]; then
            [[ "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 1 ]] || die \
              "The cumulative TAEH3 cross-rank AAC action lost its packet-encoding opt-in"
          else
            [[ "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 0 ]] || die \
              "TAEH3 cross-rank AAC must not leak into another cumulative action"
          fi
          ;;
      esac
    elif [[ "$FASTH3_VSA_MODE" == 1 ]]; then
      [[ "$mode" == adaln && "$tp" == 1 && "$sp" == 8 ]] || die \
        "The formal FastH3 VSA A/B requires TP1 x SP8 with its AdaLN sidecar"
      [[ "$use_lsa" == 0 && "$use_flashinfer_rdma" == 0 && "$use_qk_direct" == 0 ]] || die \
        "The first FastH3 VSA provider A/B is pinned to ordinary NCCL Ulysses"
      [[ "$FASTH3_VSA_TOPK" == 162 ]] || die \
        "The first FastH3 VSA provider A/B is pinned to top-k 162"
    else
      die "FastH3 mode is restricted to its explicit smoke/formal actions"
    fi
    extra_args+=(--task-type fl2va --lora-path "$FASTH3_LORA" --lora-scale 1.0)
  fi

  prepare_qkv_transport_observer_contract "$case_dir"

  if [[ "$ENABLE_DIFFUSION_PIPELINE_PROFILER" == 1 ]]; then
    profiler_args+=(--enable-diffusion-pipeline-profiler)
  fi

  local -a server_args=(
    serve "$MODEL"
    --omni
    --host 127.0.0.1
    --port "$PORT"
    --trust-remote-code
    --num-gpus 8
    --tensor-parallel-size "$tp"
    --usp "$sp"
    --ring "$ULYSSES_RING_SIZE"
    --ulysses-mode "$ULYSSES_MODE"
    --text-encoder-tp-size 8
    --vae-patch-parallel-size "$VAE_PATCH_PARALLEL_SIZE"
    --vae-parallel-mode tile
    --vae-use-tiling
    "${attention_args[@]}"
    --cache-backend none
    "${profiler_args[@]}"
    "${extra_args[@]}"
  )

  {
    echo "case=$case_name"
    echo "quality_moon_factorial_action=$QUALITY_MOON_FACTORIAL_ACTION"
    echo "quality_moon_prompt_sha256=$([[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 ]] && echo "$QUALITY_MOON_PROMPT_SHA256" || echo not_applicable)"
    echo "quality_moon_q_factor=$QUALITY_MOON_Q_FACTOR"
    echo "quality_moon_d_factor=$QUALITY_MOON_D_FACTOR"
    echo "quality_moon_one_shot=$QUALITY_MOON_FACTORIAL_ACTION"
    echo "quality_moon_o_bundle_kmax=$([[ "$QUALITY_MOON_FACTORIAL_ACTION" == 1 ]] && echo "$VSA_O_BUNDLE_KMAX" || echo not_applicable)"
    if [[ "$FASTH3_MODE" == 1 ]]; then
      echo "checkpoint=original_FL2VA_BF16_plus_FastH3_${FASTH3_VARIANT}_fused_student"
      echo "fasth3_adapter=$FASTH3_LORA"
      echo "fasth3_adapter_sha256=$FASTH3_EXPECTED_SHA256"
      echo "fasth3_base_schedule=${FASTH3_BASE_SCHEDULE[*]}"
      echo "denoiser_evaluations=$DENOISER_EVALUATIONS"
      echo "fasth3_adaln_binding=$FASTH3_ADALN_BINDING_JSON"
    else
      echo "checkpoint=original_FL2VA_BF16"
    fi
    echo "parallelism=TP${tp}_SP${sp}_ring${ULYSSES_RING_SIZE}_TE8_VAE${VAE_PATCH_PARALLEL_SIZE}"
    echo "framework=vllm-omni"
    echo "timing_boundary=client_POST_/v1/videos/sync_to_complete_validated_H264_AAC_MP4"
    echo "exclusive_gpu_measurement_timeout_s=$EXCLUSIVE_GPU_TIMEOUT"
    echo "exclusive_gpu_measurement_monitor=process_group_poll_1s"
    echo "gpu_idle_health_gate=$GPU_IDLE_HEALTH_GATE"
    echo "gpu_balance_health_gate=$GPU_BALANCE_HEALTH_GATE"
    echo "gpu_clock_policy=$GPU_CLOCK_POLICY"
    echo "diffusion_pipeline_profiler=$ENABLE_DIFFUSION_PIPELINE_PROFILER"
    echo "diffusion_pipeline_profiler_contract=$([[ "$ENABLE_DIFFUSION_PIPELINE_PROFILER" == 1 ]] && echo diagnostic_device_synchronizing || echo production_disabled_client_e2e_only)"
    echo "gpu_balance_max_time_ratio=$GPU_BALANCE_MAX_TIME_RATIO"
    echo "gpu_balance_max_median_over_fleet=$GPU_BALANCE_MAX_MEDIAN_OVER_FLEET"
    echo "gpu_balance_min_clock_ratio=$GPU_BALANCE_MIN_CLOCK_RATIO"
    echo "gpu_balance_min_power_ratio=$GPU_BALANCE_MIN_POWER_RATIO"
    echo "ulysses_a2a_permute=$([[ "$use_lsa" == 1 || "$use_flashinfer_rdma" == 1 ]] && echo 1 || echo 0)"
    echo "ulysses_a2a_backend=$([[ "$use_flashinfer_rdma" == 1 ]] && echo flashinfer-pcie-${FLASHINFER_ULYSSES_ROUTE} || ([[ "$use_lsa" == 1 ]] && echo symmetric-memory-lsa || echo nccl))"
    [[ "$use_lsa" == 1 ]] && echo "ulysses_lsa_kernel=flattened_narrow_row_pr6866"
    if [[ "$use_lsa" == 1 && "$sp" -gt 4 ]]; then
      echo "sp8_lsa_current_code_smoke_gate=$ALLOW_SP8_LSA"
    fi
    echo "weight_mode=$mode"
    echo "chunked_vae_nvenc_output=$use_nvenc"
    echo "gpu_uint8_output=$GPU_UINT8_OUTPUT"
    echo "chunked_cpu_mp4_output=$CHUNKED_CPU_MP4_OUTPUT"
    echo "chunked_cpu_mp4_route=$([[ "$CHUNKED_CPU_MP4_OUTPUT" == 1 ]] && echo finalized_chunk_gpu_u8_pinned_d2h_pyav_libx264 || echo disabled)"
    echo "chunked_cpu_mp4_slots=$CHUNKED_CPU_MP4_SLOTS"
    echo "chunked_cpu_mp4_subsumes_gpu_uint8=$CHUNKED_CPU_MP4_OUTPUT"
    echo "video_decode_backend=$TAEH3_VIDEO_DECODE_BACKEND"
    echo "vae_patch_parallel_size=$VAE_PATCH_PARALLEL_SIZE"
    echo "taeh3_output=$TAEH3_OUTPUT"
    echo "taeh3_audio_decode_overlap=$TAEH3_AUDIO_DECODE_OVERLAP"
    echo "taeh3_audio_decode_overlap_env=$TAEH3_AUDIO_OVERLAP_ENV"
    echo "taeh3_audio_decode_overlap_runtime_marker=$TAEH3_AUDIO_OVERLAP_MARKER"
    echo "taeh3_audio_decode_overlap_quality_contract=$([[ "$TAEH3_AUDIO_DECODE_OVERLAP" == 1 ]] && echo schedule_only_same_decoder_outputs || echo disabled)"
    echo "taeh3_cross_rank_audio_decode=$TAEH3_CROSS_RANK_AUDIO_DECODE"
    echo "taeh3_cross_rank_audio_decode_env=$TAEH3_CROSS_RANK_AUDIO_ENV"
    echo "taeh3_cross_rank_audio_decode_runtime_marker=$TAEH3_CROSS_RANK_AUDIO_MARKER"
    echo "taeh3_cross_rank_audio_decode_quality_contract=$([[ "$TAEH3_CROSS_RANK_AUDIO_DECODE" == 1 ]] && echo rank_placement_only_exact_mp4_sha256_repeat3_validated_20260908 || echo disabled)"
    echo "taeh3_cross_rank_audio_encode=$TAEH3_CROSS_RANK_AUDIO_ENCODE"
    echo "taeh3_cross_rank_audio_encode_env=$TAEH3_CROSS_RANK_AUDIO_ENCODE_ENV"
    echo "taeh3_cross_rank_audio_encode_runtime_marker=$TAEH3_CROSS_RANK_AUDIO_ENCODE_MARKER"
    echo "taeh3_cross_rank_audio_encode_quality_contract=$([[ "$TAEH3_CROSS_RANK_AUDIO_ENCODE" == 1 ]] && echo independent_aac_packets_exact_cpu_mp4_ab_validated_full_e2e_sha_pending || echo disabled)"
    if [[ "$TAEH3_OUTPUT" == 1 ]]; then
      echo "taeh3_checkpoint=$TAEH3_CHECKPOINT"
      echo "taeh3_checkpoint_revision=$TAEH3_EXPECTED_REVISION"
      echo "taeh3_checkpoint_size=$TAEH3_EXPECTED_SIZE"
      echo "taeh3_checkpoint_sha256=$TAEH3_EXPECTED_SHA256"
      echo "taeh3_dtype=$TAEH3_DTYPE"
      echo "taeh3_chunk_size=$TAEH3_CHUNK_SIZE"
      echo "taeh3_full_video_vae_loaded=false"
      echo "taeh3_output_rank_policy=rank0_only"
      echo "taeh3_quality_contract=lossy_approximate_decoder_${TAEH3_DTYPE}"
      echo "taeh3_expected_output=22_chunks_362_frames_1280x704"
      echo "taeh3_marker_contract=loaded:1,active:8,decoded:1_per_request"
    fi
    echo "vsa_fused_tile_pack=$VSA_FUSED_TILE_PACK"
    echo "vsa_fused_untile=$VSA_FUSED_UNTILE"
    echo "vsa_fused_gate_untile=$VSA_FUSED_GATE_UNTILE"
    echo "vsa_fused_gate_untile_quality_contract=$([[ "$VSA_FUSED_GATE_UNTILE" == 1 ]] && echo production_shape_bit_exact_sm120_micro_full_sp8_pending || echo disabled)"
    echo "vsa_deferred_gate_sp=$VSA_DEFERRED_GATE_SP"
    echo "vsa_deferred_gate_sp_quality_contract=$([[ "$VSA_DEFERRED_GATE_SP" == 1 ]] && echo bf16_bit_exact_sp2_nccl_and_rdma_validated_full_sp8_e2e_pending || echo disabled)"
    echo "vsa_o_bundle=$VSA_O_BUNDLE"
    echo "vsa_o_bundle_quality_contract=$([[ "$VSA_O_BUNDLE" == 1 ]] && echo bf16_bit_exact_sm120_sp2_rdma_full_sp8_e2e_pending || echo disabled)"
    echo "vsa_gate_compute_overlap=$VSA_GATE_COMPUTE_OVERLAP"
    echo "vsa_gate_compute_overlap_quality_contract=$([[ "$VSA_GATE_COMPUTE_OVERLAP" == 1 ]] && echo unchanged_bf16_projection_schedule_only_full_sp8_hash_ab_pending || echo disabled)"
    echo "vsa_gate_compute_overlap_runtime_marker=MINIMAX_H3_VSA_GATE_COMPUTE_OVERLAP_ACTIVE_V1"
    echo "vsa_gate_compute_overlap_request_counters=not_exposed_nvtx_trace_required"
    echo "vsa_gate_compute_overlap_nvtx_side_prefix=minimax_h3.gate_compress.side:"
    echo "vsa_gate_compute_overlap_nvtx_wait_prefix=minimax_h3.gate_compress.wait:"
    echo "vsa_gate_compute_overlap_nvtx_expected_ranges_per_rank_4step_request=side:200,wait:200"
    echo "flashinfer_required_bytes=$FLASHINFER_REQUIRED_BYTES"
    echo "ulysses_mode=$ULYSSES_MODE"
    echo "ulysses_ring_size=$ULYSSES_RING_SIZE"
    echo "h3_joint_attention_rows=$H3_JOINT_ATTENTION_ROWS"
    echo "vsa_direct_q2k=$VSA_DIRECT_Q2K"
    echo "flashinfer_o_producer_direct=$FLASHINFER_O_PRODUCER_DIRECT"
    echo "vae_temporal_pre_gather_prune=$VAE_TEMPORAL_PRE_GATHER_PRUNE"
    echo "vae_temporal_chunk_parallel=$VAE_TEMPORAL_CHUNK_PARALLEL"
    echo "vae_temporal_chunk_parallel_quality_contract=$([[ "$VAE_TEMPORAL_CHUNK_PARALLEL" == 1 ]] && echo eager_bit_exact_candidate_requires_gpu_multiseed_ab || echo disabled)"
    echo "vae_temporal_chunk_parallel_compile=disabled"
    echo "vae_temporal_chunk_parallel_perf_contract=same_sequential_tile_compute_collective_reduction_benchmark_required"
    echo "vae_decoder_tile_size=$VAE_DECODER_TILE_SIZE"
    echo "vae_decoder_tile_quality_contract=$([[ "$VAE_DECODER_TILE_SIZE" == 0 ]] && echo checkpoint_default || echo numerical_non_bit_exact_tile_context_and_blend_boundaries)"
    echo "vae_exact_ops_sm120=$VAE_EXACT_OPS_SM120"
    echo "vae_exact_ops_sm120_quality_contract=$([[ "$VAE_EXACT_OPS_SM120" == 1 ]] && echo bitwise_micro_validated_all_rank_dispatch_counters_full_sp8_raw_equivalence_pending || echo disabled)"
    echo "minimax_h3_fp8_scope=$FP8_SCOPE"
    echo "minimax_h3_fp8_config=${fp8_config:-disabled}"
    echo "minimax_h3_mlp_fp8_formal_contract=$MLP_FP8_CONTRACT"
    echo "minimax_h3_mlp_out_fp8_formal_contract=$MLP_OUT_FP8_CONTRACT"
    if [[ "$MLP_OUT_QKV_FP8_CONTRACT" == 1 ]]; then
      echo "minimax_h3_mlp_out_qkv_fp8_formal_contract=1"
    fi
    echo "minimax_h3_all_main_fp8_formal_contract=$ALL_MAIN_FP8_CONTRACT"
    echo "minimax_h3_selective_fp8_formal_contract=$SELECTIVE_FP8_CONTRACT"
    echo "minimax_h3_fp8_dit_quant_mode=$MLP_FP8_DIT_QUANT_MODE"
    echo "minimax_h3_fp8_config_sha256=${MLP_FP8_CONFIG_SHA256:-disabled}"
    echo "minimax_h3_fp8_contract_sha256=${MLP_FP8_CONTRACT_SHA256:-disabled}"
    echo "minimax_h3_fp8_quality_contract=$([[ "$FP8_SCOPE" == none ]] && echo bf16 || echo lossy_online_per_tensor_fp8)"
    echo "qkv_e4m3_transport=$QKV_E4M3_TRANSPORT"
    echo "qkv_single_phase=$QKV_SINGLE_PHASE"
    echo "qkv_single_phase_env=$QKV_SINGLE_PHASE_ENV"
    echo "qkv_single_phase_env_owner=runner"
    echo "qkv_single_phase_protocol=$QKV_SINGLE_PHASE_PROTOCOL"
    echo "qkv_single_phase_quality_contract=$([[ "$QKV_SINGLE_PHASE" == 1 ]] && echo "$QKV_SINGLE_PHASE_QUALITY_CONTRACT" || echo disabled)"
    echo "qkv_single_phase_runtime_marker=$QKV_SINGLE_PHASE_MARKER"
    echo "qkv_single_phase_marker_contract=$QKV_SINGLE_PHASE_MARKER_CONTRACT"
    echo "qkv_single_phase_expected_workers=$sp"
    echo "qkv_single_phase_expected_calls_per_worker_per_request=$QKV_SINGLE_PHASE_EXPECTED_CALLS_PER_WORKER_PER_REQUEST"
    echo "qkv_single_phase_observed_call_count=not_exposed_by_runtime_activation_marker_only"
    if [[ "$QKV_SINGLE_PHASE" == 1 ]]; then
      echo "qkv_single_phase_flashinfer_source=$FLASHINFER_VSA_ROOT"
      echo "qkv_single_phase_flashinfer_git_status=$RUN_ROOT/qkv-single-phase-flashinfer-git-status.txt"
      echo "qkv_single_phase_flashinfer_git_diff=$RUN_ROOT/qkv-single-phase-flashinfer-git-diff.patch"
      echo "qkv_single_phase_flashinfer_untracked_sha256=$RUN_ROOT/qkv-single-phase-flashinfer-untracked-sha256.txt"
    fi
    echo "qkv_compute_dtype=bfloat16"
    if [[ "$FP8_SCOPE" == mlp-out-qkv || "$FP8_SCOPE" == all-main ]]; then
      echo "qkv_projection_compute_dtype=float8_e4m3fn"
      echo "qkv_projection_output_dtype=bfloat16"
    fi
    echo "vsa_gate_compress_compute_dtype=$([[ "$FP8_SCOPE" == all-main ]] && echo float8_e4m3fn || echo bfloat16)"
    echo "vsa_gate_compress_output_dtype=bfloat16"
    echo "qkv_wire_dtype=$([[ "$QKV_E4M3_TRANSPORT" == 1 ]] && echo float8_e4m3fn || echo bfloat16)"
    echo "reverse_o_dtype=bfloat16"
    echo "qkv_transport_quality_contract=$([[ "$QKV_E4M3_TRANSPORT" == 1 ]] && echo lossy_static_per_block_e4m3_transport || echo bf16)"
    echo "qkv_transport_observer_mode=$QKV_TRANSPORT_OBSERVER_MODE"
    echo "qkv_transport_observer_snapshot_format=$([[ "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] && echo disabled || echo provenance_bound_v3)"
    echo "qkv_transport_observer_timing_rung=$([[ "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] && echo not_applicable || echo 0)"
    echo "qkv_transport_observer_enforce_eager=$([[ "$QKV_TRANSPORT_OBSERVER_MODE" == disabled ]] && echo 0 || echo 1)"
    if [[ "$QKV_TRANSPORT_OBSERVER_MODE" != disabled ]]; then
      echo "qkv_transport_observer_formal_sidecar_finalized=0"
      echo "qkv_transport_observer_formal_go=0"
      echo "qkv_transport_observer_snapshot_dir=$QKV_TRANSPORT_OBSERVER_SNAPSHOT_DIR"
      echo "qkv_transport_observer_expected_source_ranks=0,1,2,3,4,5,6,7"
      echo "qkv_transport_observer_expected_layers=50"
      echo "qkv_transport_observer_expected_components=q,k,v"
      echo "qkv_transport_observer_execution_uuid=$QKV_TRANSPORT_OBSERVER_EXECUTION_UUID"
      echo "qkv_transport_observer_campaign_uuid=$QKV_TRANSPORT_OBSERVER_CAMPAIGN_UUID"
      echo "qkv_transport_observer_run_contract_path=$QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_PATH"
      echo "qkv_transport_observer_run_contract_sha256=$QKV_TRANSPORT_OBSERVER_RUN_CONTRACT_SHA256"
      echo "qkv_transport_observer_expected_observation_count=$QKV_TRANSPORT_OBSERVER_EXPECTED_OBSERVATION_COUNT"
      echo "qkv_transport_observer_source_model_revision=$QKV_TRANSPORT_OBSERVER_SOURCE_MODEL_REVISION"
      echo "qkv_transport_observer_runtime_checkpoint_revision=$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_REVISION"
      echo "qkv_transport_observer_runtime_checkpoint_manifest_path=$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_PATH"
      echo "qkv_transport_observer_runtime_checkpoint_manifest_sha256=$QKV_TRANSPORT_OBSERVER_RUNTIME_CHECKPOINT_MANIFEST_SHA256"
      echo "qkv_transport_observer_request_count=1"
      echo "qkv_transport_observer_max_inflight_requests=1"
    fi
    if [[ "$QKV_TRANSPORT_OBSERVER_MODE" == validation ]]; then
      echo "qkv_transport_observer_validation_scales_path=$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_PATH"
      echo "qkv_transport_observer_validation_scales_sha256=$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALES_SHA256"
      echo "qkv_transport_observer_validation_scale_summary=$QKV_TRANSPORT_OBSERVER_VALIDATION_SCALE_SUMMARY"
    fi
    if [[ "$QKV_E4M3_TRANSPORT" == 1 ]]; then
      echo "qkv_e4m3_scale_sidecar=$QKV_E4M3_SCALE_SIDECAR"
      echo "qkv_e4m3_scale_sidecar_sha256=$QKV_E4M3_EXPECTED_WHOLE_SHA256"
      echo "qkv_e4m3_payload_sha256=$QKV_E4M3_EXPECTED_PAYLOAD_SHA256"
      echo "qkv_e4m3_source_model_revision=$QKV_E4M3_SOURCE_MODEL_REVISION"
      echo "qkv_e4m3_kernel_provider=$QKV_E4M3_KERNEL_PROVIDER"
      echo "qkv_e4m3_kernel_abi=$QKV_E4M3_KERNEL_ABI"
      echo "qkv_e4m3_binding=$QKV_E4M3_BINDING_JSON"
      echo "qkv_e4m3_audit=$QKV_E4M3_AUDIT_JSON"
      echo "qkv_bf16_operand_bytes=$VSA_ELIDED_GATE_OPERAND_BYTES"
      echo "qkv_e4m3_operand_bytes=$QKV_E4M3_OPERAND_BYTES"
      echo "qkv_bf16_remote_wire_bytes=$VSA_ELIDED_GATE_REMOTE_WIRE_BYTES"
      echo "qkv_e4m3_remote_wire_bytes=$QKV_E4M3_REMOTE_WIRE_BYTES"
      echo "qkv_remote_wire_saving_bytes_per_rank_request=$QKV_REMOTE_WIRE_SAVING_BYTES_PER_RANK_REQUEST"
      echo "flashinfer_capacity_basis=largest_bf16_reverse_o$([[ "$VSA_O_BUNDLE" == 1 ]] && echo _bundle)"
    fi
    echo "vae_stream_temporal_cat=$VAE_STREAM_TEMPORAL_CAT"
    echo "h3_qchunk_pipeline=$QCHUNK_PIPELINE"
    echo "flashinfer_release_after_denoise=$FLASHINFER_RELEASE_AFTER_DENOISE"
    if [[ "$FASTH3_VSA_MODE" == 1 ]]; then
      echo "attention_backend=FASTVIDEO_VSA"
      echo "vsa_compute_provider=$FASTH3_VSA_PROVIDER"
      echo "vsa_topk=$FASTH3_VSA_TOPK"
      echo "vsa_tile_size=64"
      echo "vsa_attention_config=$attention_config"
      echo "fastvideo_kernel_python=$FASTVIDEO_KERNEL_PYTHON"
      if [[ "$FASTH3_VSA_PROVIDER" == flashinfer ]]; then
        echo "flashinfer_vsa_root=$FLASHINFER_VSA_ROOT"
        echo "flashinfer_vsa_commit=$FLASHINFER_VSA_EXPECTED_COMMIT"
        echo "flashinfer_vsa_workspace=$FLASHINFER_VSA_WORKSPACE"
      fi
    else
      echo "attention_backend=CUDNN_ATTN"
    fi
      echo "per_step_synchronized_profiler=$([[ "$ENABLE_DIFFUSION_PIPELINE_PROFILER" == 1 ]] && echo enabled || echo disabled)"
    echo "async_output_residual_wait_profiler=engine_wall_clock_no_cuda_sync"
    if [[ "$mode" == layerwise-tuned ]]; then
      echo "dlo_weight_allgather=$([[ "$DLO_TUNED_USE_ALLGATHER" == 1 ]] && echo enabled || echo disabled)"
      echo "dlo_resident_layers=$DLO_TUNED_RESIDENT_LAYERS"
    elif [[ "$mode" == layerwise ]]; then
      echo "dlo_weight_allgather=disabled"
      echo "dlo_resident_layers=0"
    else
      echo "dlo_weight_allgather=not_applicable"
      echo "dlo_resident_layers=not_applicable"
    fi
    echo "gpu_order=$GPU_ORDER"
    [[ "$mode" == adaln ]] && echo "adaln_cache=$ADALN_CACHE"
    if [[ "$use_flashinfer_rdma" == 1 ]]; then
      echo "flashinfer_version=$FLASHINFER_EXPECTED_VERSION"
      echo "flashinfer_commit=$FLASHINFER_EXPECTED_COMMIT"
      echo "flashinfer_route=$FLASHINFER_ULYSSES_ROUTE"
      echo "flashinfer_max_bytes=$FLASHINFER_MAX_BYTES"
      echo "flashinfer_overlay=$FLASHINFER_PR_SITE"
      echo "flashinfer_workspace=$FLASHINFER_WORKSPACE"
      echo "flashinfer_qk_producer_direct=$use_qk_direct"
    fi
  } >"$case_dir/config.txt"
  printf '%q ' numactl --interleave=0,1 "$VLLM" "${server_args[@]}" >"$case_dir/server-command.txt"
  printf '\n' >>"$case_dir/server-command.txt"

  echo "Starting $case_name: TP${tp} x SP${sp}, LSA=$use_lsa, FlashInferPCIe=$use_flashinfer_rdma, route=$FLASHINFER_ULYSSES_ROUTE, weights=$mode"
  server_start_ns="$(date +%s%N)"
  if [[ -n "$NSYS_INTERACTIVE_SESSION" ]]; then
    setsid "$NSYS_INTERACTIVE_BIN" launch \
      --session-new="$NSYS_INTERACTIVE_SESSION" \
      --trace=cuda,nvtx,cudnn,cublas,osrt \
      --trace-fork-before-exec=false \
      numactl --interleave=0,1 "$VLLM" "${server_args[@]}" >"$server_log" 2>&1 &
  else
    setsid numactl --interleave=0,1 "$VLLM" "${server_args[@]}" >"$server_log" 2>&1 &
  fi
  SERVER_PID=$!
  echo "$SERVER_PID" >"$case_dir/server.pid"
  start_sampler "$case_dir"

  local deadline=$((SECONDS + READY_TIMEOUT))
  until curl -fsS --max-time 2 "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; do
    if ! kill -0 "$SERVER_PID" 2>/dev/null; then
      stop_sampler "$case_dir"
      tail -n 240 "$server_log" >&2 || true
      emit_summary_failure "$case_name" failed-startup
      die "$case_name exited before readiness"
    fi
    if (( SECONDS >= deadline )); then
      tail -n 240 "$server_log" >&2 || true
      die "$case_name did not become ready within ${READY_TIMEOUT}s"
    fi
    sleep 5
  done
  ready_ns="$(date +%s%N)"
  cold_start_s="$(awk -v start="$server_start_ns" -v end="$ready_ns" 'BEGIN {printf "%.3f", (end-start)/1000000000}')"
  printf '%s\n' "$cold_start_s" >"$case_dir/cold-start-seconds.txt"
  echo "$case_name ready in $cold_start_s s"

  for ((index=1; index<=WARMUPS; index++)); do
    request_video "warmup-$index" "$case_dir" "$case_dir/_warmup-${index}.mp4" "$server_log"
    warmup_s="$(<"$case_dir/warmup-${index}-e2e-seconds.txt")"
    if ! validate_server_log "$server_log" "$case_dir" "$use_flashinfer_rdma" "$use_qk_direct" \
      "$FLASHINFER_RELEASE_AFTER_DENOISE" "$FLASHINFER_O_PRODUCER_DIRECT" 0 "$sp" \
      "$QKV_E4M3_TRANSPORT"; then
      stop_sampler "$case_dir"
      emit_summary_failure "$case_name" failed-warmup-log-integrity
      die "$case_name failed server-log validation after warmup $index"
    fi
  done

  if [[ -n "$NSYS_INTERACTIVE_SESSION" ]]; then
    "$NSYS_INTERACTIVE_BIN" start \
      --session="$NSYS_INTERACTIVE_SESSION" \
      --sample=none \
      --cpuctxsw=none \
      --output="$NSYS_INTERACTIVE_OUTPUT"
  fi

  for ((index=1; index<=REPEATS; index++)); do
    if (( REPEATS == 1 )); then
      output_path="$case_dir/out_t2va1.mp4"
    else
      output_path="$case_dir/out_t2va1-repeat-${index}.mp4"
    fi
    request_video "measured-$index" "$case_dir" "$output_path" "$server_log"
  done

  if [[ -n "$NSYS_INTERACTIVE_SESSION" ]]; then
    "$NSYS_INTERACTIVE_BIN" stop --session="$NSYS_INTERACTIVE_SESSION"
    [[ -s "$NSYS_INTERACTIVE_OUTPUT.nsys-rep" ]] || die \
      "Marker-free interactive Nsight report is missing: $NSYS_INTERACTIVE_OUTPUT.nsys-rep"
  fi

  if ! validate_server_log "$server_log" "$case_dir" "$use_flashinfer_rdma" "$use_qk_direct" \
    "$FLASHINFER_RELEASE_AFTER_DENOISE" "$FLASHINFER_O_PRODUCER_DIRECT" 1 "$sp" \
    "$QKV_E4M3_TRANSPORT"; then
    stop_sampler "$case_dir"
    emit_summary_failure "$case_name" failed-log-integrity
    die "$case_name failed post-request server-log validation"
  fi
  if [[ "$QKV_SINGLE_PHASE" == 1 ]]; then
    [[ -f "$case_dir/qkv-single-phase-runtime-validation.txt" ]] || die \
      "$case_name is missing the QKV single-phase runtime validation report"
    [[ "$(grep -Fc 'validation_status=ok' \
      "$case_dir/qkv-single-phase-runtime-validation.txt" || true)" == 1 ]] || die \
      "$case_name QKV single-phase runtime report is not uniquely successful"
    qkv_single_phase_validation_sha="$(sha256sum \
      "$case_dir/qkv-single-phase-runtime-validation.txt")"
    qkv_single_phase_validation_sha="${qkv_single_phase_validation_sha%% *}"
    {
      echo "qkv_single_phase_runtime_validation_report=$case_dir/qkv-single-phase-runtime-validation.txt"
      echo "qkv_single_phase_runtime_validation_sha256=$qkv_single_phase_validation_sha"
    } >>"$case_dir/config.txt"
  fi
  if ! validate_qkv_transport_observer "$server_log" "$case_dir"; then
    stop_sampler "$case_dir"
    emit_summary_failure "$case_name" failed-qkv-observer-validation
    die "$case_name failed QKV transport observer artifact/marker validation"
  fi

  measured_s="$(awk '{sum+=$1; n+=1} END {if(n) printf "%.3f", sum/n}' "$case_dir"/measured-*-e2e-seconds.txt)"
  encoder_s="$(average_metric_files "$case_dir"/measured-*-encoder-seconds.txt)"
  dit_s="$(average_metric_files "$case_dir"/measured-*-dit-seconds.txt)"
  decode_total_s="$(average_metric_files "$case_dir"/measured-*-decode-total-seconds.txt)"
  video_vae_path_s="$(average_metric_files "$case_dir"/measured-*-video-vae-path-seconds.txt)"
  audio_vae_s="$(average_metric_files "$case_dir"/measured-*-audio-vae-seconds.txt)"
  pipeline_forward_s="$(average_metric_files "$case_dir"/measured-*-pipeline-forward-seconds.txt)"
  engine_exec_s="$(average_metric_files "$case_dir"/measured-*-engine-exec-seconds.txt)"
  stage_gen_s="$(average_metric_files "$case_dir"/measured-*-stage-gen-seconds.txt)"
  async_output_residual_wait_s="$(average_metric_files \
    "$case_dir"/measured-*-async-output-residual-wait-seconds.txt)"
  postprocess_s="$(average_metric_files "$case_dir"/measured-*-postprocess-seconds.txt)"
  stage_unattributed_residual_s="$(average_metric_files \
    "$case_dir"/measured-*-stage-unattributed-residual-seconds.txt)"
  mp4_encode_s="$(average_metric_files "$case_dir"/measured-*-mp4-encode-seconds.txt)"
  api_http_residual_s="$(average_metric_files \
    "$case_dir"/measured-*-api-http-residual-seconds.txt)"
  denoise_updates="$DENOISER_EVALUATIONS"
  avg_step_ms="$(awk -F'\t' '
    FNR > 1 && $4 ~ /^[0-9]+([.][0-9]+)?$/ { sum += $4; count += 1 }
    END { if (count) printf "%.3f", sum * 1000.0 / count; else printf "-" }
  ' "$case_dir"/measured-*-dit-step-times.tsv)"
  media_s="$(probe_media "$output_path" "$case_dir/measured-media.txt")"
  if ! validate_taeh3_output_artifact "$output_path" "$case_dir"; then
    stop_sampler "$case_dir"
    emit_summary_failure "$case_name" failed-taeh3-output-manifest
    die "$case_name failed finalized TAEH3 MP4 validation"
  fi
  rtf="$(awk -v wall="$measured_s" -v media="$media_s" 'BEGIN {printf "%.3f", wall/media}')"
  peak_gpu_mib="$(awk -F',' 'NF>=3 {gsub(/ /,"",$3); if($3+0>max) max=$3+0} END {print max+0}' \
    "$case_dir/gpu-samples.csv")"

  stop_sampler "$case_dir"
  stop_case
  if [[ "$UPLOAD_VIDEOS" != 1 ]]; then
    upload_status=disabled
    github_url=-
  elif github_url="$(upload_case_video "$case_name" "$output_path")"; then
    upload_status=ok
  else
    upload_status=failed
    github_url=-
    echo "WARNING: video upload failed for $case_name; measurements remain valid" >&2
  fi
  printf 'status=%s\nurl=%s\n' "$upload_status" "$github_url" >"$case_dir/upload.txt"
  printf '%s\tok\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$case_name" "$cold_start_s" "$warmup_s" "$measured_s" "$encoder_s" "$dit_s" \
    "$decode_total_s" "$video_vae_path_s" "$audio_vae_s" "$pipeline_forward_s" \
    "$engine_exec_s" "$stage_gen_s" "$async_output_residual_wait_s" "$postprocess_s" \
    "$stage_unattributed_residual_s" "$mp4_encode_s" "$api_http_residual_s" \
    "$denoise_updates" "$avg_step_ms" "$media_s" \
    "$rtf" "$peak_gpu_mib" "$output_path" "$github_url" \
    >>"$SUMMARY_TSV"
  SUMMARY_ROW_WRITTEN=1
  CURRENT_CASE=""
  sleep 5
}

case "$ACTION" in
  comm-ab)
    CASES=(tp2-sp4-regular tp2-sp4-lsa)
    ;;
  remaining)
    CASES=(tp2-sp4-lsa tp2-sp4-adaln-lsa tp1-sp8-layerwise tp1-sp8-adaln)
    ;;
  matrix)
    CASES=(tp2-sp4-regular tp2-sp4-lsa tp2-sp4-adaln-lsa tp1-sp8-layerwise tp1-sp8-adaln)
    ;;
  *)
    CASES=("$ACTION")
    ;;
esac

prepare_video_upload
require_idle_gpus
for case_name in "${CASES[@]}"; do
  case "$case_name" in
    tp2-sp4-regular)       run_case "$case_name" 2 4 0 resident 0 ;;
    tp2-sp4-lsa)           run_case "$case_name" 2 4 1 resident 0 ;;
    tp2-sp4-adaln-lsa)     run_case "$case_name" 2 4 1 adaln 0 ;;
    tp1-sp8-adaln-lsa)     run_case "$case_name" 1 8 1 adaln 0 ;;
    tp1-sp8-adaln-rdma)    run_case "$case_name" 1 8 0 adaln 0 1 ;;
    tp1-sp8-adaln-rdma-qk-direct) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    tp1-sp8-fasth3-dense-adaln-rdma-qk-direct) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-fastvideo-topk162-nccl) run_case "$case_name" 1 8 0 adaln 0 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-nccl) run_case "$case_name" 1 8 0 adaln 0 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-full-vae) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp32) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-bf16-o-bundle-taeh3-fp16) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-full-vae) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-full-vae) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-quality-moon-all-main-fp8-bf16-qkv-o-bundle-taeh3-fp16) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-mlp-out-qkv-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp32) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-mlp-out-qkv-fp8-o-bundle-taeh3-fp16-qkv-single-phase) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-mlp-out-qkv-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-mlp-out-qkv-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-calibration-all-main-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-validation-all-main-fp8) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-audio-overlap) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-cross-rank-audio-aac) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct-qkv-e4m3-all-main-fp8-o-bundle-taeh3-fp16-persistent-rdma-qkv-single-phase) run_case "$case_name" 1 8 0 adaln 0 1 1 ;;
    tp2-sp4-fasth3-dense-smoke) run_case "$case_name" 2 4 0 resident 0 ;;
    tp1-sp8-layerwise)     run_case "$case_name" 1 8 0 layerwise 0 ;;
    tp1-sp8-layerwise-tuned) run_case "$case_name" 1 8 0 layerwise-tuned 0 ;;
    tp1-sp8-adaln)         run_case "$case_name" 1 8 0 adaln 0 ;;
  esac
done

echo
column -t -s $'\t' "$SUMMARY_TSV" 2>/dev/null || cat "$SUMMARY_TSV"
echo "Results: $RUN_ROOT"
