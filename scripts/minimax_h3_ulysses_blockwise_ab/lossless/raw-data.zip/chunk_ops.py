"""Lossless O experiments: variable tails and one immutable received tail."""
import torch
import triton
import triton.language as tl


@triton.jit
def _h3_o_chunk_produce_v2(fine, coarse, owners, out, coarse_rs, coarse_hs,
                          OWNER_STRIDE: tl.constexpr, OFFSET: tl.constexpr,
                          COUNT: tl.constexpr, TAIL: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    owner = row // (COUNT + TAIL)
    within = row % (COUNT + TAIL)
    col = tl.arange(0, BLOCK)
    fine_value = tl.load(fine + (owner * 11992 + OFFSET + within) * 896 + col,
                         (within < COUNT) & (col < 896), other=0)
    if TAIL:
        tile = tl.load(owners + owner * OWNER_STRIDE + within - COUNT,
                       within >= COUNT, other=-1)
        coarse_value = tl.load(coarse + tile * coarse_rs + (col // 128) * coarse_hs + col % 128,
                              (within >= COUNT) & (tile >= 0) & (col < 896), other=0)
        value = tl.where(within < COUNT, fine_value, coarse_value)
    else:
        value = fine_value
    tl.store(out + row * 896 + col, value, col < 896)


def produce(fine, coarse, owners, landing, start, count):
    assert fine.shape == (1, 95936, 7, 128) and fine.is_contiguous()
    assert coarse.shape == (1, 1648, 7, 128) and coarse.stride(-1) == 1
    assert owners.ndim == 2 and owners.shape[0] == 8 and owners.is_contiguous()
    tail = landing.shape[1] // 8 - count
    assert landing.shape == (1, 8 * (count + tail), 7, 128) and landing.is_contiguous()
    assert tail in (0, owners.shape[1]) and 0 <= start < start + count <= 11992
    _h3_o_chunk_produce_v2[(8 * (count + tail),)](
        fine, coarse, owners, landing, coarse.stride(1), coarse.stride(2),
        OWNER_STRIDE=owners.shape[1], OFFSET=start, COUNT=count, TAIL=tail,
        BLOCK=1024, num_warps=8)


@triton.jit
def _h3_o_gate_shared_tail_v2(fine, coarse, gate, row_map,
                            FINE_RS: tl.constexpr, COARSE_RS: tl.constexpr,
                            GATE_RS: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    col = tl.program_id(1) * BLOCK + tl.arange(0, BLOCK)
    tail_slot = tl.load(row_map + row)
    mask = (tail_slot >= 0) & (col < 7168)
    f = tl.load(fine + row * FINE_RS + col, mask, other=0)
    c = tl.load(coarse + tail_slot * COARSE_RS + col, mask, other=0)
    g = tl.load(gate + row * GATE_RS + col, mask, other=0)
    # Identical two BF16 roundings to the existing local gate kernel.
    value = tl.inline_asm_elementwise(
        '{ .reg .b32 gated; mul.rn.bf16x2 gated, $2, $3; add.rn.bf16x2 $0, $1, gated; }',
        constraints='=r,r,r,r', args=[f, c, g], dtype=tl.bfloat16,
        is_pure=True, pack=2)
    tl.store(fine + row * FINE_RS + col, value, mask)


def gate_shared_tail(bundle, tail, gate, row_map, count):
    assert bundle.shape[0] == 1 and bundle.shape[2:] == (56, 128)
    assert tail.shape == (1, 270, 56, 128)
    assert gate.shape == (1, count, 56, 128)
    assert row_map.shape == (count,) and row_map.dtype == torch.int32
    assert bundle.stride(-1) == tail.stride(-1) == gate.stride(-1) == 1
    assert bundle.stride(-2) == tail.stride(-2) == gate.stride(-2) == 128
    _h3_o_gate_shared_tail_v2[(count, 7)](
        bundle, tail, gate, row_map, FINE_RS=bundle.stride(1),
        COARSE_RS=tail.stride(1), GATE_RS=gate.stride(1), BLOCK=1024, num_warps=8)
    return bundle[:, :count]


def compact_route(plan, count):
    """CPU route: include only the coarse tiles referenced by this row chunk."""
    assert 11992 % count == 0
    routes = []
    for start in range(0, 11992, count):
        slots = plan.local_row_to_tail[:, start:start + count]
        used = [row[row >= 0].unique(sorted=True) for row in slots]
        tail = max(len(row) for row in used)
        owners = torch.full((8, tail), -1, dtype=torch.int32)
        maps = torch.full((8, count), -1, dtype=torch.int32)
        for rank in range(8):
            owners[rank, :len(used[rank])] = plan.owner_tile_ids[rank, used[rank].long()]
            valid = slots[rank] >= 0
            maps[rank, valid] = torch.searchsorted(used[rank], slots[rank, valid]).int()
            assert torch.equal(owners[rank, maps[rank, valid].long()],
                               plan.owner_tile_ids[rank, slots[rank, valid].long()])
        routes.append((owners, maps))
    return routes
