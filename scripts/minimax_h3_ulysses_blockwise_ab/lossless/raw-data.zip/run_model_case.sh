#!/usr/bin/env bash
set -euo pipefail
EXPERIMENT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
mode="${1:?bf16-base, bf16-overlap, fp8-base, fp8-overlap}"
kind="${2:?normal, stages, or nsys}"
[[ "$mode" == bf16-base || "$mode" == bf16-overlap || "$mode" == fp8-base || "$mode" == fp8-overlap ]]
export VLLM_OMNI_H3_EXPERIMENT_BLOCKWISE=0
export VLLM_OMNI_H3_EXPERIMENT_OVERLAP=0
[[ "$mode" != fp8-* ]] || export VLLM_OMNI_H3_EXPERIMENT_BLOCKWISE=1
[[ "$mode" != *-overlap ]] || export VLLM_OMNI_H3_EXPERIMENT_OVERLAP=1
SOURCE_EXPERIMENT="/lustre/raplab/client/sylarl/minimax-h3-native/experiments/h3-vsa-sage-teahouse15s-20260910"
[[ "$kind" == normal || "$kind" == stages || "$kind" == nsys ]]
export VLLM_OMNI_H3_VSA_SAGE=pr4951
# Pin the exact scale representation and the SM120 kernel validated below.
export VLLM_USE_DEEP_GEMM=0
export VLLM_OMNI_H3_PROMPT_FILE="$SOURCE_EXPERIMENT/prompt.txt"
source "$SOURCE_EXPERIMENT/prompt-geometry.env"
export VLLM_OMNI_SOURCE="$EXPERIMENT_DIR/vllm-omni"
export VLLM_OMNI_FLASHINFER_VSA_ROOT="$SOURCE_EXPERIMENT/flashinfer"
export VLLM_OMNI_FLASHINFER_VSA_WORKSPACE="$SOURCE_EXPERIMENT/cache/flashinfer"
export TRITON_CACHE_DIR="${H3_LOSSLESS_COMPILE_CACHE:-$EXPERIMENT_DIR/cache}/triton"
export TORCHINDUCTOR_CACHE_DIR="${H3_LOSSLESS_COMPILE_CACHE:-$EXPERIMENT_DIR/cache}/inductor"
export XDG_CACHE_HOME="$EXPERIMENT_DIR/cache/xdg"
export VLLM_CACHE_ROOT="$EXPERIMENT_DIR/cache/vllm"
export CUDA_CACHE_PATH="$EXPERIMENT_DIR/cache/cuda"
export OMP_NUM_THREADS=28
export MAX_JOBS=8
export VLLM_OMNI_OUTPUT_DIR="$EXPERIMENT_DIR/runs/${H3_EXPERIMENT_RUN_TAG:-$mode-$kind}"
export VLLM_OMNI_UPLOAD_VIDEOS=0
export VLLM_OMNI_GPU_BALANCE_HEALTH_GATE=0
export VLLM_OMNI_PORT=8091
export VLLM_OMNI_WARMUPS="${H3_EXPERIMENT_WARMUPS:-1}"
export VLLM_OMNI_MINIMAX_H3_FP8_SCOPE=none
export VLLM_OMNI_FLASHINFER_ULYSSES_QKV_E4M3_TRANSPORT=0
export VLLM_OMNI_FASTVIDEO_VSA_SKIP_SOFTMAX_THRESHOLD_SCALE_FACTOR=0
# The base action pins h3-vae and rejects the TAEH3-only override variable.
unset VLLM_OMNI_MINIMAX_H3_VIDEO_DECODE_BACKEND
export VLLM_OMNI_FASTVIDEO_VSA_O_BUNDLE=1
export VLLM_OMNI_FASTVIDEO_VSA_GATE_COMPUTE_OVERLAP=0
export VLLM_OMNI_MINIMAX_H3_VAE_TEMPORAL_PRE_GATHER_PRUNE=0
export VLLM_OMNI_MINIMAX_H3_VAE_TEMPORAL_CHUNK_PARALLEL=0
export VLLM_OMNI_MINIMAX_H3_VAE_DECODER_TILE_SIZE=0
export VLLM_OMNI_MINIMAX_H3_QCHUNK_PIPELINE=0
export VLLM_OMNI_FLASHINFER_ULYSSES_RELEASE_AFTER_DENOISE=1
mkdir -p "$VLLM_OMNI_OUTPUT_DIR"
if [[ "$kind" != nsys ]]; then
  export VLLM_OMNI_REPEATS="${H3_EXPERIMENT_REPEATS:-3}"
  export VLLM_OMNI_ENABLE_DIFFUSION_PIPELINE_PROFILER=0
  if [[ "$kind" == stages ]]; then
    export VLLM_OMNI_ENABLE_DIFFUSION_PIPELINE_PROFILER=1
  fi
  export VLLM_OMNI_MINIMAX_H3_VSA_NVTX=0
  export VLLM_OMNI_MINIMAX_H3_NVTX_DENOISE_STEP=0
  export VLLM_OMNI_MINIMAX_H3_NVTX_DECODE_REQUEST=0
  unset VLLM_OMNI_NSYS_INTERACTIVE_SESSION VLLM_OMNI_NSYS_INTERACTIVE_OUTPUT
else
  export VLLM_OMNI_REPEATS=1
  export VLLM_OMNI_ENABLE_DIFFUSION_PIPELINE_PROFILER=1
  export VLLM_OMNI_MINIMAX_H3_VSA_NVTX=1
  export VLLM_OMNI_MINIMAX_H3_NVTX_DENOISE_STEP=3
  export VLLM_OMNI_MINIMAX_H3_NVTX_DECODE_REQUEST=2
  export VLLM_OMNI_NSYS_BIN="$SOURCE_EXPERIMENT/nsys_with_metrics.sh"
  export VLLM_OMNI_NSYS_INTERACTIVE_SESSION="h3overlap-${mode}-$(date -u +%H%M%S)"
  export VLLM_OMNI_NSYS_INTERACTIVE_OUTPUT="$VLLM_OMNI_OUTPUT_DIR/$mode-warmed"
fi
env | sort | rg '^(VLLM_OMNI_|OMP_NUM_THREADS=|TRITON_CACHE_DIR=|TORCHINDUCTOR_CACHE_DIR=|XDG_CACHE_HOME=|CUDA_CACHE_PATH=)' > "$VLLM_OMNI_OUTPUT_DIR/experiment-env.txt"
exec bash "$EXPERIMENT_DIR/benchmark_h3_ab.sh" vllm-omni-tp1-sp8-fasth3-vsa-flashinfer-topk162-rdma-qk-direct
