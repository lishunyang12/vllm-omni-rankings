"""Derive gate-v2 full-model evidence after numerical qualification finishes."""
import datetime,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def status(state,**extra):
    result=dict(state=state,at=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra)
    (ROOT/'postprocess-status.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

def run(label,args):
    with (ROOT/f'postprocess-{label}.log').open('w') as f:subprocess.run(args,check=True,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
    print('Completed',label,flush=True)

try:
    status('waiting_for_fixed_campaign')
    while True:
        p=ROOT/'fixed-campaign-status.json'
        if p.exists():
            result=json.loads(p.read_text());assert result['state']!='failed',result.get('error')
            if result['state']=='completed':break
        time.sleep(10)
    status('processing');os.environ['OMP_NUM_THREADS']='4';os.environ['MPLCONFIGDIR']=str(ROOT/'cache/matplotlib')
    run('nsys',[sys.executable,str(ROOT.parent/'analyze_run.py'),str(ROOT/'runs/v2-gate-nsys')])
    run('timeline',[sys.executable,str(ROOT/'analyze_gate_timeline.py')])
    run('report',[sys.executable,str(ROOT/'build_report.py')])
    status('ready_for_browser_review')
except BaseException as error:
    status('failed',error=repr(error));raise
