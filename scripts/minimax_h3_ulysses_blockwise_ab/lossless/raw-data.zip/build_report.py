"""Full-model lossless evidence with frozen compiler selections, plus bounded micros."""
import csv,difflib,hashlib,html,json,shutil,statistics,subprocess,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parent
OUT=ROOT/'report'
EXPECTED='aa55fa19de94066e999f04275362f5477b3d74eb925d45fece8918d1cc8f596a'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read_run(tag):
    run=ROOT/'runs'/tag
    summary,=list(csv.DictReader((run/'summary.tsv').open(),delimiter='\t'))
    assert summary['status']=='ok'
    case=run/summary['case'];n=1 if tag.endswith('nsys') else 3
    samples=[float((case/f'measured-{i}-e2e-seconds.txt').read_text()) for i in range(1,n+1)]
    health=json.loads((case/'gpu-health-pre-balance.json').read_text());assert health['status']=='passed'
    for i in range(1,n+1):
        assert (case/f'measured-{i}-gpu-exclusivity-preflight.txt').read_text().strip().endswith(' exclusive')
        assert (case/f'measured-{i}-foreign-gpu-processes.log').stat().st_size==0
    videos=sorted(case.glob('out_t2va1*.mp4'));assert len(videos)==n
    identities=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in videos]
    assert all(v['sha256']==EXPECTED for v in identities)
    cache=json.loads((run/'compile-config-contract.json').read_text());assert cache['status']=='passed'
    hardware=[{k:g[k] for k in ('index','uuid','pci.bus_id','gpu.power.current_limit','gpu.power.default_limit')} for g in health['samples'][0]['gpus']]
    contract=dict(hardware=hardware,model_diff_sha256=sha(run/'source-git-diff.patch'),untracked_sources_sha256=sha(run/'source-untracked-sha256.txt'),benchmark_sha256=(run/'executed-benchmark-script.sha256').read_text().split()[0])
    return dict(tag=tag,samples_s=samples,mean_s=statistics.mean(samples),median_s=statistics.median(samples),summary=summary,videos=identities,contract=contract,cache_contract_sha256=sha(run/'compile-config-contract.json'))


def main():
    assert json.loads((ROOT/'fixed-campaign-status.json').read_text())['state']=='completed'
    OUT.mkdir(exist_ok=True)
    tags=('v1-fixed-cache-normal','v2-gate-normal','v2-gate-stages','v2-gate-nsys')
    runs=[read_run(t) for t in tags]
    assert all(r['contract']==runs[0]['contract'] for r in runs)
    old_data=json.loads((PARENT/'summary/report-data.json').read_text())
    old_mean=next(r['mean_s'] for r in old_data['latencies'] if r['mode']=='bf16-base' and r['measurement']=='normal')
    new_mean=runs[1]['mean_s'];control=runs[0]['mean_s']
    reductions=dict(v2_vs_fresh_v1_percent=100*(1-new_mean/control),v2_vs_original_bf16_base_percent=100*(1-new_mean/old_mean),v2_vs_fresh_v1_seconds=control-new_mean)
    old_stage,=list(csv.DictReader((PARENT/'runs/bf16-overlap-stages/summary.tsv').open(),delimiter='\t'))
    stages=[dict(name=label,baseline_s=float(old_stage[field]),candidate_s=float(runs[2]['summary'][field])) for label,field in [('Encoder','encoder_s'),('DiT','dit_s'),('Decode total','decode_total_s'),('Video VAE path','video_vae_path_s'),('Audio VAE','audio_vae_s')]]
    timelines=json.loads((OUT/'gate-timelines.json').read_text())
    drift=json.loads((ROOT/'control-drift-quality.json').read_text())
    data=dict(runs=runs,reductions=reductions,stages=stages,stage_scope='Baseline stages from earlier v1 four-way campaign, candidate stages collected independently; no profiling latency substituted for normal requests.',video_sha256=EXPECTED,video_and_audio='All formal MP4 bytes match both fresh v1 control and original BF16 videos; this implies identical encoded video/audio and decoded pixels/PCM for the same decoder.',gate_timelines=timelines,compile_drift=dict(config_differences=json.loads((ROOT/'compile-config-differences.json').read_text()),cache_control=json.loads((ROOT/'cache-control-status.json').read_text()),fresh_cache_diagnostic_video_sha256=drift['inputs']['candidate'].get('sha256'),note='Initial cache-cold v1 control is excluded from speed/lossless claims: its output changed with gate overlap disabled. Six previously selected RMSNorm reduction configurations differed. Reusing a copy of the original compiler cache restored the original MP4; formal A/B pins and checks those selections.'))
    (OUT/'data.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
    with (OUT/'latencies.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['tag','mean_s','median_s','samples_s']);w.writeheader();w.writerows({k:r[k] for k in w.fieldnames} for r in runs)
    with (OUT/'stages.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(stages[0]));w.writeheader();w.writerows(stages)
    for i,name in [(0,'v1-control'),(1,'v2-gate')]:shutil.copy2(runs[i]['videos'][0]['path'],OUT/(name+'.mp4'))
    trace,=(ROOT/'runs/v2-gate-nsys').glob('*.nsys-rep');shutil.copy2(trace,OUT/'v2-gate-warmed.nsys-rep')
    for name in ('micro-v1.json','compile-config-differences.json','control-drift-quality.json','communication-options.md','transport-capacity.json'):shutil.copy2(ROOT/name,OUT/name)
    # Incremental patch against the first, already tested overlap candidate.
    repo=ROOT/'vllm-omni';base=PARENT/'vllm-omni';patch=''
    for rel in ('vllm_omni/diffusion/models/minimax_h3/minimax_h3_transformer.py','vllm_omni/diffusion/attention/ops/h3_overlap_experiment.py'):
        patch+=''.join(difflib.unified_diff((base/rel).read_text().splitlines(True),(repo/rel).read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
    (OUT/'gate-incremental.patch').write_text(patch)
    header=['方法','无 profiler E2E / s','三个样本 / s']
    latency=''.join('<tr><td>'+label+'</td><td>'+f"{r['mean_s']:.3f}"+'</td><td>'+', '.join(f'{v:.3f}' for v in r['samples_s'])+'</td></tr>' for label,r in [('v1 重叠，固定编译配置',runs[0]),('v2 加入 gate GEMM 重叠',runs[1])])
    stage_rows=''.join(f"<tr><td>{r['name']}</td><td>{r['baseline_s']:.3f}</td><td>{r['candidate_s']:.3f}</td></tr>" for r in stages)
    micro=json.loads((ROOT/'micro-v1.json').read_text())
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,2,figsize=(13,7))
    for ax,(key,title) in zip(axes.flat,[('forward','Forward preparation'),('reverse','Reverse O'),('projection','QKV projection split'),('gate','Unchanged gate GEMM')]):
        timings=micro[key]['timings'];labels=list(timings);means=[timings[k]['mean_ms'] for k in labels];std=[timings[k]['stdev_ms'] for k in labels]
        ax.barh(labels,means,xerr=std,color=['#607d89']+['#3a8c85']*(len(labels)-1),capsize=3)
        for i,m in enumerate(means):ax.text(m+std[i]+.15,i,f'{m:.3f}',va='center',fontsize=8)
        ax.invert_yaxis();ax.set_title(title,loc='left');ax.set_xlabel('max-rank wall ms; mean ± sample SD');ax.set_xlim(0,max(means)*1.17);ax.grid(axis='x',alpha=.2)
    fig.tight_layout();fig.savefig(OUT/'lossless-micros.svg');fig.savefig(OUT/'lossless-micros.png',dpi=130)
    old_stage_e2e=next(r['mean_s'] for r in old_data['latencies'] if r['mode']=='bf16-overlap' and r['measurement']=='stages')
    fig2,ax2=plt.subplots(figsize=(12,2.8))
    palette={'Encoder':'#b7c6be','DiT':'#607d89','Decode':'#d6a16f','Other':'#d9dcd8'}
    for i,(label,row,total) in enumerate([('v1 stage run',old_stage,old_stage_e2e),('v2 stage run',runs[2]['summary'],runs[2]['mean_s'])]):
        values=[float(row[k]) for k in ('encoder_s','dit_s','decode_total_s')];values.append(total-sum(values));offset=0
        for (name,color),value in zip(palette.items(),values):
            ax2.barh(i,value,left=offset,color=color,label=name if i==0 else None)
            if value>.5:ax2.text(offset+value/2,i,f'{value:.3f} s',ha='center',va='center',fontsize=9,color='white' if name=='DiT' else '#252c2d')
            offset+=value
        ax2.text(total+.1,i,f'{total:.3f} s',va='center',fontsize=9)
    ax2.set_yticks([0,1],['v1 stage run','v2 stage run']);ax2.invert_yaxis();ax2.set_xlim(0,max(old_stage_e2e,runs[2]['mean_s'])*1.1)
    ax2.set_xlabel('Independent profiler-enabled stage measurements / seconds');ax2.legend(loc='lower left',bbox_to_anchor=(0,1.02),ncol=4,fontsize=9)
    fig2.tight_layout();fig2.savefig(OUT/'stage-breakdown.svg');fig2.savefig(OUT/'stage-breakdown.png',dpi=140)
    page=f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>H3 · 无损 gate 通信重叠</title><link rel="stylesheet" href="../page.css"></head><body><main><div class="eyebrow">H3 / BF16 / SM120 × 8 / LOSSLESS GATE OVERLAP</div><h1>把 gate GEMM 放入 Q/K 传输期间</h1><p>沿用相同的 Cake attention、BF16 主干线性层、Q/K 预处理与四段 O 重叠，只改变 Gc 投影的执行 stream。精度、矩阵形状、权重、通信字节数及 RDMA 完成协议保持一致。</p><p class="note">相对同轮 v1 对照，正常请求耗时下降 {reductions['v2_vs_fresh_v1_percent']:.2f}%（{reductions['v2_vs_fresh_v1_seconds']:.3f} s）；相对前序 BF16 原调度累计下降 {reductions['v2_vs_original_bf16_base_percent']:.2f}%。单 prompt、seed 1101、362 帧，每组预热一次并正式测三次。该组全部正式视频与音频文件逐字节一致。</p>
<section><div class="videos"><article class="card" style="--tone:#607d89"><div class="card-head"><h3>v1 固定编译配置</h3></div><video id="control" controls playsinline preload="metadata" src="v1-control.mp4"></video></article><article class="card" style="--tone:#3a8c85"><div class="card-head"><h3>v2 gate 重叠</h3></div><video id="candidate" controls playsinline preload="metadata" src="v2-gate.mp4" muted></video></article></div><div class="controls"><div class="control-row"><button id="play">同步播放</button><button id="pause">全部暂停</button><button data-seek="1">1 s</button><button data-seek="4.5">4.5 s</button><button data-seek="9">9 s</button><button data-seek="14">14 s</button></div><p class="note">默认只播放 v1 音轨；两个 MP4 的 SHA256 完全相同。</p></div></section>
<section class="panel"><h2>完整请求与独立阶段计时</h2><a href="stage-breakdown.svg"><img class="gallery" src="stage-breakdown.svg" alt="v1 和 v2 的独立 Encoder、DiT、Decode 阶段耗时对照"></a><div class="table-wrap"><table id="lossless-latencies"><thead><tr>{''.join('<th>'+x+'</th>' for x in header)}</tr></thead><tbody>{latency}</tbody></table></div><div class="table-wrap"><table><thead><tr><th>阶段</th><th>前序 v1 / s</th><th>v2 / s</th></tr></thead><tbody>{stage_rows}</tbody></table></div><p class="note">阶段基线来自前序 v1 的独立计时，v2 单独采集。Video/Audio VAE 已包含在 Decode 内，不能再次求和。性能结论使用关闭 profiler 的正常请求。</p></section>
<section class="panel"><h2>实际完整模型 GPU 7 · 第 3 步第 0 层</h2><a href="gate-timelines.svg"><img class="gallery" src="gate-timelines.svg" alt="QKV 与 gate GEMM、QK norm 和 RDMA 时间线及 SM、PCIe 原始采样"></a><p class="note">v2 gate 通过 NVTX 和 CUDA API 关联定位，v1 两个 GEMM 按源码顺序归属。从 QKV 投影开始到最后一个前向 RDMA 窗口结束，v1 为 {timelines[0]["projection_through_qkv_transfer_ms"]:.3f} ms，v2 为 {timelines[1]["projection_through_qkv_transfer_ms"]:.3f} ms。Gate 与通信窗口重叠 {timelines[1]["gate_overlap_ms"]:.3f} ms；窗口是前后 barrier 之间的区间，也包含完成及调度等待，不代表整个区间 PCIe 持续搬运。指标曲线是单个采样点，不是区间平均。Nsight 耗时不用于端到端加速结论。</p><a href="v2-gate-warmed.nsys-rep">下载 v2 原生 Nsight</a></section>
<section class="panel"><h2>传输带宽的边界</h2><p>各 GPU 自动选择不同的邻近 400 Gb/s RDMA 端口。前序基线 GPU 7 的 QKV 有效发送率为 47.44 GB/s，约为单端口名义 50 GB/s 的 94.9%。在相同载荷下，单纯提升带宽的余量有限；这些是逻辑载荷与端口速率的比较，不是把 PCIe 的单个采样值当成平均利用率。</p></section><section class="panel"><h2>Gc 与 Gf</h2><p>大 GEMM：X [11992,5376] × Wqkvᵀ [5376,21504]，一次输出 Q/K/V。小 GEMM：X × Wgateᵀ [5376,7168]，输出 Gc。</p><p>此 H3 路径执行 O = Oc ⊙ Gc + Of，即 Gf = 1，没有独立的 Gf 投影。v2 保留原 BF16 gate GEMM 与合并时的 BF16 乘法、加法舍入。</p></section>
<section class="panel"><h2>无损还需要固定编译选核</h2><p>最初新缓存下的 v1 对照在关闭 gate 优化时也改变了输出。检查发现六处 RMSNorm 归约配置不同，例如 R0_BLOCK 从 8192 变为 4096，浮点求和顺序随之变化。使用前序编译缓存的副本恢复了原始视频。</p><p>本页正式 A/B 固定并检查全部原有选核配置；初次缓存实验作为诊断记录保留，不混入性能均值。无损结论限定于相同编译配置、模型和测试输入，尚未覆盖任意 batch、分辨率或长时间服务。</p></section>
<section class="panel"><h2>其他候选的八卡微测</h2><img class="gallery" src="lossless-micros.svg" alt="四类独立八卡无损候选的微基准"><p class="note">合成 H3 形状，真实 RDMA；8 个交错试验，每个试验 8 次，均值为每次测量八卡最慢的墙钟时间。每种可用方案先在八卡、三种输入模式上逐位核对。仅 gate 调度集成并完成上述完整模型验证。</p><p>提前处理 Q 未显示进一步收益；coarse tail 只传一次可少传 10,160,640 字节/卡/层，但耗时改善很小。8 段 O 的 gate 结果一致、O 投影结果不逐位一致，已排除。QKV 拆分微测通过逐位检查并有收益，尚未纳入完整模型方案；它会与 gate 竞争计算资源和同一通信窗口，收益不能直接相加。</p></section>
<section class="panel"><h2>复现与原始证据</h2><div class="links"><a href="data.json">完整数据与文件哈希</a><a href="latencies.csv">正常耗时 CSV</a><a href="stages.csv">阶段 CSV</a><a href="micro-v1.json">八卡微测</a><a href="communication-options.md">其他通信候选与边界</a><a href="transport-capacity.json">GPU / 网卡映射与端口速率</a><a href="gate-incremental.patch">在 v1 补丁上应用的 gate 增量</a><a href="raw-data.zip">原始记录与脚本</a><a href="../index.html">四组 FP8 / BF16 A/B</a></div><p class="note">相同视频 SHA256：<code>{EXPECTED}</code></p></section></main><script src="player.js"></script></body></html>'''
    (OUT/'index.html').write_text(page)
    (OUT/'player.js').write_text("""const vs=[...document.querySelectorAll('video')];let playing=false;
function seek(t){vs.forEach(v=>v.currentTime=t)}
document.querySelector('#play').onclick=async()=>{seek(vs[0].currentTime);vs[0].muted=false;vs[1].muted=true;try{await Promise.all(vs.map(v=>v.play()));playing=true}catch(e){vs.forEach(v=>v.pause());playing=false}};
document.querySelector('#pause').onclick=()=>{playing=false;vs.forEach(v=>v.pause())};
document.querySelectorAll('[data-seek]').forEach(b=>b.onclick=()=>seek(Number(b.dataset.seek)));
function tick(){if(playing&&Math.abs(vs[1].currentTime-vs[0].currentTime)>.12)vs[1].currentTime=vs[0].currentTime;requestAnimationFrame(tick)}tick();
""")
    readme=f'''# H3 BF16 gate GEMM overlap

[同步视频、完整数据和 GPU 时间线](index.html)

在固定编译选核下，正常请求从 {control:.6f} s 降到 {new_mean:.6f} s，
额外减少 {reductions['v2_vs_fresh_v1_percent']:.3f}% / {reductions['v2_vs_fresh_v1_seconds']:.6f} s。
相对前序 BF16 原调度累计减少 {reductions['v2_vs_original_bf16_base_percent']:.3f}%。
两个调度各预热一次、正式测三次，全部正式 MP4 与原 BF16 视频逐字节一致。
单个 prompt、seed 1101、362 帧、4 denoise steps；不推及任意输入或独立重新调优的编译缓存。

| 调度 | 三个正常请求 / s |
|---|---|
| v1，固定缓存 | {runs[0]['samples_s']} |
| v2，gate 重叠 | {runs[1]['samples_s']} |

小 GEMM 只计算 Gc = X Wgateᵀ，形状 M11992 N7168 K5376。
合并为 O = Oc ⊙ Gc + Of，即 Gf = 1。新的执行顺序让相同的 BF16 GEMM
在 Q/K RDMA 传输期间运行；完整 gate/O 数值、通信字节数及完成协议保持一致。

[阶段耗时](stages.csv)来自独立计时；前序 v1 阶段基线与本次 v2 阶段测量分开记录。
[GPU 时间线](gate-timelines.svg)包含 QKV/Gate GEMM、QK norm/RoPE、RDMA 窗口及原始计数器采样。
[原生 Nsight](v2-gate-warmed.nsys-rep)的耗时不用于正常请求加速结论。
这一层从 QKV GEMM 开始到最后的前向通信窗口结束，
由 {timelines[0]["projection_through_qkv_transfer_ms"]:.3f} ms 缩到 {timelines[1]["projection_through_qkv_transfer_ms"]:.3f} ms。
Gate 与通信窗口重叠 {timelines[1]["gate_overlap_ms"]:.3f} ms；窗口包含完成或调度等待，
不能将其全部视为 PCIe 持续搬运时间。

[增量补丁](gate-incremental.patch)应用在[前序候选补丁](../candidate.patch)之后。
源码和执行脚本在[原始记录](raw-data.zip)，正常请求、哈希、源码和硬件身份在[data.json](data.json)。
同一模型树下设 VLLM_OMNI_H3_LOSSLESS_GATE=0/1，配合
VLLM_OMNI_H3_EXPERIMENT_OVERLAP=1；run_model_case.sh 的 bf16-overlap 模式设置后者。
H3_LOSSLESS_COMPILE_CACHE 指向原始 Inductor/Triton 缓存的副本。
正式执行前后均检查原有的80个选核配置；新缓存控制产生的变化独立留作诊断证据。

[其他无损候选](communication-options.md)：QKV 拆分通过算子微测但未集成进此完整模型方案；
O8段未通过逐位一致性；coarse tail复用减少字节但耗时提升很小。
'''
    (OUT/'README.md').write_text(readme)
    files=[]
    for run in (ROOT/'runs').iterdir():
        if run.name not in tags:continue
        for p in run.rglob('*'):
            if not p.is_file() or p.name in ('environment.txt','experiment-env.txt','vllm-serve-help.txt'):continue
            if p.suffix in ('.json','.csv','.tsv','.log','.sha256','.patch') or p.name.startswith('measured-') or p.name in ('config.txt','server-command.txt','request.txt'):files.append(p)
    files += list(ROOT.glob('*.py'))+list(ROOT.glob('*.sh'))+list(ROOT.glob('*.cjs'))
    files += [ROOT/name for name in ('micro-v1.json','micro-status.json','foreign-process-observations.json','fixed-campaign-status.json','cache-control-status.json','compile-config-differences.json','control-drift-quality.json','transport-capacity.json','communication-options.md')]
    files += [PARENT/'compile-config-snapshot.json']
    with zipfile.ZipFile(OUT/'raw-data.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else 'original-'+p.name)
    print(json.dumps(reductions,indent=2))

if __name__=='__main__':main()
