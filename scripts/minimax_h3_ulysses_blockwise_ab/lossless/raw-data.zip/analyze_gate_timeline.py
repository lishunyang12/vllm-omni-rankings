"""Include QKV/gate projections when comparing actual full-model schedules."""
import csv,json,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent))
from analyze_model_timeline import extract
from analyze_trace import overlap_ns


def one(label,run,is_gate):
    result=extract('bf16-overlap',run)
    s=result['summary'];first=s['gpu_start_ns'];pid=result['kernels'][0]['pid']
    path,=run.glob('*.sqlite')
    with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as db:
        strings=dict(db.execute('select id,value from StringIds'))
        rows=[dict(start=a,end=b,stream=st,pid=p,corr=c,name=strings[n]) for a,b,st,p,c,n in db.execute('select start,end,streamId,globalPid,correlationId,demangledName from CUPTI_ACTIVITY_KIND_KERNEL where globalPid=? order by start',(pid,))]
        gemms=[r for r in rows if any(t in r['name'].lower() for t in ('gemm','cublas','matmul'))]
        if is_gate:
            runtime={(p&~0xffffff,c):dict(start=a,end=b,tid=p) for a,b,p,c in db.execute('select start,end,globalTid,correlationId from CUPTI_ACTIVITY_KIND_RUNTIME') if p is not None and c is not None}
            scopes=[dict(start=a,end=b,tid=t) for a,b,t,lit,sid in db.execute('select start,end,globalTid,text,textId from NVTX_EVENTS where end is not null') if (lit or strings.get(sid,''))=='h3.lossless.gate_gemm']
            gates=[]
            for r in gemms:
                api=runtime.get((r['pid'],r['corr']))
                if api and any(v['tid']==api['tid'] and v['start']<=api['start']<=api['end']<=v['end'] for v in scopes):gates.append(r)
            gate,=[r for r in gates if first-15e6<r['start']<result['transfers'][2]['end']]
            qkv=[r for r in gemms if r['end']<=first and r is not gate][-1]
        else:qkv,gate=[r for r in gemms if r['end']<=first][-2:]
        start=qkv['start'];end=result['transfers'][2]['end']
        norms=[r for r in rows if start<=r['start'] and r['end']<=end and '_rms_norm_rope_kernel' in r['name']]
        assert len(norms)==2,norms
        type_id,=db.execute('select distinct typeId from TARGET_INFO_GPU_METRICS where (typeId & 4294967295)=?',(s['metric_instance'],)).fetchone()
        samples=[dict(timestamp=t,metric=m,raw_percent=v) for t,m,v in db.execute('select timestamp,metricId,value from GPU_METRICS where typeId=? and timestamp>=? and timestamp<=? and metricId in (7,21,22) order by timestamp,metricId',(type_id,start,end))]
    windows=[w for w in result['transfers'] if w['phase']=='QKV']
    result=dict(label=label,source=str(path),physical_gpu=7,step=3,layer=0,start_ns=start,end_ns=end,
                qkv=qkv,gate=gate,norms=norms,windows=windows,samples=samples,
                qkv_gemm_ms=(qkv['end']-qkv['start'])/1e6,gate_gemm_ms=(gate['end']-gate['start'])/1e6,
                gate_overlap_ms=overlap_ns([(gate['start'],gate['end'])],[(w['start'],w['end']) for w in windows])/1e6,
                projection_through_qkv_transfer_ms=(end-start)/1e6,
                method='GPU7 step3layer0. Gate-v2 identity from gate NVTX and CUDA API correlation; previous gate and fused QKV inferred from model source order. RDMA windows span the opening-barrier end to closing-barrier start and may include completion/scheduling waits: gate_overlap_ms is overlap with these windows, not measured PCIe payload-active duration. Raw sampled counters, not interval averages. Diagnostic trace timings, not normal-request speed claims.')
    return result


def main():
    out=ROOT/'report';out.mkdir(exist_ok=True)
    results=[one('v1 overlap',ROOT.parent/'runs/bf16-overlap-nsys',False),one('v2 gate overlap',ROOT/'runs/v2-gate-nsys',True)]
    (out/'gate-timelines.json').write_text(json.dumps(results,indent=2)+'\n')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(4,1,figsize=(13,7),gridspec_kw={'height_ratios':[1.4,1,1.4,1]})
    for i,r in enumerate(results):
        start=r['start_ns'];ax=axes[2*i];metrics=axes[2*i+1]
        for y,key,color in [(3,'qkv','#607d89'),(2,'gate','#bc774c')]:
            item=r[key];ax.broken_barh([((item['start']-start)/1e6,(item['end']-item['start'])/1e6)],(y-.25,.5),facecolors=color)
        for item in r['norms']:ax.broken_barh([((item['start']-start)/1e6,(item['end']-item['start'])/1e6)],(.75,.5),facecolors='#795aae')
        for item,name in zip(r['windows'],('Q','K','V')):
            x=(item['start']-start)/1e6;w=(item['end']-item['start'])/1e6
            ax.broken_barh([(x,w)],(-.25,.5),facecolors='#3b80b5');ax.text(x+w/2,0,name,ha='center',va='center',fontsize=8,color='white')
        ax.set_yticks([0,1,2,3],['RDMA window','Q/K norm+RoPE','Gate GEMM','QKV GEMM']);ax.set_ylim(-.5,3.5)
        ax.set_title(r['label']+' | GPU7 step3/layer0 | gate/window overlap '+f"{r['gate_overlap_ms']:.3f} ms",loc='left')
        for metric,label,color in [(7,'SM active','#3a9779'),(21,'PCIe RX','#3b80b5'),(22,'PCIe TX','#bc774c')]:
            points=[v for v in r['samples'] if v['metric']==metric];metrics.plot([(v['timestamp']-start)/1e6 for v in points],[v['raw_percent'] for v in points],'.-',lw=1,markersize=2,color=color,label=label)
        metrics.set_ylim(-3,103);metrics.set_ylabel('% sample');metrics.legend(loc='upper right',ncol=3,fontsize=8)
        for target in (ax,metrics):target.set_xlim(0,32);target.grid(axis='x',alpha=.2)
        metrics.set_xlabel('ms since fused QKV GEMM start')
    fig.text(.5,.004,'RDMA window includes completion / scheduling waits; its full length is not continuous PCIe payload activity.',ha='center',fontsize=8)
    fig.tight_layout(rect=(0,.025,1,1));fig.savefig(out/'gate-timelines.svg');fig.savefig(out/'gate-timelines.png',dpi=140)
    print(json.dumps([{k:v for k,v in r.items() if k.endswith('_ms') or k=='label'} for r in results],indent=2))

if __name__=='__main__':main()
