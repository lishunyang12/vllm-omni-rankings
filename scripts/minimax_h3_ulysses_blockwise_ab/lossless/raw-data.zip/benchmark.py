"""Paired real-SP8 measurements for additional bitwise-preserving schedules."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent))
import torch
import torch.distributed as dist
from flashinfer.comm import UlyssesCommunicator
from benchmark_overlap import barrier, compare, log, measure
from support import geometry, source_helpers, h3_vsa_tile_pack
from chunked_o import produce as old_produce, gate_chunk as old_gate
from chunk_ops import produce, gate_shared_tail, compact_route
from vllm_omni.diffusion.attention.ops.minimax_h3_vsa_o_bundle import (
    h3_vsa_o_bundle_out, h3_vsa_o_bundle_local_gate_add_,
    _h3_vsa_o_bundle_local_gate_kernel,
)


def forward(comm, device, helpers, maps, sizes, args):
    main, side = torch.cuda.current_stream(), torch.cuda.Stream()
    projected = torch.randn(1,11992,3,56,128,device=device,dtype=torch.bfloat16)
    local = [projected[:,:,i] for i in range(3)]
    outs = [comm.allocate_output(x.contiguous(),'scatter_heads') for x in local]
    landings = [comm.input_buffer(out,(1,11992,56,128)) for out in outs]
    for dst,src in zip(landings[:2],local[:2]):dst.copy_(src)

    def pack_pool(index):
        packed=h3_vsa_tile_pack(outs[index][:,:95924],maps)
        return packed,helpers['_pool_h3_tiles'](packed,sizes)

    def metadata(qp,kp):
        scores=torch.matmul(qp,kp.transpose(-2,-1))*128**-.5
        idx,num=helpers['_build_h3_ordered_q2k_indices'](scores,28,1620,162)
        return scores,idx,num

    def run(mode):
        with torch.cuda.nvtx.range('lossless.v2.forward.'+mode):
            comm.scatter_heads(landings[0],out=outs[0])
            if mode=='q_during_k':
                side.wait_stream(main)
                with torch.cuda.stream(side),torch.cuda.nvtx.range('lossless.v2.q_prepare'):
                    qt,qp=pack_pool(0)
            comm.scatter_heads(landings[1],out=outs[1])
            landings[2].copy_(local[2])
            if mode!='serial':
                side.wait_stream(main)
                with torch.cuda.stream(side),torch.cuda.nvtx.range('lossless.v2.k_routing_prepare'):
                    if mode!='q_during_k':qt,qp=pack_pool(0)
                    kt,kp=pack_pool(1)
                    scores,idx,num=metadata(qp,kp)
            with torch.cuda.nvtx.range('lossless.v2.v_rdma'):
                comm.scatter_heads(landings[2],out=outs[2])
            if mode=='serial':
                qt,qp=pack_pool(0);kt,kp=pack_pool(1)
                scores,idx,num=metadata(qp,kp)
            else:
                main.wait_stream(side)
                for tensor in (qt,kt,qp,kp,scores,idx,num):tensor.record_stream(main)
            vt=h3_vsa_tile_pack(outs[2][:,:95924],maps)
            return qt,kt,qp,kp,scores,idx,num,vt

    checks=[]
    for pattern in range(3):
        projected.normal_()
        if pattern:projected[:,::(17+pattern)].zero_()
        for dst,src in zip(landings[:2],local[:2]):dst.copy_(src)
        ref=run('serial');torch.cuda.synchronize()
        for mode in ('qk_during_v','q_during_k'):
            out=run(mode);torch.cuda.synchronize()
            equal=[bool(torch.equal(a.view(torch.uint8),b.view(torch.uint8))) for a,b in zip(ref,out)]
            assert all(equal),(dist.get_rank(),pattern,mode,equal)
            checks.append(dict(pattern=pattern,mode=mode,all_operands_and_metadata_bitwise=equal))
            del out
        del ref
    cases={name:(lambda name=name:run(name)) for name in ('serial','qk_during_v','q_during_k')}
    timings=measure(cases,args)
    gathered=[None]*8;dist.all_gather_object(gathered,checks)
    return dict(timings=timings,checks_by_rank=gathered,
                remote_payload_bytes=451282944,
                scope='Identical Q/K/V packed operands, pooled operands, scores and sparse metadata; actual RDMA, no fine attention in timing.')


def projection_overlap(comm,device,args):
    main,side=torch.cuda.current_stream(),torch.cuda.Stream()
    x=torch.randn(11992,5376,device=device,dtype=torch.bfloat16)
    weight=torch.randn(21504,5376,device=device,dtype=torch.bfloat16)*.01
    prototype=torch.empty(1,11992,56,128,device=device,dtype=torch.bfloat16)
    outs=[comm.allocate_output(prototype,'scatter_heads') for _ in range(3)]
    landings=[comm.input_buffer(out,prototype.shape) for out in outs]

    def run(split):
        with torch.cuda.nvtx.range('lossless.v2.projection.split'+str(int(split))):
            if split:
                qk=torch.nn.functional.linear(x,weight[:14336]).view(1,11992,2,56,128)
                q,k=qk[:,:,0],qk[:,:,1]
            else:
                qkv=torch.nn.functional.linear(x,weight).view(1,11992,3,56,128)
                q,k,v=qkv[:,:,0],qkv[:,:,1],qkv[:,:,2]
            # Stand-in staging only: real QK norm/RoPE is excluded from this
            # bounded operator experiment and must be validated in integration.
            landings[0].copy_(q);landings[1].copy_(k)
            if split:
                side.wait_stream(main)
                with torch.cuda.stream(side):
                    v=torch.nn.functional.linear(x,weight[14336:]).view(1,11992,56,128)
            comm.scatter_heads(landings[0],out=outs[0])
            comm.scatter_heads(landings[1],out=outs[1])
            if split:
                main.wait_stream(side);v.record_stream(main)
            landings[2].copy_(v)
            comm.scatter_heads(landings[2],out=outs[2])
        return outs

    checks=[]
    for pattern in range(3):
        x.normal_()
        if pattern:x[::(17+pattern)].zero_()
        run(False);torch.cuda.synchronize();ref=[r.clone() for r in outs]
        run(True);torch.cuda.synchronize()
        stats=[compare(a,b) for a,b in zip(ref,outs)]
        checks.append(dict(pattern=pattern,qkv=stats));del ref
    gathered=[None]*8;dist.all_gather_object(gathered,checks)
    exact=all(s['bitwise_equal'] and s['finite'] for group in gathered for row in group for s in row['qkv'])
    cases={'qkv_then_rdma':lambda:run(False)}
    if exact:cases['v_gemm_during_qk_rdma']=lambda:run(True)
    log(dict(stage='projection_split_eligibility',bitwise_equal_all_ranks=exact))
    return dict(timings=measure(cases,args),checks_by_rank=gathered,split_eligible=exact,
                remote_payload_bytes=451282944,
                scope='BF16 H3-shaped synthetic QKV projection + staging + real RDMA; QK norm/RoPE and attention excluded. Split changes GEMM N, so eligibility requires bitwise Q/K/V on all ranks.')



def gate_overlap(comm,device,args):
    main,side=torch.cuda.current_stream(),torch.cuda.Stream()
    x=torch.randn(11992,5376,device=device,dtype=torch.bfloat16)
    weight=torch.randn(7168,5376,device=device,dtype=torch.bfloat16)*.01
    local=torch.randn(1,11992,56,128,device=device,dtype=torch.bfloat16)
    outs=[comm.allocate_output(local,'scatter_heads') for _ in range(3)]
    landings=[comm.input_buffer(out,local.shape) for out in outs]
    for dst in landings:dst.copy_(local)
    def run(overlap):
        with torch.cuda.nvtx.range('lossless.v2.gate.overlap'+str(int(overlap))):
            if overlap:
                side.wait_stream(main)
                with torch.cuda.stream(side):gate=torch.nn.functional.linear(x,weight)
            else:gate=torch.nn.functional.linear(x,weight)
            for src,dst in zip(landings,outs):comm.scatter_heads(src,out=dst)
            if overlap:main.wait_stream(side);gate.record_stream(main)
        return gate
    checks=[]
    for pattern in range(3):
        x.normal_()
        if pattern:x[::(17+pattern)].zero_()
        ref=run(False);torch.cuda.synchronize()
        out=run(True);torch.cuda.synchronize()
        checks.append(dict(pattern=pattern,gate=compare(ref,out)))
        del ref,out
    gathered=[None]*8;dist.all_gather_object(gathered,checks)
    assert all(r['gate']['bitwise_equal'] and r['gate']['finite'] for group in gathered for r in group),gathered
    return dict(timings=measure({'gate_then_rdma':lambda:run(False),
                                'gate_during_rdma':lambda:run(True)},args),
                checks_by_rank=gathered,remote_payload_bytes=451282944,
                scope='Unchanged BF16 gate GEMM M11992 N7168 K5376, synthetic inputs, scheduled alongside real QKV RDMA. QKV projection and QK norm/RoPE excluded.')


def reverse(comm,device,plan,args):
    main,side=torch.cuda.current_stream(),torch.cuda.Stream()
    fine=torch.randn(1,95936,7,128,device=device,dtype=torch.bfloat16)
    coarse=torch.randn(1,7,1648,128,device=device,dtype=torch.bfloat16).permute(0,2,1,3)
    gate=torch.randn(1,11992,56,128,device=device,dtype=torch.bfloat16)
    weight=torch.randn(5376,7168,device=device,dtype=torch.bfloat16)*.01
    result=torch.empty(11992,5376,device=device,dtype=torch.bfloat16)
    gated=torch.empty_like(gate)
    rank=dist.get_rank()
    owners=plan.owner_tile_ids.to(device);row_map=plan.local_row_to_tail[rank].to(device)
    configs={'whole':(1,'whole'),'v1_chunks4':(4,'full'),
             'compact_chunks4':(4,'compact'),'once_chunks2':(2,'once'),
             'once_chunks4':(4,'once'),'once_chunks8':(8,'once')}
    slots={};remote_bytes={}
    for name,(chunks,kind) in configs.items():
        count=11992//chunks;assert chunks*count==11992
        compact=compact_route(plan,count) if kind=='compact' else None
        entries=[]
        for index in range(chunks):
            owner_ids=compact[index][0].to(device) if compact else owners
            mapping=compact[index][1][rank].to(device) if compact else row_map[index*count:(index+1)*count]
            tail=owner_ids.shape[1] if kind!='once' or index==0 else 0
            shape=(1,8*(count+tail),7,128)
            proto=torch.empty(shape,device=device,dtype=torch.bfloat16)
            out=comm.allocate_output(proto,'gather_heads')
            entries.append(dict(landing=comm.input_buffer(out,shape),out=out,owners=owner_ids,mapping=mapping,tail=tail))
            del proto
        slots[name]=entries
        remote_bytes[name]=7*sum(count+entry['tail'] for entry in entries)*7*128*2

    def run(name,capture=False):
        chunks,kind=configs[name];count=11992//chunks;tail_view=None
        with torch.cuda.nvtx.range('lossless.v2.reverse.'+name):
            for index,entry in enumerate(slots[name]):
                start=index*count;landing,out=entry['landing'],entry['out']
                with torch.cuda.nvtx.range(f'lossless.v2.produce.{index}'):
                    if kind=='whole':h3_vsa_o_bundle_out(fine,coarse,plan,out=landing)
                    elif kind=='full':old_produce(fine,coarse,owners,landing,start,count)
                    else:produce(fine,coarse,entry['owners'],landing,start,count)
                with torch.cuda.nvtx.range(f'lossless.v2.rdma.{index}'):
                    comm.gather_heads(landing,out=out)
                if kind=='once' and index==0:tail_view=out[:,count:]
                consumer=main if kind=='whole' else side
                if kind!='whole':side.wait_stream(main)
                with torch.cuda.stream(consumer),torch.cuda.nvtx.range(f'lossless.v2.gate_project.{index}'):
                    if kind=='whole':view=h3_vsa_o_bundle_local_gate_add_(out,gate,plan,owner_rank=rank)
                    elif kind=='full':view=old_gate(out,gate[:,start:start+count],entry['mapping'],count)
                    elif kind=='once':view=gate_shared_tail(out,tail_view,gate[:,start:start+count],entry['mapping'],count)
                    else:
                        gate_view=gate[:,start:start+count]
                        _h3_vsa_o_bundle_local_gate_kernel[(count,7)](
                            out,gate_view,entry['mapping'],*out.stride(),*gate_view.stride(),
                            local_rows=count,head_dim=128,row_width=7168,feature_block=1024,num_warps=8)
                        view=out[:,:count]
                    if capture:gated[:,start:start+count].copy_(view)
                    torch.mm(view.reshape(count,7168),weight.t(),out=result[start:start+count])
            if kind!='whole':main.wait_stream(side)
        return result

    checks=[]
    for pattern in range(3):
        fine.normal_();coarse.normal_();gate.normal_()
        if pattern:fine[:,-12:].zero_();gate[:,::(29+pattern)].zero_()
        run('whole',True);torch.cuda.synchronize()
        ref=result.clone();ref_gate=gated.clone();ref_tail=slots['whole'][0]['out'][:,11992:].clone()
        for name,(_,kind) in configs.items():
            if name=='whole':continue
            run(name,True);torch.cuda.synchronize()
            a,b=compare(ref,result),compare(ref_gate,gated)
            tail_equal=None
            if kind=='once':
                count=11992//configs[name][0]
                tail_equal=bool(torch.equal(ref_tail.view(torch.uint8),slots[name][0]['out'][:,count:].view(torch.uint8)))
            checks.append(dict(pattern=pattern,mode=name,projection=a,gate=b,shared_tail_unchanged=tail_equal))
        del ref,ref_gate,ref_tail
    gathered=[None]*8;dist.all_gather_object(gathered,checks)
    eligible=['whole'];rejected=[]
    for name in configs:
        if name=='whole':continue
        records=[r for group in gathered for r in group if r['mode']==name]
        assert len(records)==24
        valid=all(r['projection']['bitwise_equal'] and r['projection']['finite']
                  and r['gate']['bitwise_equal'] and r['gate']['finite']
                  and r['shared_tail_unchanged'] is not False for r in records)
        (eligible if valid else rejected).append(name)
    assert 'v1_chunks4' in eligible,'Previously validated baseline failed the current correctness check'
    log(dict(stage='lossless_reverse_eligibility',eligible=eligible,rejected=rejected))
    timings=measure({name:(lambda name=name:run(name)) for name in eligible},args)
    return dict(timings=timings,checks_by_rank=gathered,eligible=eligible,rejected=rejected,remote_bytes=remote_bytes,
                scope='Real BF16 RDMA, original BF16 gate arithmetic, H3-shaped synthetic O projection; no full-model latency claim.')


def main():
    p=argparse.ArgumentParser();p.add_argument('--warmup',type=int,default=5)
    p.add_argument('--trials',type=int,default=8);p.add_argument('--iters',type=int,default=8)
    p.add_argument('--case',choices=('all','forward','reverse','projection','gate'),default='all')
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    torch.set_grad_enabled(False);device=torch.device('cuda',int(os.environ['LOCAL_RANK']))
    torch.cuda.set_device(device)
    dist.init_process_group('nccl',device_id=device,timeout=datetime.timedelta(minutes=5))
    assert dist.get_world_size()==8
    torch.manual_seed(1101+dist.get_rank())
    stream=torch.cuda.Stream(priority=-1);stream.wait_stream(torch.cuda.current_stream());torch.cuda.set_stream(stream)
    helpers=source_helpers();maps,sizes,plan=geometry(device,helpers)
    result=dict(scope='Lossless candidates, synthetic H3 tensors, actual SP8 RDMA; paired max-rank wall time.',
                protocol={**vars(args),'output':str(args.output)},torch=torch.__version__,
                rank_to_physical=[0,4,1,5,2,6,3,7],source_sha256=helpers['source_sha256'],
                sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')})
    with UlyssesCommunicator(max_bytes=175788032,dtype=torch.bfloat16,backend='pcie',device=device) as comm:
        assert comm.transport=='rdma',comm.transport
        log(dict(stage='lossless_v2_rdma_ready',route=comm.decision.reason))
        if args.case in ('all','forward'):result['forward']=forward(comm,device,helpers,maps,sizes,args)
        if args.case in ('all','reverse'):result['reverse']=reverse(comm,device,plan,args)
        if args.case in ('all','projection'):result['projection']=projection_overlap(comm,device,args)
        if args.case in ('all','gate'):result['gate']=gate_overlap(comm,device,args)
        barrier()
    if dist.get_rank()==0:args.output.write_text(json.dumps(result,indent=2)+'\n')
    dist.destroy_process_group()


if __name__=='__main__':main()
