"""Sequential, resumable four-way H3 campaign; waits for eight free GPUs."""
import csv
import datetime
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT=Path(__file__).resolve().parent
MODES=('bf16-base','bf16-overlap','fp8-base','fp8-overlap')
STATUS=ROOT/'full-campaign-status.json'

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
state=dict(started=now(),state='starting',completed=[])
if STATUS.exists():
    state=json.loads(STATUS.read_text())

def save(**values):
    if values.get('state') != 'failed':state.pop('error',None)
    state.update(values,updated=now())
    tmp=STATUS.with_suffix('.tmp');tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(STATUS)
    print(json.dumps(values),flush=True)

def wait_free(case):
    free=0
    while free<3:
        apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader'],text=True).strip()
        usage=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True).strip()
        rows=list(csv.reader(usage.splitlines()))
        idle=not apps and len(rows)==8 and all(float(row[1])<100 and float(row[2])<5 for row in rows)
        free=free+1 if idle else 0
        save(state='waiting_for_eight_free_gpus',current=case,compute_apps=apps,gpu_usage=usage,consecutive_idle_samples=free)
        if free<3:time.sleep(20)

def archive_preflight_failure(case):
    folder=ROOT/'runs'/case
    gates=list(folder.glob('vllm-*/gpu-health-pre-balance.json'))
    if not folder.exists():return False
    if len(gates)!=1 or list(folder.glob('vllm-*/server.pid')):return False
    health=json.loads(gates[0].read_text())
    if health.get('status')!='failed':return False
    # Preserve rejected evidence. No model process or measured request started.
    rejected=ROOT/'rejected-attempts';rejected.mkdir(exist_ok=True)
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    dest=rejected/(case+'-'+stamp);folder.rename(dest)
    log=ROOT/f'{case}.log'
    if log.exists():log.rename(dest/'controller-case.log')
    state.setdefault('retry_history',[]).append(dict(case=case,archive=str(dest),reason='prelaunch_gpu_health_gate',at=now()))
    save(state='retrying_prelaunch_gpu_health_gate',current=case)
    return True

def run(mode,kind,tag=None,qualification=False):
    case=tag or f'{mode}-{kind}'
    if any(item['case']==case for item in state['completed']):return
    archive_preflight_failure(case)
    env=dict(os.environ)
    if tag:env['H3_EXPERIMENT_RUN_TAG']=tag
    if qualification:env.update(H3_EXPERIMENT_REPEATS='1',H3_EXPERIMENT_WARMUPS='1')
    while True:
        wait_free(case)
        save(state='running',current=case,case_started=now())
        try:
            with (ROOT/f'{case}.log').open('w') as log:
                subprocess.run(['bash',str(ROOT/'run_model_case.sh'),mode,kind],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
            break
        except subprocess.CalledProcessError:
            if not archive_preflight_failure(case):raise
    with (ROOT/'runs'/case/'summary.tsv').open() as f:rows=list(csv.DictReader(f,delimiter='\t'))
    assert len(rows)==1 and rows[0]['status']=='ok',(case,rows)
    if mode.startswith('fp8'):
        server,=(ROOT/'runs'/case).glob('vllm-*/server.log')
        audit=[]
        for line in server.read_text().splitlines():
            if 'H3_BLOCKWISE_AUDIT ' in line:
                audit.append(json.loads(line.split('H3_BLOCKWISE_AUDIT ',1)[1]))
        assert sorted(item['rank'] for item in audit)==list(range(8)),audit
        assert all(item['modules']==200 and item['fallbacks']==0 and item['status']=='ok' for item in audit)
        (ROOT/'runs'/case/'blockwise-runtime-audit.json').write_text(json.dumps(audit,indent=2))
    state['completed'].append(dict(case=case,finished=now(),summary=rows[0]))
    save(state='case_completed',current=case)

try:
    micro=json.loads((ROOT/'micro-v1.json').read_text())
    assert json.loads((ROOT/'micro-status.json').read_text())['state']=='completed'
    assert all(r['gate']['bitwise_equal'] and r['gate']['finite'] for group in micro['gate']['checks_by_rank'] for r in group)
    for name,kind,enabled in [('v1-control','normal',False),('v2-gate','normal',True),('v2-gate','stages',True),('v2-gate','nsys',True)]:
        os.environ['VLLM_OMNI_H3_LOSSLESS_GATE']=str(int(enabled))
        tag=name+'-'+kind
        run('bf16-overlap',kind,tag)
        folder=ROOT/'runs'/tag
        if enabled:
            server,=folder.glob('vllm-*/server.log')
            ranks=[int(x) for x in re.findall(r'H3_LOSSLESS_GATE rank=(\d+)',server.read_text())]
            assert sorted(ranks)==list(range(8)),ranks
        import hashlib
        videos=sorted(folder.glob('vllm-*/out_t2va1*.mp4'))
        assert videos,folder
        identities=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in videos]
        # Same model, precision, prompt, seed, and output media contract.
        assert all(r['sha256']=='aa55fa19de94066e999f04275362f5477b3d74eb925d45fece8918d1cc8f596a' for r in identities),identities
        (folder/'lossless-video-check.json').write_text(json.dumps(dict(status='passed',videos=identities),indent=2)+'\n')
    save(state='completed',finished=now())
except BaseException as exc:
    save(state='failed',error=repr(exc))
    raise
