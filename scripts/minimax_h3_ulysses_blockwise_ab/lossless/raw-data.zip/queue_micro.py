"""Run only after the frozen full campaign; reject foreign GPU activity."""
import csv
import datetime
import json
import os
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parent
STATUS=ROOT/'micro-status.json'


def save(state,**extra):
    value=dict(state=state,updated=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra)
    temp=STATUS.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(STATUS)
    print(json.dumps(value),flush=True)


def apps():
    raw=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader'],text=True)
    return list(csv.reader(raw.splitlines()))


def descendant(pid,root):
    for _ in range(128):
        if pid==root:return True
        if pid<=1:return False
        try:pid=int(Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[1])
        except (FileNotFoundError,ProcessLookupError,ValueError):return False
    return False


def main():
    save('waiting_for_frozen_campaign')
    while True:
        prior=json.loads((ROOT.parent/'full-campaign-status.json').read_text())
        assert prior['state']!='failed',prior.get('error')
        if prior['state']=='completed':break
        time.sleep(10)
    consecutive=0
    while consecutive<3:
        active=apps()
        usage=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used,utilization.gpu,temperature.gpu','--format=csv,noheader,nounits'],text=True)
        rows=list(csv.reader(usage.splitlines()))
        idle=not active and len(rows)==8 and all(float(r[1])<100 and float(r[2])<5 for r in rows)
        consecutive=consecutive+1 if idle else 0
        save('waiting_for_eight_free_gpus',consecutive_idle_samples=consecutive,gpu_usage=usage)
        if consecutive<3:time.sleep(20)
    output=ROOT/'micro-v1.json'
    assert not output.exists(),output
    with (ROOT/'micro-v1.log').open('w') as log:
        process=subprocess.Popen(['bash',str(ROOT/'run_micro.sh'),'--output',str(output)],
                                 cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        save('running',pid=process.pid,output=str(output))
        foreign=[]
        while process.poll() is None:
            for row in apps():
                pid=int(row[1].strip())
                try:pgid=os.getpgid(pid)
                except ProcessLookupError:continue
                if pgid!=process.pid and not descendant(pid,process.pid):
                    foreign.append(dict(timestamp=time.time(),pid=pid,pgid=pgid,gpu_uuid=row[0]))
            time.sleep(1)
        (ROOT/'foreign-process-observations.json').write_text(json.dumps(foreign,indent=2)+'\n')
        assert process.returncode==0,dict(returncode=process.returncode,log=str(ROOT/'micro-v1.log'))
        assert not foreign,'Foreign GPU process observations reject this microbenchmark'
    save('completed',output=str(output))


if __name__=='__main__':
    try:main()
    except BaseException as error:
        save('failed',error=repr(error))
        raise
