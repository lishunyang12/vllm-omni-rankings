#!/usr/bin/env bash
set -euo pipefail
LOSSLESS_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$LOSSLESS_DIR/../../h3-vsa-sage-teahouse15s-20260910"
export CUDA_VISIBLE_DEVICES=0,4,1,5,2,6,3,7
export FLASHINFER_ULYSSES_PCIE_ROUTE=rdma
export VLLM_OMNI_H3_VSA_SAGE=pr4951
export PYTHONPATH="$SOURCE_DIR/flashinfer:$SOURCE_DIR/vllm-omni${PYTHONPATH:+:$PYTHONPATH}"
export FLASHINFER_WORKSPACE_BASE="$SOURCE_DIR/cache/flashinfer"
export TRITON_CACHE_DIR="$LOSSLESS_DIR/cache/triton"
export CUDA_CACHE_PATH="$LOSSLESS_DIR/cache/cuda"
export OMP_NUM_THREADS=4
export MAX_JOBS=8
exec /lustre/raplab/client/sylarl/minimax-h3-native/vllm-omni-h3-dlo-latest/.venv-vllm028/bin/python \
  -m torch.distributed.run --standalone --nproc-per-node=8 \
  "$LOSSLESS_DIR/benchmark.py" "$@"
